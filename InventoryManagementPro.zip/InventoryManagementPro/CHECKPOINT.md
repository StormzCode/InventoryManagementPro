# CHECKPOINT - resume here

## Decisions (from the user)
- Database is **InvProDB** (not InventoryDB), server `BLACKSTORMZ\SQLEXPRESS`, Windows auth, ODBC Driver 18.
- Light theme default; theme switchable in Settings (10 themes). Original palette kept as the Dark theme.
- Real login, per-store roles/permissions, everything stored in SQL Server, 100+ settings.
- Every error must show exact numbered fix steps (core/errors.py -> Guidance; shown by ui/widgets.show_guidance).
- Look inspired by the 30 reference screenshots (cards, table, modals, stock preview panel, report tabs).

## Done (Phases 1-2) - smoke-tested headless; every SQL statement checked with sqlglot (T-SQL) and placeholder counts
core/ (config, errors, security, permissions, settings_registry, formatting), database.py, schema.sql (ALL tables),
services/ (auth, users+stores, roles, settings, audit), ui/ (theme, widgets, table, shell, login),
ui/pages/ (settings_page, admin_page, products_page, categories_page, suppliers_page), services/catalog.py, core/export.py, ui/export_ui.py, application.py, main.py.

## Next
- Phase 3: services/stock.py + pages stock (Stock in / Stock out / Adjustment tabs, live preview panel, confirm dialog,
  single SQL transaction updating Products + inserting StockTransactions, double-submit guard) and transactions (filters, details).
- Phase 4: dashboard (cards, matplotlib charts, recent, low stock, quick actions) and reports (5 tabs + CSV export).
- Register each page in ui/pages/__init__.py build_registry(); settings with that page key then show up automatically.
- Settings already registered for those pages: see `page=` in core/settings_registry.py.

## Conventions
- UI never touches pyodbc; services take `db` and raise AppError via core.errors.user_error(title, cause, steps).
- Long work: app.run_async(work, done, failed). Pages must check self.alive() in callbacks.
- Never name attributes `state`, `config`, `title` on the Tk root.
- Forms: Form(host_frame) uses grid; never pack other widgets into the same frame as a Form.

## Phase 2 notes
- Products.Quantity is only set at creation (opening stock + a 'Stock In' transaction, reference OPENING). Later changes must go through services/stock.py (Phase 3) in ONE transaction that updates Products.Quantity and inserts StockTransactions.
- Forms use core.errors.FieldError so the fix text appears under the exact field (ui/widgets.submit_form).
- Settings 'transactions.*', 'stock.*', 'dashboard.*', 'reports.default_tab/include_totals_row', 'inventory.show_value_basis_cost' and 'regional.first_day_of_week' are waiting for Phases 3-4.
- Gotcha found in testing: never pack() into a frame that also hosts a Form (grid). Always give the Form its own host frame.
