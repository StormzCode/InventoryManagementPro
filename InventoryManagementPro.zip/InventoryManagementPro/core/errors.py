"""Central error guidance. Every failure the app can raise carries *what happened* and
*exactly what to do about it*. UI code only ever shows a Guidance object."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Guidance:
    title: str
    cause: str
    steps: list[str]
    detail: str = ""
    code: str = "UNKNOWN"

    def short(self) -> str:
        """One-line version for toasts: the title plus the first fix step."""
        return f"{self.title} Fix: {self.steps[0]}" if self.steps else self.title

    def full_text(self) -> str:
        lines = [self.title, "", f"Why: {self.cause}", "", "How to fix it:"]
        lines += [f"  {i}. {s}" for i, s in enumerate(self.steps, 1)]
        if self.detail:
            lines += ["", f"Technical detail: {self.detail}"]
        return "\n".join(lines)


class AppError(Exception):
    """Any error the user should see. Always carries a Guidance."""

    def __init__(self, guidance: Guidance):
        super().__init__(guidance.title)
        self.guidance = guidance


def user_error(title: str, cause: str, steps: list[str], code: str = "INPUT") -> AppError:
    """Convenience for validation / business-rule errors raised by services."""
    return AppError(Guidance(title, cause, steps, code=code))


# ----------------------------------------------------------------------------------------
# Database guidance
# ----------------------------------------------------------------------------------------
def database_guidance(sqlstate: str, text: str, server: str, database: str, driver: str) -> Guidance:
    low = text.lower()
    detail = text.strip()

    if sqlstate == "IM002" or "data source name not found" in low or "can't open lib" in low:
        return Guidance(
            "The SQL Server ODBC driver is not installed.",
            f"Windows has no driver called '{driver}'.",
            [
                "Download 'Microsoft ODBC Driver 18 for SQL Server' (x64) from Microsoft: "
                "search for 'Download ODBC Driver for SQL Server'.",
                "Run the installer, accept the defaults, then restart this app.",
                "Check it installed: press Win+R, type odbcad32, open the 'Drivers' tab and look for "
                "'ODBC Driver 18 for SQL Server'.",
                "If you only have 'ODBC Driver 17', either install 18, or create a file named config.json "
                'next to main.py containing {"driver": "ODBC Driver 17 for SQL Server"}.',
            ],
            detail, "ODBC_DRIVER_MISSING")

    if "18456" in text or "login failed" in low:
        return Guidance(
            "SQL Server refused your Windows login.",
            f"Your Windows account is not allowed to sign in to '{server}'.",
            [
                "Open SQL Server Management Studio (SSMS) connected as an administrator.",
                "Expand Security > Logins, right-click Logins > New Login, and add your Windows account "
                "(example: BLACKSTORMZ\\YourName).",
                "On the 'Server Roles' page tick 'dbcreator' (needed once to create InvProDB) and 'public'. "
                "Click OK, then restart this app.",
                "Make sure you are running the app while signed in to Windows as that same account.",
            ],
            detail, "LOGIN_FAILED")

    if "certificate" in low or "ssl provider" in low:
        return Guidance(
            "SQL Server's security certificate was rejected.",
            "Driver 18 encrypts the connection and does not trust a self-signed certificate by default.",
            [
                "This app already sends TrustServerCertificate=yes, so this usually means a custom "
                "config.json overrides the driver or server.",
                "Delete config.json (next to main.py) or make sure it only changes 'server', 'database' or 'driver'.",
                "Restart the app.",
            ],
            detail, "CERT_ERROR")

    if "4060" in text or "cannot open database" in low:
        return Guidance(
            f"Database '{database}' cannot be opened.",
            "It either does not exist yet or your Windows account has no access to it.",
            [
                "Restart the app: it creates the database automatically when your account has the "
                "'dbcreator' server role.",
                "If creation fails, create it yourself in SSMS: right-click Databases > New Database, "
                f"name it {database}, click OK.",
                f"Then in SSMS: Security > Logins > your account > User Mapping > tick {database} and "
                "tick the 'db_owner' role. Restart the app.",
            ],
            detail, "DB_CANNOT_OPEN")

    if "permission denied" in low and "create database" in low or "262" in text and "create database" in low:
        return Guidance(
            f"Your account may not create the '{database}' database.",
            "Creating a database needs the 'dbcreator' or 'sysadmin' server role.",
            [
                "In SSMS (as administrator): Security > Logins > your account > Server Roles > tick 'dbcreator'.",
                "Or create an empty database named "
                f"{database} yourself (right-click Databases > New Database).",
                "Restart this app. It will create all tables automatically.",
            ],
            detail, "CREATE_DB_DENIED")

    if (sqlstate in ("08001", "HYT00", "08S01", "HYT01") or "timeout" in low
            or "could not open a connection" in low or "server does not exist" in low
            or "named pipes" in low or "no connection could be made" in low):
        return Guidance(
            f"Cannot reach SQL Server '{server}'.",
            "The server is stopped, the name is wrong, or TCP/IP is turned off.",
            [
                "Press Win+R, type services.msc, find 'SQL Server (SQLEXPRESS)' and make sure Status is "
                "'Running' (right-click > Start). Also start 'SQL Server Browser'.",
                "Open 'SQL Server Configuration Manager' > SQL Server Network Configuration > "
                "Protocols for SQLEXPRESS > set 'TCP/IP' to Enabled, then restart the SQL Server service.",
                "Check the name: in SSMS the Server name must be exactly "
                f"{server}. If yours differs, create config.json next to main.py with "
                '{"server": "YOUR-PC\\\\SQLEXPRESS"}.',
                "If it still times out, allow the Windows Firewall to let sqlservr.exe and sqlbrowser.exe through.",
            ],
            detail, "SERVER_UNREACHABLE")

    if "deadlock" in low or "1205" in text:
        return Guidance(
            "The database was busy and cancelled your action.",
            "Another operation locked the same rows at the same moment.",
            ["Nothing was saved. Wait a few seconds and repeat the action once."],
            detail, "DEADLOCK")

    return Guidance(
        "The database returned an unexpected error.",
        "SQL Server rejected a command and the app does not have a specific fix for this message.",
        [
            "Retry the action once.",
            "If it repeats, open 'Technical detail' below, copy it, and check it against schema.sql "
            "(the table or column named in the message must exist).",
            "To rebuild a damaged empty database: in SSMS drop the database "
            f"{database}, then restart this app so it recreates everything.",
        ],
        detail, "DB_UNKNOWN")


def integrity_guidance(text: str) -> Guidance:
    low = text.lower()
    if "unique" in low or "duplicate" in low or "2627" in text or "2601" in text:
        return Guidance(
            "That value already exists.",
            "A unique field (username, SKU, category name, store name ...) matches an existing record.",
            ["Change the value to something not used yet, or open the existing record and edit that instead."],
            text.strip(), "DUPLICATE")
    if "foreign key" in low or "reference constraint" in low or "547" in text:
        return Guidance(
            "This record is linked to other data.",
            "Other records (products, transactions, users) still depend on it.",
            ["Reassign or remove the linked records first, then repeat the action.",
             "If you only want to hide it, use Disable / Deactivate instead of delete."],
            text.strip(), "FK_IN_USE")
    if "check constraint" in low:
        return Guidance(
            "A value is outside the allowed range.",
            "The database refuses negative prices, negative stock and unknown transaction types.",
            ["Correct the highlighted number (it must be zero or more) and save again."],
            text.strip(), "CHECK_FAILED")
    return Guidance(
        "The database rejected this change.",
        "A rule in the database (unique, linked or range check) was broken.",
        ["Review the values you entered and try again.",
         "If it keeps failing copy the technical detail and compare it with schema.sql."],
        text.strip(), "INTEGRITY")


def schema_file_missing(path: str) -> Guidance:
    return Guidance(
        "schema.sql is missing.",
        f"The app builds its tables from {path} and cannot find it.",
        ["Make sure schema.sql is in the same folder as main.py (re-extract the project zip if needed).",
         "Do not rename or move the file, then restart the app."],
        path, "SCHEMA_MISSING")


def schema_failed(batch_no: int, text: str) -> Guidance:
    return Guidance(
        "Creating the database tables failed.",
        f"Batch {batch_no} of schema.sql was rejected by SQL Server.",
        ["Make sure your account is db_owner on the database (SSMS: Security > Logins > User Mapping).",
         "If you edited schema.sql, undo your change or restore it from the zip.",
         "Restart the app. The script is safe to re-run: it only creates what is missing."],
        text.strip(), "SCHEMA_FAILED")


def config_guidance(text: str) -> Guidance:
    return Guidance(
        "config.json could not be read.",
        "The optional settings file next to main.py contains a mistake.",
        ["Open config.json in a text editor.",
         'It must look like: {"server": "BLACKSTORMZ\\\\SQLEXPRESS", "database": "InvProDB"} '
         "(note the doubled backslash).",
         "Or delete config.json to use the built-in defaults, then restart."],
        text, "CONFIG_INVALID")


def unexpected_guidance(exc: BaseException) -> Guidance:
    return Guidance(
        "Something unexpected went wrong.",
        "The app hit a situation it was not designed for. Your data was not changed by this error.",
        ["Repeat the action once.",
         "If it happens again, sign out and sign in, then retry.",
         "Copy the technical detail below when reporting it."],
        f"{type(exc).__name__}: {exc}", "UNEXPECTED")


def guidance_of(exc: BaseException) -> Guidance:
    """Turn any exception into a Guidance."""
    if isinstance(exc, AppError):
        return exc.guidance
    return unexpected_guidance(exc)


class FieldError(AppError):
    """A validation problem tied to one form field; the form shows the fix right under that field."""

    def __init__(self, field: str, guidance: Guidance):
        super().__init__(guidance)
        self.field = field

    def inline_text(self) -> str:
        return " ".join([self.guidance.title] + self.guidance.steps[:2])


def field_error(field: str, title: str, cause: str, steps: list[str], code: str = "INPUT") -> FieldError:
    return FieldError(field, Guidance(title, cause, steps, code=code))
