"""Permission catalog, built-in roles and the Session that answers 'can this user do X in this store?'."""
from __future__ import annotations

from dataclasses import dataclass, field
from fnmatch import fnmatchcase

# (code, group, description)
PERMISSIONS: list[tuple[str, str, str]] = [
    ("dashboard.view", "Dashboard", "See the dashboard"),
    ("products.view", "Products", "See products"),
    ("products.create", "Products", "Add products"),
    ("products.edit", "Products", "Edit products"),
    ("products.delete", "Products", "Delete products"),
    ("products.export", "Products", "Export products to CSV"),
    ("categories.view", "Categories", "See categories"),
    ("categories.create", "Categories", "Add categories"),
    ("categories.edit", "Categories", "Edit categories"),
    ("categories.delete", "Categories", "Delete categories"),
    ("suppliers.view", "Suppliers", "See suppliers"),
    ("suppliers.create", "Suppliers", "Add suppliers"),
    ("suppliers.edit", "Suppliers", "Edit suppliers"),
    ("suppliers.delete", "Suppliers", "Delete suppliers"),
    ("stock.view", "Stock", "Open stock management"),
    ("stock.in", "Stock", "Record Stock In"),
    ("stock.out", "Stock", "Record Stock Out"),
    ("stock.adjust", "Stock", "Adjust counted quantities"),
    ("transactions.view", "Transactions", "See transaction history"),
    ("transactions.export", "Transactions", "Export transactions to CSV"),
    ("reports.view", "Reports", "See reports"),
    ("reports.export", "Reports", "Export reports to CSV"),
    ("settings.view", "Settings", "Open settings"),
    ("settings.personal", "Settings", "Change personal settings (theme, formats)"),
    ("settings.store", "Settings", "Change this store's settings (currency, stock rules)"),
    ("users.view", "Administration", "See users"),
    ("users.create", "Administration", "Create users"),
    ("users.edit", "Administration", "Edit users"),
    ("users.assign_roles", "Administration", "Give users roles in this store"),
    ("users.deactivate", "Administration", "Disable / enable users"),
    ("users.reset_password", "Administration", "Reset other users' passwords"),
    ("stores.view", "Administration", "See stores"),
    ("stores.create", "Administration", "Create stores"),
    ("stores.edit", "Administration", "Edit / deactivate stores"),
    ("roles.view", "Administration", "See roles"),
    ("roles.manage", "Administration", "Create and edit custom roles"),
    ("audit.view", "Administration", "See the audit log"),
]
ALL_CODES = frozenset(code for code, _, _ in PERMISSIONS)
DESCRIPTIONS = {code: desc for code, _, desc in PERMISSIONS}
GROUP_ORDER = ["Dashboard", "Products", "Categories", "Suppliers", "Stock", "Transactions",
               "Reports", "Settings", "Administration"]


def _pick(*patterns: str, exclude: tuple[str, ...] = ()) -> frozenset[str]:
    return frozenset(
        c for c in ALL_CODES
        if any(fnmatchcase(c, p) for p in patterns) and not any(fnmatchcase(c, e) for e in exclude)
    )


@dataclass(frozen=True)
class SystemRole:
    name: str
    rank: int  # lower number = more powerful
    description: str
    permissions: frozenset[str]


SYSTEM_ROLES: list[SystemRole] = [
    SystemRole("Administrator", 10, "Full control of the store, its users and its data.", ALL_CODES),
    SystemRole("Manager", 20, "Runs day-to-day inventory, adjustments and reports. No user administration.",
               _pick("dashboard.*", "products.*", "categories.*", "suppliers.*", "stock.*",
                     "transactions.*", "reports.*", "settings.view", "settings.personal",
                     "settings.store", "audit.view")),
    SystemRole("Stock Clerk", 30, "Adds and edits products and records stock in/out. Cannot delete or adjust.",
               _pick("dashboard.view", "products.view", "products.create", "products.edit",
                     "categories.view", "suppliers.view", "stock.view", "stock.in", "stock.out",
                     "transactions.view", "settings.view", "settings.personal")),
    SystemRole("Auditor", 40, "Read-only access plus exports and the audit log.",
               _pick("*.view", "*.export", "settings.personal", exclude=("users.*", "stores.*", "roles.*"))
               | frozenset({"audit.view"})),
    SystemRole("Viewer", 50, "Read-only access to inventory and reports.",
               _pick("dashboard.view", "products.view", "categories.view", "suppliers.view",
                     "transactions.view", "reports.view", "settings.view", "settings.personal")),
]
SUPER_ROLE_NAME = "Super administrator"


@dataclass(frozen=True)
class StoreAccess:
    store_id: int
    store_name: str
    role_id: int | None
    role_name: str
    rank: int
    permissions: frozenset[str]


@dataclass
class Session:
    user: dict
    accesses: dict[int, StoreAccess] = field(default_factory=dict)
    active_store_id: int = 0

    @property
    def user_id(self) -> int:
        return self.user["UserID"]

    @property
    def is_super(self) -> bool:
        return bool(self.user.get("IsSuperAdmin"))

    @property
    def active(self) -> StoreAccess:
        return self.accesses[self.active_store_id]

    @property
    def store_name(self) -> str:
        return self.active.store_name

    def can(self, code: str, store_id: int | None = None) -> bool:
        if self.is_super:
            return True
        access = self.accesses.get(store_id if store_id is not None else self.active_store_id)
        return bool(access and code in access.permissions)

    def can_any(self, codes) -> bool:
        return any(self.can(c) for c in codes)

    def stores_where(self, code: str) -> list[StoreAccess]:
        return [a for a in self.accesses.values() if self.can(code, a.store_id)]

    def best_rank(self, store_id: int | None = None) -> int:
        if self.is_super:
            return 0
        access = self.accesses.get(store_id if store_id is not None else self.active_store_id)
        return access.rank if access else 999
