"""CSV export helpers. Failures raise AppError with exact fix steps."""
from __future__ import annotations

import csv
import os
import re
import subprocess
import sys
from datetime import datetime

from core.errors import user_error

ENCODINGS = {"UTF-8 with BOM": "utf-8-sig", "UTF-8": "utf-8", "Windows-1256 (Arabic)": "cp1256", "Windows-1252": "cp1252"}
DELIMITERS = {"Comma": ",", "Semicolon": ";", "Tab": "\t"}


def default_filename(pattern: str, report: str, store: str) -> str:
    slug = lambda text: re.sub(r"[^A-Za-z0-9_-]+", "-", text).strip("-").lower() or "report"
    name = pattern.replace("{report}", slug(report)).replace("{date}", datetime.now().strftime("%Y-%m-%d")).replace("{store}", slug(store))
    return re.sub(r'[<>:"/\\|?*]+', "-", name) or "export"


def _safe(value):
    """Stop spreadsheet formula injection: text that starts with = + @ (or - + non-digit) is prefixed with a quote."""
    if isinstance(value, str) and value and (value[0] in "=+@" or (value[0] == "-" and not value[1:2].isdigit())):
        return "'" + value
    return value


def write_csv(path: str, headers: list[str], rows: list[list], delimiter_label: str, encoding_label: str,
              include_header: bool = True) -> None:
    try:
        with open(path, "w", newline="", encoding=ENCODINGS[encoding_label]) as handle:
            writer = csv.writer(handle, delimiter=DELIMITERS[delimiter_label])
            if include_header:
                writer.writerow(headers)
            for row in rows:
                writer.writerow([_safe(v) for v in row])
    except PermissionError as exc:
        raise user_error("The file could not be written.", f"Windows denied access to '{path}'. It is probably open in Excel or the folder is protected.",
                         ["Close the file in Excel if it is open.", "Press Export again and save it in your Documents folder instead."], "EXPORT_DENIED") from exc
    except UnicodeEncodeError as exc:
        raise user_error("Some characters do not fit the chosen CSV encoding.", f"{encoding_label} cannot store every letter in this data.",
                         ["Open Settings > Reports & Export > CSV encoding and choose 'UTF-8 with BOM'.", "Press Export again."], "EXPORT_ENCODING") from exc
    except OSError as exc:
        raise user_error("The file could not be saved.", str(exc),
                         ["Check the folder name exists and the disk has free space.", "Press Export again and pick a different folder."], "EXPORT_FAILED") from exc


def open_file(path: str) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except OSError:
        pass
