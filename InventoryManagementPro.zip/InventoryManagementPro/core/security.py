"""Password hashing (PBKDF2-HMAC-SHA256) and input validation helpers. No plain-text passwords are stored."""
from __future__ import annotations

import hashlib
import hmac
import os
import re

ITERATIONS = 240_000
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_USERNAME = re.compile(r"^[A-Za-z0-9._-]{3,40}$")


def hash_password(password: str, iterations: int = ITERATIONS) -> tuple[str, str, int]:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return digest.hex(), salt.hex(), iterations


def verify_password(password: str, hash_hex: str, salt_hex: str, iterations: int) -> bool:
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), iterations)
    return hmac.compare_digest(digest.hex(), hash_hex)


def password_problems(password: str, min_length: int, need_upper: bool, need_digit: bool,
                      need_symbol: bool) -> list[str]:
    """Return a list of unmet password rules, each phrased as the exact thing to add."""
    problems = []
    if len(password) < min_length:
        problems.append(f"make it at least {min_length} characters long (now {len(password)})")
    if need_upper and not re.search(r"[A-Z]", password):
        problems.append("add at least one capital letter (A-Z)")
    if need_digit and not re.search(r"\d", password):
        problems.append("add at least one number (0-9)")
    if need_symbol and not re.search(r"[^A-Za-z0-9]", password):
        problems.append("add at least one symbol such as ! @ # $ %")
    return problems


def is_valid_email(value: str) -> bool:
    return bool(_EMAIL.match(value))


def is_valid_username(value: str) -> bool:
    return bool(_USERNAME.match(value))
