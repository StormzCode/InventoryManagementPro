"""Every configurable setting in one table. The Settings page is generated from this registry.

scope:  user   -> stored per person          (needs 'settings.personal')
        store  -> stored per store           (needs 'settings.store')
        global -> stored once for all stores (super administrator only)
page:   the page that consumes the setting. Settings whose page is not built yet are hidden
        automatically, so the Settings screen never shows a switch that does nothing.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

THEMES = ("Light", "Dark", "Ocean", "Forest", "Sunset", "Rose", "Midnight", "Graphite",
          "High contrast", "System")
THOUSANDS = {"Comma (1,234)": ",", "Dot (1.234)": ".", "Space (1 234)": " ", "None (1234)": ""}
DATE_FORMATS = {"DD/MM/YYYY": "%d/%m/%Y", "MM/DD/YYYY": "%m/%d/%Y", "YYYY-MM-DD": "%Y-%m-%d",
                "DD Mon YYYY": "%d %b %Y"}
FONTS = ("Segoe UI", "Arial", "Calibri", "Tahoma", "Verdana", "Consolas", "Georgia", "Trebuchet MS")
UNITS = "Piece,Box,Pack,Carton,Kg,Gram,Litre,Meter,Set,Pair,Roll,Bottle"
UTC_OFFSETS = tuple(f"UTC{h:+d}" if h else "UTC" for h in range(-12, 15))
PAGE_KEYS = ("dashboard", "products", "categories", "suppliers", "stock", "transactions", "reports",
             "admin", "settings")
_HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")


@dataclass(frozen=True)
class SettingDef:
    key: str
    label: str
    category: str
    kind: str                 # bool | choice | int | float | text | color
    default: Any
    scope: str                # user | store | global
    description: str = ""
    choices: tuple = ()
    lo: float | None = None
    hi: float | None = None
    page: str | None = None

    def parse(self, raw: Any) -> Any:
        try:
            if self.kind == "bool":
                return str(raw).strip().lower() in ("1", "true", "yes", "on")
            if self.kind == "int":
                return int(float(raw))
            if self.kind == "float":
                return float(raw)
            if self.kind == "choice":
                return str(raw) if str(raw) in self.choices else self.default
        except (TypeError, ValueError):
            return self.default
        return str(raw)

    def dump(self, value: Any) -> str:
        return ("1" if value else "0") if self.kind == "bool" else str(value)

    def validate(self, value: Any) -> tuple[Any, str | None]:
        """Return (clean_value, error). The error text says exactly what to type instead."""
        try:
            if self.kind == "bool":
                return bool(value), None
            if self.kind in ("int", "float"):
                num = int(str(value).strip()) if self.kind == "int" else float(str(value).strip())
                if self.lo is not None and num < self.lo or self.hi is not None and num > self.hi:
                    return None, f"enter a {'whole ' if self.kind == 'int' else ''}number from {self.lo:g} to {self.hi:g}"
                return num, None
            if self.kind == "choice":
                return (value, None) if value in self.choices else (None, "pick one of the listed options")
            if self.kind == "color":
                text = str(value).strip()
                if text and not _HEX.match(text):
                    return None, "enter a colour like #6366F1 (a # and 6 letters/digits) or leave it empty"
                return text, None
            text = str(value).strip()
            if len(text) > 200:
                return None, "shorten it to 200 characters or fewer"
            return text, None
        except ValueError:
            kind = "whole number" if self.kind == "int" else "number"
            return None, f"type a {kind} using digits only, e.g. {int(self.lo) if self.lo is not None else 10}"


SETTINGS: list[SettingDef] = []


def _add(key, label, category, kind, default, scope, desc="", choices=(), lo=None, hi=None, page=None):
    SETTINGS.append(SettingDef(key, label, category, kind, default, scope, desc, tuple(choices), lo, hi, page))


def B(key, label, default, scope, cat, desc="", page=None):
    _add(key, label, cat, "bool", default, scope, desc, page=page)


def C(key, label, default, choices, scope, cat, desc="", page=None):
    _add(key, label, cat, "choice", default, scope, desc, choices, page=page)


def I(key, label, default, lo, hi, scope, cat, desc="", page=None):
    _add(key, label, cat, "int", default, scope, desc, lo=lo, hi=hi, page=page)


def F(key, label, default, lo, hi, scope, cat, desc="", page=None):
    _add(key, label, cat, "float", default, scope, desc, lo=lo, hi=hi, page=page)


def T(key, label, default, scope, cat, desc="", page=None):
    _add(key, label, cat, "text", default, scope, desc, page=page)


def K(key, label, default, scope, cat, desc="", page=None):
    _add(key, label, cat, "color", default, scope, desc, page=page)


# ---------------------------------------------------------------- Appearance (personal)
A = "Appearance"
C("appearance.theme", "Theme", "Light", THEMES, "user", A, "Colour scheme of the whole application.")
K("appearance.accent_color", "Accent colour override", "", "user", A, "Optional #RRGGBB colour that replaces the theme accent.")
C("appearance.font_family", "Font", "Segoe UI", FONTS, "user", A, "Typeface used across the interface.")
C("appearance.font_scale", "Text size", "100%", ("85%", "90%", "100%", "110%", "125%", "150%"), "user", A, "Scales all text.")
C("appearance.ui_scaling", "Interface zoom", "100%", ("80%", "90%", "100%", "110%", "125%", "150%"), "user", A, "Scales every control and window.")
I("appearance.corner_radius", "Corner roundness", 10, 0, 24, "user", A, "0 = square corners, 24 = very round.")
B("appearance.compact_mode", "Compact layout", False, "user", A, "Tighter spacing to fit more on screen.")
I("appearance.page_padding", "Page margin", 28, 8, 56, "user", A, "Space around page content in pixels.")
I("appearance.sidebar_width", "Sidebar width", 236, 200, 340, "user", A, "Width of the left navigation in pixels.")
B("appearance.sidebar_collapsed", "Start with collapsed sidebar", False, "user", A, "Show icons only until expanded.")
B("appearance.sidebar_icons", "Sidebar icons", True, "user", A, "Show an icon next to each menu entry.")
B("appearance.sidebar_store_switcher", "Show store switcher", True, "user", A, "Store selector at the top of the sidebar.")
B("appearance.show_breadcrumb", "Breadcrumb in header", True, "user", A, "Store > Page path at the top.")
B("appearance.show_page_subtitle", "Page descriptions", True, "user", A, "Grey help line under each page title.")
B("appearance.show_connection_status", "Database status indicator", True, "user", A, "Green/red dot in the sidebar.")
I("appearance.table_row_height", "Table row height", 44, 28, 72, "user", A, "Vertical padding of table rows.")
B("appearance.zebra_rows", "Striped table rows", True, "user", A, "Alternate row shading.")
B("appearance.row_hover", "Highlight row under mouse", True, "user", A, "Hover colour in tables.")
B("appearance.card_borders", "Card borders", True, "user", A, "Thin outline around cards and tables.")
B("appearance.uppercase_headers", "UPPERCASE table headers", False, "user", A, "Table column titles in capitals.")

# ---------------------------------------------------------------- Window & startup (personal)
W = "Window & Startup"
B("window.start_maximized", "Open maximised", False, "user", W, "Start the app filling the screen.")
B("window.remember_size", "Remember window size", True, "user", W, "Reopen at the last size and position.")
C("window.default_page", "Page after sign-in", "dashboard", PAGE_KEYS, "user", W, "First page shown. Falls back if you lack access.")
B("window.confirm_exit", "Ask before closing", True, "user", W, "Confirm when closing the window.")
B("window.always_on_top", "Keep window on top", False, "user", W, "Stay above other applications.")
I("window.opacity", "Window opacity", 100, 70, 100, "user", W, "Percent. Lower values make the window see-through.")
B("window.focus_search_on_open", "Focus search on page open", True, "user", W, "Cursor starts in the page search box.")
B("window.ctrl_k_search", "Ctrl+K opens quick search", True, "user", W, "Keyboard shortcut for search.", page="products")

# ---------------------------------------------------------------- Regional & formats
R = "Regional & Formats"
T("regional.currency_symbol", "Currency symbol", "SAR", "store", R, "Shown next to every amount, e.g. SAR, $, EUR.")
C("regional.currency_position", "Symbol position", "Before amount", ("Before amount", "After amount"), "store", R)
C("regional.decimal_places", "Decimal places", "2", ("0", "1", "2", "3"), "store", R, "Digits after the decimal separator for money.")
C("regional.thousands_separator", "Thousands separator", "Comma (1,234)", tuple(THOUSANDS), "store", R)
C("regional.decimal_separator", "Decimal separator", "Dot", ("Dot", "Comma"), "store", R)
C("regional.negative_format", "Negative numbers", "-1,234", ("-1,234", "(1,234)"), "store", R)
C("regional.utc_offset", "Time zone", "UTC+3", UTC_OFFSETS, "store", R, "Times are stored in UTC and shown in this zone. Riyadh = UTC+3.")
C("regional.date_format", "Date format", "DD/MM/YYYY", tuple(DATE_FORMATS), "user", R)
C("regional.time_format", "Time format", "24-hour", ("24-hour", "12-hour"), "user", R)
C("regional.first_day_of_week", "First day of week", "Sunday", ("Saturday", "Sunday", "Monday"), "user", R, "Used by 'this week' date filters.", page="transactions")
B("regional.show_seconds", "Show seconds in times", False, "user", R)
B("regional.show_currency_in_tables", "Currency symbol in table cells", True, "user", R, "Off = symbol only in headers.", page="products")

# ---------------------------------------------------------------- Notifications
N = "Notifications"
B("notify.toasts", "Pop-up messages", True, "user", N, "Small messages for success, warning and errors.")
I("notify.duration", "Message duration (seconds)", 5, 2, 20, "user", N, "Errors stay 3x longer so you can read the fix.")
C("notify.position", "Message position", "Bottom right", ("Bottom right", "Bottom left", "Top right", "Top left"), "user", N)
B("notify.success", "Show success messages", True, "user", N)
B("notify.warning", "Show warning messages", True, "user", N)
B("notify.error", "Show error messages", True, "user", N, "Errors also open a full fix-it dialog when needed.")
B("notify.beep_on_error", "Beep on errors", False, "user", N)
B("notify.low_stock_alerts", "Low-stock alerts", True, "store", N, "Master switch for every low-stock warning.", page="products")
B("notify.low_stock_on_login", "Low-stock summary after sign-in", True, "user", N, "One message listing how many items need restocking.", page="products")
B("notify.out_of_stock_alerts", "Out-of-stock alerts", True, "store", N, page="products")

# ---------------------------------------------------------------- Security (global)
S = "Security & Sessions"
I("security.min_password_length", "Minimum password length", 8, 6, 64, "global", S)
B("security.require_upper", "Password needs a capital letter", True, "global", S)
B("security.require_digit", "Password needs a number", True, "global", S)
B("security.require_symbol", "Password needs a symbol", False, "global", S)
I("security.max_failed_attempts", "Failed sign-ins before lock", 5, 3, 20, "global", S)
I("security.lockout_minutes", "Lock duration (minutes)", 10, 1, 1440, "global", S)
I("security.session_timeout_minutes", "Auto sign-out when idle (minutes)", 30, 0, 1440, "global", S, "0 turns idle sign-out off.")
I("security.password_expiry_days", "Password expires after (days)", 0, 0, 3650, "global", S, "0 = never. Expired passwords must be changed at sign-in.")
B("security.remember_username", "Offer to remember username", True, "global", S, "Shows the 'Remember me' box on the sign-in screen.")
B("security.show_password_toggle", "Show/hide password button", True, "global", S)
B("security.reauth_for_delete", "Ask for password before deleting", False, "global", S, "Extra confirmation for destructive actions.", page="products")
B("security.log_sign_ins", "Record sign-ins in audit log", True, "global", S)

# ---------------------------------------------------------------- Audit (global)
U = "Audit Log"
B("audit.enabled", "Audit log", True, "global", U, "Record who changed what.")
I("audit.retention_days", "Keep entries for (days)", 0, 0, 3650, "global", U, "0 = keep forever.")
B("audit.log_settings", "Record settings changes", True, "global", U)
B("audit.log_exports", "Record CSV exports", True, "global", U)
B("audit.log_user_changes", "Record user and role changes", True, "global", U)
I("audit.page_size", "Audit rows per page", 50, 10, 200, "user", U)

# ---------------------------------------------------------------- Inventory rules (store)
V = "Inventory Rules"
I("inventory.default_reorder_level", "Default reorder level", 10, 0, 100000, "store", V, "Pre-filled for new products.", page="products")
C("inventory.low_stock_mode", "Low stock means", "At or below reorder level", ("At or below reorder level", "Below reorder level", "At or below fixed number"), "store", V, page="products")
I("inventory.low_stock_fixed", "Fixed low-stock number", 5, 0, 100000, "store", V, "Used only with the 'fixed number' rule.", page="products")
C("inventory.default_unit", "Default unit", "Piece", UNITS.split(","), "store", V, page="products")
T("inventory.units_list", "Available units", UNITS, "store", V, "Comma-separated list shown in product forms.", page="products")
T("inventory.sku_prefix", "SKU prefix", "", "store", V, "Added in front of generated SKUs, e.g. ELC.", page="products")
B("inventory.auto_sku", "Suggest SKU automatically", True, "store", V, page="products")
B("inventory.sku_uppercase", "Force SKUs to capitals", True, "store", V, page="products")
I("inventory.sku_digits", "SKU number length", 3, 1, 8, "store", V, "ELC-001 uses 3.", page="products")
B("inventory.require_category", "Category is required", True, "store", V, page="products")
B("inventory.require_supplier", "Supplier is required", True, "store", V, page="products")
B("inventory.require_description", "Description is required", False, "store", V, page="products")
B("inventory.require_selling_price", "Selling price is required", True, "store", V, page="products")
F("inventory.default_markup", "Default markup %", 25.0, 0, 1000, "store", V, "Suggested selling price = cost + this %.", page="products")
B("inventory.warn_below_cost", "Warn if price is below cost", True, "store", V, page="products")
B("inventory.show_value_basis_cost", "Value inventory at cost", True, "store", V, "Off = value at selling price.", page="dashboard")

# ---------------------------------------------------------------- Products page
P = "Products Page"
C("products.page_size", "Rows per page", "25", ("10", "25", "50", "100"), "user", P, page="products")
C("products.sort_by", "Default sort", "Name", ("Name", "SKU", "Stock", "Cost", "Updated"), "user", P, page="products")
B("products.sort_desc", "Sort descending", False, "user", P, page="products")
B("products.col_sku", "Show SKU", True, "user", P, page="products")
B("products.col_category", "Show category", True, "user", P, page="products")
B("products.col_supplier", "Show supplier", True, "user", P, page="products")
B("products.col_cost", "Show cost", True, "user", P, page="products")
B("products.col_price", "Show selling price", True, "user", P, page="products")
B("products.col_status", "Show status", True, "user", P, page="products")
B("products.col_updated", "Show last updated", False, "user", P, page="products")
I("products.search_delay", "Search delay (ms)", 300, 0, 2000, "user", P, "Wait after typing before searching.", page="products")
B("products.search_description", "Search descriptions too", False, "user", P, page="products")
B("products.highlight_low", "Highlight low stock", True, "user", P, page="products")
B("products.remember_filters", "Remember filters", False, "user", P, page="products")
B("products.confirm_delete", "Confirm before delete", True, "user", P, page="products")

# ---------------------------------------------------------------- Categories & suppliers
G = "Categories & Suppliers"
C("categories.page_size", "Categories per page", "25", ("10", "25", "50", "100"), "user", G, page="categories")
B("categories.show_distribution", "Show value distribution panel", True, "user", G, page="categories")
B("categories.show_stats", "Show summary cards", True, "user", G, page="categories")
C("suppliers.page_size", "Suppliers per page", "25", ("10", "25", "50", "100"), "user", G, page="suppliers")
B("suppliers.require_email", "Supplier email is required", True, "store", G, page="suppliers")
B("suppliers.require_phone", "Supplier phone is required", False, "store", G, page="suppliers")
B("suppliers.validate_email", "Check email format", True, "store", G, page="suppliers")
T("suppliers.default_country", "Default country", "Saudi Arabia", "store", G, page="suppliers")
T("suppliers.default_city", "Default city", "Riyadh", "store", G, page="suppliers")
B("suppliers.show_stats", "Show summary cards", True, "user", G, page="suppliers")

# ---------------------------------------------------------------- Stock movements (store)
M = "Stock Movements"
B("stock.require_notes", "Notes are required", True, "store", M, page="stock")
B("stock.require_reference", "Reference is required", False, "store", M, page="stock")
B("stock.review_first", "Review screen before saving", True, "store", M, "Shows the confirm dialog.", page="stock")
I("stock.max_movement", "Largest single movement", 100000, 1, 10000000, "store", M, page="stock")
I("stock.submit_guard", "Double-click guard (seconds)", 2, 0, 30, "store", M, "Ignores a repeated submit within this time.", page="stock")
B("stock.show_value_preview", "Show value preview", True, "store", M, page="stock")
B("stock.suggest_reference", "Suggest a reference number", False, "store", M, page="stock")
T("stock.ref_prefix_in", "Stock In reference prefix", "PO-", "store", M, page="stock")
T("stock.ref_prefix_out", "Stock Out reference prefix", "REQ-", "store", M, page="stock")
B("stock.remember_last_product", "Remember last product", True, "user", M, page="stock")
B("stock.clear_after_save", "Clear form after saving", True, "user", M, page="stock")

# ---------------------------------------------------------------- Transactions page
X = "Transactions Page"
C("transactions.page_size", "Rows per page", "25", ("10", "25", "50", "100"), "user", X, page="transactions")
C("transactions.date_range", "Default date range", "Last 30 days", ("Today", "Last 7 days", "Last 30 days", "This month", "All time"), "user", X, page="transactions")
B("transactions.col_user", "Show user", True, "user", X, page="transactions")
B("transactions.col_reference", "Show reference", True, "user", X, page="transactions")
B("transactions.col_notes", "Show notes", False, "user", X, page="transactions")
T("transactions.id_prefix", "Transaction ID prefix", "TX-", "store", X, page="transactions")
B("transactions.show_summary", "Show summary cards", True, "user", X, page="transactions")

# ---------------------------------------------------------------- Dashboard
D = "Dashboard"
B("dashboard.show_value_chart", "Inventory value chart", True, "user", D, page="dashboard")
B("dashboard.show_category_chart", "Products by category chart", True, "user", D, page="dashboard")
B("dashboard.show_recent", "Recent transactions", True, "user", D, page="dashboard")
B("dashboard.show_low_stock", "Low-stock table", True, "user", D, page="dashboard")
B("dashboard.show_quick_actions", "Quick action buttons", True, "user", D, page="dashboard")
B("dashboard.show_sales_value", "Potential sales value card", True, "user", D, page="dashboard")
I("dashboard.recent_count", "Recent transactions shown", 6, 3, 20, "user", D, page="dashboard")
I("dashboard.low_stock_rows", "Low-stock rows shown", 6, 3, 20, "user", D, page="dashboard")
C("dashboard.chart_days", "Chart period", "30 days", ("7 days", "30 days", "90 days", "365 days"), "user", D, page="dashboard")
I("dashboard.auto_refresh", "Auto-refresh (seconds)", 0, 0, 3600, "user", D, "0 = only when you open the page.", page="dashboard")

# ---------------------------------------------------------------- Reports & export
E = "Reports & Export"
C("reports.default_tab", "Default report", "Inventory valuation", ("Inventory valuation", "Low stock", "By category", "By supplier", "Transactions"), "user", E, page="reports")
T("reports.export_folder", "Export folder", "", "user", E, "Empty = ask every time.")
C("reports.csv_delimiter", "CSV delimiter", "Comma", ("Comma", "Semicolon", "Tab"), "user", E, "Use Semicolon for Excel in many regions.")
C("reports.csv_encoding", "CSV encoding", "UTF-8 with BOM", ("UTF-8 with BOM", "UTF-8", "Windows-1256 (Arabic)", "Windows-1252"), "user", E, "'UTF-8 with BOM' opens Arabic text correctly in Excel.")
B("reports.csv_currency", "Add currency symbol to CSV amounts", False, "user", E)
B("reports.open_after_export", "Open file after export", False, "user", E)
T("reports.filename_pattern", "File name pattern", "{report}-{date}", "user", E, "Use {report}, {date}, {store}.")
B("reports.include_header_row", "Include column headers", True, "user", E)
B("reports.include_totals_row", "Include totals row", False, "user", E, page="reports")

# ---------------------------------------------------------------- System (global)
Y = "System"
I("system.query_timeout", "Query timeout (seconds)", 30, 5, 300, "global", Y, "Longest a single database command may run.")
I("system.idle_check_seconds", "Idle check interval (seconds)", 15, 5, 120, "global", Y)
I("system.status_ping_seconds", "Database ping interval (seconds)", 45, 10, 600, "global", Y, "How often the green/red status dot refreshes.")
C("system.default_store_policy", "Open at sign-in", "Last used store", ("Last used store", "First store"), "user", Y)

REGISTRY: dict[str, SettingDef] = {}
for _d in SETTINGS:
    if _d.key in REGISTRY:
        raise RuntimeError(f"Duplicate setting key: {_d.key}")
    REGISTRY[_d.key] = _d

CATEGORY_ORDER = [A, W, R, N, S, U, V, P, G, M, X, D, E, Y]
SCOPE_LABEL = {"user": "Personal", "store": "This store", "global": "All stores"}
SCOPE_PERMISSION = {"user": "settings.personal", "store": "settings.store", "global": None}
