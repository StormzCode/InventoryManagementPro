"""Application configuration and a tiny local state store (last user, last theme)."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

APP_NAME = "Inventory Management Pro"
APP_VERSION = "1.0.0"
BUILD_PHASE = 1
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = BASE_DIR / "config.json"


@dataclass(frozen=True)
class DbConfig:
    server: str = r"BLACKSTORMZ\SQLEXPRESS"
    database: str = "InvProDB"
    driver: str = "ODBC Driver 18 for SQL Server"
    timeout: int = 15

    def connection_string(self, database: str | None = None) -> str:
        return (
            f"DRIVER={{{self.driver}}};SERVER={self.server};"
            f"DATABASE={database or self.database};"
            "Trusted_Connection=yes;TrustServerCertificate=yes;"
        )


class ConfigError(Exception):
    """config.json is unreadable or contains an invalid value."""


def load_db_config() -> DbConfig:
    cfg = DbConfig()
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            cfg = DbConfig(
                server=str(data.get("server", cfg.server)),
                database=str(data.get("database", cfg.database)),
                driver=str(data.get("driver", cfg.driver)),
                timeout=int(data.get("timeout", cfg.timeout)),
            )
        except (OSError, ValueError, AttributeError) as exc:
            raise ConfigError(str(exc)) from exc
    if not re.fullmatch(r"[A-Za-z0-9_]+", cfg.database):
        raise ConfigError(f"Database name '{cfg.database}' has invalid characters.")
    return cfg


class LocalState:
    """Per-Windows-user JSON file for things needed before sign-in (last username, last theme)."""

    def __init__(self) -> None:
        self.path = Path.home() / ".inventory_management_pro" / "state.json"
        try:
            self.data: dict = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.data = {}

    def get(self, key: str, default=None):
        return self.data.get(key, default)

    def put(self, **values) -> None:
        self.data.update(values)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.data), encoding="utf-8")
        except OSError:
            pass  # local state is a convenience only
