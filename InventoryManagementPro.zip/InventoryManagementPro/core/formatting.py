"""Formats money, numbers and times using the active store/user settings."""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Callable

from core.settings_registry import DATE_FORMATS, THOUSANDS


def _offset_hours(label: str) -> float:
    return 0.0 if label == "UTC" else float(label.replace("UTC", ""))


class Formatter:
    def __init__(self, get: Callable[[str], object]) -> None:
        self._get = get

    def number(self, value, decimals: int = 0) -> str:
        if value is None:
            return "-"
        thousands = THOUSANDS.get(self._get("regional.thousands_separator"), ",")
        decimal = "," if self._get("regional.decimal_separator") == "Comma" else "."
        text = f"{abs(float(value)):,.{decimals}f}"
        whole, _, frac = text.partition(".")
        out = whole.replace(",", thousands) + (decimal + frac if frac else "")
        if float(value) < 0 and float(f"{abs(float(value)):.{decimals}f}") != 0:
            out = f"({out})" if self._get("regional.negative_format") == "(1,234)" else f"-{out}"
        return out

    def money(self, value, with_symbol: bool = True) -> str:
        text = self.number(value, int(self._get("regional.decimal_places")))
        if not with_symbol or value is None:
            return text
        symbol = str(self._get("regional.currency_symbol")).strip()
        if not symbol:
            return text
        gap = " " if symbol[-1].isalpha() else ""
        if self._get("regional.currency_position") == "After amount":
            return f"{text} {symbol}"
        return f"{symbol}{gap}{text}"

    def local(self, dt: datetime | None) -> datetime | None:
        if dt is None:
            return None
        return dt + timedelta(hours=_offset_hours(str(self._get("regional.utc_offset"))))

    def date(self, dt: datetime | None) -> str:
        dt = self.local(dt)
        return "-" if dt is None else dt.strftime(DATE_FORMATS[self._get("regional.date_format")])

    def time(self, dt: datetime | None) -> str:
        dt = self.local(dt)
        if dt is None:
            return "-"
        seconds = ":%S" if self._get("regional.show_seconds") else ""
        pattern = f"%H:%M{seconds}" if self._get("regional.time_format") == "24-hour" else f"%I:%M{seconds} %p"
        return dt.strftime(pattern)

    def datetime(self, dt: datetime | None) -> str:
        return "-" if dt is None else f"{self.date(dt)} {self.time(dt)}"
