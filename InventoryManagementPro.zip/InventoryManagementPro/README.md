# Inventory Management Pro (Phases 1-2: foundation + catalog)

Python + CustomTkinter desktop app on Microsoft SQL Server. Database: **InvProDB** on `BLACKSTORMZ\SQLEXPRESS` (Windows authentication).

## What works in this phase
- Sign-in with lockout, password rules, idle sign-out, forced password change, first-run setup
- Stores, users, **per-store roles** (Administrator, Manager, Stock Clerk, Auditor, Viewer + your own custom roles)
- 150 registered settings (118 are live now; the rest appear automatically when their page is built)
- 10 themes (Light is the default; Dark, Ocean, Forest, Sunset, Rose, Midnight, Graphite, High contrast, System)
- Audit log, store switcher, toast messages, and **guided errors**: every error says why it happened and lists numbered fix steps
- **Products:** search (name/SKU), category/supplier/status filters, sortable columns, paging, add/edit/details/delete (soft delete keeps history), suggested SKU and selling price, opening stock recorded as a transaction, CSV export, low-stock banner
- **Categories:** summary cards, value distribution, add/edit, delete with safe reassignment of products
- **Suppliers:** directory with city filter, details with linked products, add/edit, delete with replacement supplier, CSV export
- Stock Management, Transactions, Dashboard and Reports come in Phases 3-4 (see CHECKPOINT.md). Their database tables already exist.

## Install (Windows, VS Code)
1. Install Python 3.10+ (tick "Add Python to PATH"), SQL Server Express, and **Microsoft ODBC Driver 18 for SQL Server**.
2. Open this folder in VS Code, then open a terminal (Ctrl+`):
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```
3. First launch creates the database `InvProDB` and all tables, then asks you to create the first store and super administrator.

## SQL Server setup (one time)
- Services (Win+R, `services.msc`): "SQL Server (SQLEXPRESS)" and "SQL Server Browser" must be Running.
- SQL Server Configuration Manager: Protocols for SQLEXPRESS, TCP/IP = Enabled, then restart the service.
- Your Windows account needs the `dbcreator` server role (SSMS: Security > Logins > your account > Server Roles) so the app can create InvProDB. Or create an empty database named InvProDB yourself.
- Different server name? Create `config.json` beside main.py: `{"server": "MYPC\\SQLEXPRESS", "database": "InvProDB"}`.
- `schema.sql` can also be run manually in SSMS against InvProDB; it is safe to re-run.

## Roles in short
| Role | Can do |
|---|---|
| Super administrator | Everything in every store, global settings |
| Administrator | Everything in their store incl. users and custom roles |
| Manager | Inventory, adjustments, reports, store settings; no user admin |
| Stock Clerk | Add/edit products, Stock In/Out; no delete or adjust |
| Auditor | Read-only + exports + audit log |
| Viewer | Read-only |

## Troubleshooting
The app shows these fixes on screen; they are repeated here.
- **Driver not found (IM002):** install ODBC Driver 18, restart the app.
- **Login failed (18456):** add your Windows account as a SQL login with `dbcreator`.
- **Cannot reach server / timeout:** start the SQL services, enable TCP/IP, check the server name in config.json.
- **Cannot open database (4060):** restart the app (it creates it) or create InvProDB in SSMS and map your login as db_owner.
- **Certificate error:** remove custom driver/server overrides from config.json.

## Known limitations
- Tested headlessly (UI smoke test with stubbed services). The SQL itself could not be run against SQL Server in the build environment, so please report any SQL error text you see.
- Sidebar icons are Unicode symbols; fonts lacking them show a box (turn off in Settings > Appearance).
