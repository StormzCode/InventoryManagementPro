"""Reads and writes settings in the Settings table. Values are cached per signed-in user + store."""
from __future__ import annotations

from typing import Any

from core.settings_registry import REGISTRY


class SettingsService:
    def __init__(self, db) -> None:
        self.db = db
        self.user_id = 0
        self.store_id = 0
        self._values: dict[tuple[str, int], dict[str, str]] = {}

    def load(self, user_id: int = 0, store_id: int = 0) -> None:
        self.user_id, self.store_id = user_id, store_id
        rows = self.db.query(
            "SELECT Scope, ScopeID, SettingKey, SettingValue FROM Settings "
            "WHERE Scope = 'global' OR (Scope = 'store' AND ScopeID = ?) OR (Scope = 'user' AND ScopeID = ?)",
            (store_id, user_id))
        values: dict[tuple[str, int], dict[str, str]] = {}
        for row in rows:
            values.setdefault((row["Scope"], row["ScopeID"]), {})[row["SettingKey"]] = row["SettingValue"]
        self._values = values

    def _scope_id(self, scope: str) -> int:
        return {"global": 0, "store": self.store_id, "user": self.user_id}[scope]

    def get(self, key: str) -> Any:
        definition = REGISTRY[key]
        raw = self._values.get((definition.scope, self._scope_id(definition.scope)), {}).get(key)
        return definition.default if raw is None else definition.parse(raw)

    def is_default(self, key: str) -> bool:
        definition = REGISTRY[key]
        return self._values.get((definition.scope, self._scope_id(definition.scope)), {}).get(key) is None

    def save(self, changes: dict[str, Any]) -> None:
        if not changes:
            return
        with self.db.transaction() as tx:
            for key, value in changes.items():
                definition = REGISTRY[key]
                scope_id = self._scope_id(definition.scope)
                raw = definition.dump(value)
                updated = tx.execute(
                    "UPDATE Settings SET SettingValue = ?, UpdatedAt = SYSUTCDATETIME() "
                    "WHERE Scope = ? AND ScopeID = ? AND SettingKey = ?",
                    (raw, definition.scope, scope_id, key))
                if updated == 0:
                    tx.execute("INSERT INTO Settings (Scope, ScopeID, SettingKey, SettingValue) VALUES (?, ?, ?, ?)",
                               (definition.scope, scope_id, key, raw))
        for key, value in changes.items():  # cache only after the commit succeeded
            definition = REGISTRY[key]
            self._values.setdefault((definition.scope, self._scope_id(definition.scope)), {})[key] = definition.dump(value)

    def reset(self, keys: list[str]) -> None:
        if not keys:
            return
        with self.db.transaction() as tx:
            for key in keys:
                definition = REGISTRY[key]
                tx.execute("DELETE FROM Settings WHERE Scope = ? AND ScopeID = ? AND SettingKey = ?",
                           (definition.scope, self._scope_id(definition.scope), key))
        for key in keys:
            definition = REGISTRY[key]
            self._values.get((definition.scope, self._scope_id(definition.scope)), {}).pop(key, None)

    def save_store_value(self, store_id: int, key: str, value: Any) -> None:
        """Used by first-run setup and new-store creation, before the store is active."""
        definition = REGISTRY[key]
        self.db.execute("INSERT INTO Settings (Scope, ScopeID, SettingKey, SettingValue) VALUES ('store', ?, ?, ?)",
                        (store_id, key, definition.dump(value)))
