"""Categories, suppliers and products. Everything is scoped to one store and uses parameterised SQL."""
from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

from core.errors import field_error, user_error
from core.security import is_valid_email

SORTS = {"Name": "p.ProductName", "SKU": "p.SKU", "Stock": "p.Quantity", "Cost": "p.PurchasePrice",
         "Price": "p.SellingPrice", "Updated": "p.UpdatedAt", "Category": "c.CategoryName", "Supplier": "s.SupplierName"}
MAX_MONEY = Decimal("999999999999.99")
MAX_INT = 2_000_000_000


def like_pattern(text: str) -> str:
    """Escape LIKE wildcards so user text is matched literally (pair with ESCAPE '\\')."""
    return "%" + re.sub(r"([\\%_\[])", r"\\\1", text) + "%"


def _gone(what: str):
    return user_error(f"That {what} no longer exists.", "Someone else deleted it or it belongs to another store.",
                      ["Close this window and refresh the list."], "GONE")


# ====================================================================== categories
class CategoryService:
    ICONS = ["Box", "Keyboard", "Desk lamp", "Chair", "Paper", "Tools", "Food", "Clothing", "Device", "Other"]

    def __init__(self, db, settings) -> None:
        self.db, self.settings = db, settings

    def list(self, store_id: int) -> list[dict]:
        return self.db.query(
            "SELECT c.CategoryID, c.CategoryName, c.Description, c.IconName, "
            "COUNT(p.ProductID) AS ProductCount, COALESCE(SUM(p.Quantity), 0) AS Units, "
            "COALESCE(SUM(p.Quantity * p.PurchasePrice), 0) AS Value "
            "FROM Categories c LEFT JOIN Products p ON p.CategoryID = c.CategoryID AND p.IsDeleted = 0 "
            "WHERE c.StoreID = ? GROUP BY c.CategoryID, c.CategoryName, c.Description, c.IconName "
            "ORDER BY c.CategoryName", (store_id,))

    def products_in(self, store_id: int, category_id: int) -> list[dict]:
        return self.db.query("SELECT ProductName, SKU, Quantity FROM Products WHERE StoreID = ? AND CategoryID = ? AND IsDeleted = 0 "
                             "ORDER BY ProductName", (store_id, category_id))

    def save(self, store_id: int, category_id: int | None, name: str, description: str, icon: str) -> int:
        name, description = name.strip(), description.strip()
        if not name:
            raise field_error("name", "Category name is empty.", "Every category needs a name.", ["Type a name such as 'Electronics'."])
        if len(name) > 100:
            raise field_error("name", "Category name is too long.", "The limit is 100 characters.", ["Shorten the name to 100 characters or fewer."])
        with self.db.transaction() as tx:
            clash = tx.query_one("SELECT CategoryID FROM Categories WHERE StoreID = ? AND CategoryName = ? AND (? IS NULL OR CategoryID <> ?)",
                                 (store_id, name, category_id, category_id))
            if clash:
                raise field_error("name", f"A category named '{name}' already exists.", "Category names must be unique in a store.",
                                  ["Choose a different name, or edit the existing category instead."], "DUPLICATE")
            if category_id is None:
                return tx.scalar("INSERT INTO Categories (StoreID, CategoryName, Description, IconName) OUTPUT INSERTED.CategoryID VALUES (?, ?, ?, ?)",
                                 (store_id, name, description or None, icon))
            if tx.execute("UPDATE Categories SET CategoryName = ?, Description = ?, IconName = ? WHERE CategoryID = ? AND StoreID = ?",
                          (name, description or None, icon, category_id, store_id)) == 0:
                raise _gone("category")
            return category_id

    def delete(self, store_id: int, category_id: int, move_to: int | None) -> None:
        with self.db.transaction() as tx:
            if not tx.query_one("SELECT CategoryID FROM Categories WHERE CategoryID = ? AND StoreID = ?", (category_id, store_id)):
                raise _gone("category")
            live = tx.scalar("SELECT COUNT(*) FROM Products WHERE CategoryID = ? AND IsDeleted = 0", (category_id,))
            if live and not move_to:
                raise user_error("This category still has products.", f"{live} product(s) use it, so it cannot be deleted yet.",
                                 ["Pick another category in 'Move products to', then press the delete button again."])
            if move_to:
                if move_to == category_id or not tx.query_one("SELECT CategoryID FROM Categories WHERE CategoryID = ? AND StoreID = ?", (move_to, store_id)):
                    raise user_error("The target category is not valid.", "It is the same category or no longer exists.", ["Choose a different category in the list."])
            tx.execute("UPDATE Products SET CategoryID = ? WHERE CategoryID = ?", (move_to, category_id))  # includes soft-deleted rows
            tx.execute("DELETE FROM Categories WHERE CategoryID = ? AND StoreID = ?", (category_id, store_id))


# ====================================================================== suppliers
class SupplierService:
    def __init__(self, db, settings) -> None:
        self.db, self.settings = db, settings

    def list(self, store_id: int) -> list[dict]:
        return self.db.query(
            "SELECT s.SupplierID, s.SupplierName, s.ContactPerson, s.Phone, s.Email, s.City, s.Country, s.Address, s.IsActive, s.CreatedAt, "
            "COUNT(p.ProductID) AS ProductCount, COALESCE(SUM(p.Quantity), 0) AS Units, "
            "COALESCE(SUM(p.Quantity * p.PurchasePrice), 0) AS Value "
            "FROM Suppliers s LEFT JOIN Products p ON p.SupplierID = s.SupplierID AND p.IsDeleted = 0 "
            "WHERE s.StoreID = ? GROUP BY s.SupplierID, s.SupplierName, s.ContactPerson, s.Phone, s.Email, s.City, s.Country, "
            "s.Address, s.IsActive, s.CreatedAt ORDER BY s.SupplierName", (store_id,))

    def linked_products(self, store_id: int, supplier_id: int) -> list[dict]:
        return self.db.query("SELECT ProductName, SKU, Quantity, Quantity * PurchasePrice AS Value FROM Products "
                             "WHERE StoreID = ? AND SupplierID = ? AND IsDeleted = 0 ORDER BY ProductName", (store_id, supplier_id))

    def save(self, store_id: int, supplier_id: int | None, data: dict) -> int:
        get = self.settings.get
        name, email, phone = data["name"].strip(), data["email"].strip(), data["phone"].strip()
        if not name:
            raise field_error("name", "Supplier name is empty.", "Every supplier needs a name.", ["Type the company name, e.g. Riyadh Tech."])
        if get("suppliers.require_email") and not email:
            raise field_error("email", "Email is required.", "Your store settings require a supplier email.",
                              ["Type the supplier's email, e.g. sales@company.sa.", "Or turn the rule off in Settings > Categories & Suppliers."])
        if email and get("suppliers.validate_email") and not is_valid_email(email):
            raise field_error("email", "That email address looks wrong.", "It must look like name@company.com.",
                              ["Check for a missing @ or dot, e.g. maha@najdsupplies.sa."])
        if get("suppliers.require_phone") and not phone:
            raise field_error("phone", "Phone is required.", "Your store settings require a supplier phone number.", ["Type a phone number such as +966 11 555 0194."])
        values = (name, data["contact"].strip() or None, phone or None, email or None, data["city"].strip() or None,
                  data["country"].strip() or None, data["address"].strip() or None)
        with self.db.transaction() as tx:
            clash = tx.query_one("SELECT SupplierID FROM Suppliers WHERE StoreID = ? AND SupplierName = ? AND (? IS NULL OR SupplierID <> ?)",
                                 (store_id, name, supplier_id, supplier_id))
            if clash:
                raise field_error("name", f"A supplier named '{name}' already exists.", "Supplier names must be unique in a store.",
                                  ["Use a different name (add the city, e.g. 'Najd Supplies - Jeddah'), or edit the existing supplier."], "DUPLICATE")
            if supplier_id is None:
                return tx.scalar("INSERT INTO Suppliers (StoreID, SupplierName, ContactPerson, Phone, Email, City, Country, Address) "
                                 "OUTPUT INSERTED.SupplierID VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (store_id,) + values)
            if tx.execute("UPDATE Suppliers SET SupplierName = ?, ContactPerson = ?, Phone = ?, Email = ?, City = ?, Country = ?, Address = ? "
                          "WHERE SupplierID = ? AND StoreID = ?", values + (supplier_id, store_id)) == 0:
                raise _gone("supplier")
            return supplier_id

    def delete(self, store_id: int, supplier_id: int, move_to: int | None) -> None:
        with self.db.transaction() as tx:
            if not tx.query_one("SELECT SupplierID FROM Suppliers WHERE SupplierID = ? AND StoreID = ?", (supplier_id, store_id)):
                raise _gone("supplier")
            live = tx.scalar("SELECT COUNT(*) FROM Products WHERE SupplierID = ? AND IsDeleted = 0", (supplier_id,))
            if live and not move_to:
                raise user_error("This supplier still has products.", f"{live} product(s) are linked to it.",
                                 ["Pick a replacement in 'Assign replacement supplier', then press the delete button again."])
            if move_to and (move_to == supplier_id or not tx.query_one("SELECT SupplierID FROM Suppliers WHERE SupplierID = ? AND StoreID = ?", (move_to, store_id))):
                raise user_error("The replacement supplier is not valid.", "It is the same supplier or no longer exists.", ["Choose a different supplier in the list."])
            tx.execute("UPDATE Products SET SupplierID = ? WHERE SupplierID = ?", (move_to, supplier_id))
            tx.execute("DELETE FROM Suppliers WHERE SupplierID = ? AND StoreID = ?", (supplier_id, store_id))


# ====================================================================== products
class ProductService:
    def __init__(self, db, settings) -> None:
        self.db, self.settings = db, settings

    # ---------------------------------------------------------------- helpers
    def _low(self) -> str:
        mode = self.settings.get("inventory.low_stock_mode")
        if mode == "Below reorder level":
            return "p.Quantity < p.ReorderLevel"
        if mode == "At or below fixed number":
            return f"p.Quantity <= {int(self.settings.get('inventory.low_stock_fixed'))}"
        return "p.Quantity <= p.ReorderLevel"

    def _status(self) -> str:
        return f"CASE WHEN p.Quantity = 0 THEN 'Out of stock' WHEN {self._low()} THEN 'Low stock' ELSE 'In stock' END"

    def lookups(self, store_id: int) -> dict:
        return {"categories": self.db.query("SELECT CategoryID, CategoryName FROM Categories WHERE StoreID = ? ORDER BY CategoryName", (store_id,)),
                "suppliers": self.db.query("SELECT SupplierID, SupplierName FROM Suppliers WHERE StoreID = ? AND IsActive = 1 ORDER BY SupplierName", (store_id,))}

    def suggest_sku(self, store_id: int, prefix: str) -> str:
        prefix = (prefix.strip() or "SKU").rstrip("-")
        if self.settings.get("inventory.sku_uppercase"):
            prefix = prefix.upper()
        rows = self.db.query("SELECT SKU FROM Products WHERE StoreID = ? AND IsDeleted = 0 AND SKU LIKE ? ESCAPE '\\'",
                             (store_id, re.sub(r"([\\%_\[])", r"\\\1", prefix + "-") + "%"))
        highest = 0
        for row in rows:
            match = re.search(r"(\d+)$", row["SKU"])
            if match:
                highest = max(highest, int(match.group(1)))
        return f"{prefix}-{highest + 1:0{int(self.settings.get('inventory.sku_digits'))}d}"

    # ---------------------------------------------------------------- reading
    def _where(self, store_id: int, f: dict) -> tuple[str, list]:
        where, params = ["p.StoreID = ?", "p.IsDeleted = 0"], [store_id]
        if f.get("search"):
            clause = "p.ProductName LIKE ? ESCAPE '\\' OR p.SKU LIKE ? ESCAPE '\\'"
            pattern = like_pattern(f["search"])
            params += [pattern, pattern]
            if self.settings.get("products.search_description"):
                clause += " OR p.Description LIKE ? ESCAPE '\\'"
                params.append(pattern)
            where.append(f"({clause})")
        if f.get("category_id"):
            where.append("p.CategoryID = ?")
            params.append(f["category_id"])
        if f.get("supplier_id"):
            where.append("p.SupplierID = ?")
            params.append(f["supplier_id"])
        if f.get("status"):
            where.append(f"({self._status()}) = ?")
            params.append(f["status"])
        return " AND ".join(where), params

    def list_page(self, store_id: int, filters: dict, sort: str, desc: bool, page: int, size: int) -> tuple[list[dict], int]:
        where, params = self._where(store_id, filters)
        order = SORTS.get(sort, "p.ProductName") + (" DESC" if desc else " ASC")
        total = self.db.scalar(f"SELECT COUNT(*) FROM Products p WHERE {where}", params)
        rows = self.db.query(
            "SELECT p.ProductID, p.ProductName, p.SKU, p.CategoryID, c.CategoryName, p.SupplierID, s.SupplierName, p.PurchasePrice, "
            f"p.SellingPrice, p.Quantity, p.ReorderLevel, p.Unit, p.UpdatedAt, {self._status()} AS Status "
            "FROM Products p LEFT JOIN Categories c ON c.CategoryID = p.CategoryID LEFT JOIN Suppliers s ON s.SupplierID = p.SupplierID "
            f"WHERE {where} ORDER BY {order}, p.ProductID OFFSET ? ROWS FETCH NEXT ? ROWS ONLY",
            params + [(max(1, page) - 1) * size, size])
        return rows, total or 0

    def summary(self, store_id: int) -> dict:
        row = self.db.query_one(
            "SELECT COUNT(*) AS Products, COALESCE(SUM(p.Quantity), 0) AS Units, COALESCE(SUM(p.Quantity * p.PurchasePrice), 0) AS CostValue, "
            f"COALESCE(SUM(CASE WHEN p.Quantity > 0 AND {self._low()} THEN 1 ELSE 0 END), 0) AS LowCount, "
            "COALESCE(SUM(CASE WHEN p.Quantity = 0 THEN 1 ELSE 0 END), 0) AS OutCount "
            "FROM Products p WHERE p.StoreID = ? AND p.IsDeleted = 0", (store_id,))
        row["Categories"] = self.db.scalar("SELECT COUNT(*) FROM Categories WHERE StoreID = ?", (store_id,))
        row["Suppliers"] = self.db.scalar("SELECT COUNT(*) FROM Suppliers WHERE StoreID = ? AND IsActive = 1", (store_id,))
        return row

    def stock_alerts(self, store_id: int) -> tuple[int, int]:
        s = self.summary(store_id)
        return s["LowCount"], s["OutCount"]

    def detail(self, store_id: int, product_id: int) -> dict:
        row = self.db.query_one(
            "SELECT p.ProductID, p.ProductName, p.SKU, p.CategoryID, c.CategoryName, p.SupplierID, s.SupplierName, p.PurchasePrice, p.SellingPrice, "
            f"p.Quantity, p.ReorderLevel, p.Unit, p.Description, p.CreatedAt, p.UpdatedAt, {self._status()} AS Status "
            "FROM Products p LEFT JOIN Categories c ON c.CategoryID = p.CategoryID LEFT JOIN Suppliers s ON s.SupplierID = p.SupplierID "
            "WHERE p.ProductID = ? AND p.StoreID = ? AND p.IsDeleted = 0", (product_id, store_id))
        if row is None:
            raise _gone("product")
        row["Transactions"] = self.db.query(
            "SELECT TOP 5 TransactionID, TransactionType, QuantityChanged, PreviousQuantity, NewQuantity, TransactionDate "
            "FROM StockTransactions WHERE ProductID = ? ORDER BY TransactionID DESC", (product_id,))
        return row

    # ---------------------------------------------------------------- validation
    def _money(self, text: str, field: str, label: str, required: bool) -> Decimal:
        text = (text or "").strip().replace(",", ".")
        if not text:
            if required:
                raise field_error(field, f"{label} is empty.", "This price is required.", [f"Type the {label.lower()} as a number such as 45.00."])
            return Decimal("0.00")
        try:
            value = Decimal(text)
        except InvalidOperation:
            raise field_error(field, f"{label} is not a number.", f"'{text}' contains letters or symbols.", [f"Type digits only, for example 45 or 45.50 (no currency symbol)."])
        if value < 0 or value > MAX_MONEY or not value.is_finite():
            raise field_error(field, f"{label} is out of range.", "Prices cannot be negative or enormous.", ["Type zero or a positive amount below 999,999,999,999."])
        return value.quantize(Decimal("0.01"))

    def _count(self, text: str, field: str, label: str) -> int:
        text = (text or "").strip()
        try:
            value = int(text)
        except ValueError:
            raise field_error(field, f"{label} must be a whole number.", f"'{text}' is not a whole number.", ["Type digits only, such as 0, 10 or 250."])
        if value < 0 or value > MAX_INT:
            raise field_error(field, f"{label} is out of range.", "It cannot be negative.", ["Type 0 or a positive whole number."])
        return value

    def validate(self, data: dict) -> dict:
        get = self.settings.get
        name = data["name"].strip()
        sku = data["sku"].strip()
        if get("inventory.sku_uppercase"):
            sku = sku.upper()
        if not name:
            raise field_error("name", "Product name is empty.", "Every product needs a name.", ["Type a name such as 'USB-C hub 7-in-1'."])
        if len(name) > 200:
            raise field_error("name", "Product name is too long.", "The limit is 200 characters.", ["Shorten the name."])
        if not sku:
            raise field_error("sku", "SKU is empty.", "Every product needs a unique SKU.", ["Type a code such as ELC-004, or click Suggest."])
        if len(sku) > 60 or re.search(r"\s", sku):
            raise field_error("sku", "That SKU is not valid.", "SKUs are up to 60 characters with no spaces.", ["Use letters, digits and dashes only, e.g. ELC-004."])
        if get("inventory.require_category") and not data.get("category_id"):
            raise field_error("category", "Choose a category.", "Your store settings require one.", ["Pick a category. None listed? Open Categories > Add category first."])
        if get("inventory.require_supplier") and not data.get("supplier_id"):
            raise field_error("supplier", "Choose a supplier.", "Your store settings require one.", ["Pick a supplier. None listed? Open Suppliers > Add supplier first."])
        if get("inventory.require_description") and not data.get("description", "").strip():
            raise field_error("description", "Description is empty.", "Your store settings require one.", ["Type a short description of the product."])
        unit = (data.get("unit") or "").strip() or get("inventory.default_unit")
        return {"name": name, "sku": sku, "category_id": data.get("category_id") or None, "supplier_id": data.get("supplier_id") or None,
                "cost": self._money(data["cost"], "cost", "Unit cost", True),
                "price": self._money(data["price"], "price", "Selling price", bool(get("inventory.require_selling_price"))),
                "reorder": self._count(data["reorder"], "reorder", "Reorder level"),
                "quantity": self._count(data.get("quantity") or "0", "quantity", "Opening stock") if "quantity" in data else None,
                "unit": unit[:30], "description": data.get("description", "").strip() or None}

    def _check_refs(self, tx, store_id: int, clean: dict) -> None:
        if clean["category_id"] and not tx.query_one("SELECT 1 AS x FROM Categories WHERE CategoryID = ? AND StoreID = ?", (clean["category_id"], store_id)):
            raise field_error("category", "That category no longer exists.", "It was deleted or belongs to another store.", ["Pick another category from the list."])
        if clean["supplier_id"] and not tx.query_one("SELECT 1 AS x FROM Suppliers WHERE SupplierID = ? AND StoreID = ?", (clean["supplier_id"], store_id)):
            raise field_error("supplier", "That supplier no longer exists.", "It was deleted or belongs to another store.", ["Pick another supplier from the list."])

    def _check_sku(self, tx, store_id: int, sku: str, product_id: int | None) -> None:
        if tx.query_one("SELECT ProductID FROM Products WHERE StoreID = ? AND SKU = ? AND IsDeleted = 0 AND (? IS NULL OR ProductID <> ?)",
                        (store_id, sku, product_id, product_id)):
            raise field_error("sku", f"The SKU '{sku}' is already used.", "SKUs must be unique within a store.",
                              ["Change the SKU (for example add the next number), or edit the existing product instead."], "DUPLICATE")

    # ---------------------------------------------------------------- writing
    def create(self, session, data: dict) -> int:
        store_id = session.active_store_id
        clean = self.validate(data)
        qty = clean["quantity"] or 0
        with self.db.transaction() as tx:
            self._check_refs(tx, store_id, clean)
            self._check_sku(tx, store_id, clean["sku"], None)
            product_id = tx.scalar(
                "INSERT INTO Products (StoreID, ProductName, SKU, CategoryID, SupplierID, PurchasePrice, SellingPrice, Quantity, ReorderLevel, Unit, Description) "
                "OUTPUT INSERTED.ProductID VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (store_id, clean["name"], clean["sku"], clean["category_id"], clean["supplier_id"], clean["cost"], clean["price"], qty,
                 clean["reorder"], clean["unit"], clean["description"]))
            if qty > 0:  # opening stock is recorded as a transaction so history always adds up
                tx.execute("INSERT INTO StockTransactions (StoreID, ProductID, TransactionType, QuantityChanged, PreviousQuantity, NewQuantity, "
                           "UnitCost, Reference, Notes, UserID) VALUES (?, ?, 'Stock In', ?, 0, ?, ?, 'OPENING', 'Opening stock when the product was created', ?)",
                           (store_id, product_id, qty, qty, clean["cost"], session.user_id))
        return product_id

    def update(self, session, product_id: int, data: dict) -> None:
        store_id = session.active_store_id
        clean = self.validate(data)
        with self.db.transaction() as tx:
            self._check_refs(tx, store_id, clean)
            self._check_sku(tx, store_id, clean["sku"], product_id)
            if tx.execute(
                    "UPDATE Products SET ProductName = ?, SKU = ?, CategoryID = ?, SupplierID = ?, PurchasePrice = ?, SellingPrice = ?, ReorderLevel = ?, "
                    "Unit = ?, Description = ?, UpdatedAt = SYSUTCDATETIME() WHERE ProductID = ? AND StoreID = ? AND IsDeleted = 0",
                    (clean["name"], clean["sku"], clean["category_id"], clean["supplier_id"], clean["cost"], clean["price"], clean["reorder"],
                     clean["unit"], clean["description"], product_id, store_id)) == 0:
                raise _gone("product")

    def delete(self, session, product_id: int) -> dict:
        with self.db.transaction() as tx:
            row = tx.query_one("SELECT ProductName, SKU, Quantity, PurchasePrice FROM Products WHERE ProductID = ? AND StoreID = ? AND IsDeleted = 0",
                               (product_id, session.active_store_id))
            if row is None:
                raise _gone("product")
            tx.execute("UPDATE Products SET IsDeleted = 1, DeletedAt = SYSUTCDATETIME(), UpdatedAt = SYSUTCDATETIME() WHERE ProductID = ?", (product_id,))
        return row
