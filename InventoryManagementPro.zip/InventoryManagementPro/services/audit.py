"""Audit trail. Logging never raises: a failed audit write must not block the user's real action."""
from __future__ import annotations


class AuditService:
    def __init__(self, db, settings) -> None:
        self.db, self.settings = db, settings

    def log(self, action: str, session=None, entity: str | None = None, entity_id=None,
            details: str | None = None, username: str | None = None, force: bool = False) -> None:
        try:
            if not force and not self.settings.get("audit.enabled"):
                return
            user_id = session.user_id if session else None
            name = session.user["Username"] if session else username
            store_id = session.active_store_id if session and session.active_store_id else None
            self.db.execute(
                "INSERT INTO AuditLog (UserID, Username, StoreID, Action, Entity, EntityID, Details) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (user_id, name, store_id, action[:60], entity, None if entity_id is None else str(entity_id)[:60],
                 (details or "")[:1000] or None))
        except Exception:
            pass

    def actions(self) -> list[str]:
        return [r["Action"] for r in self.db.query("SELECT DISTINCT Action FROM AuditLog ORDER BY Action")]

    def search(self, session, text: str = "", action: str = "", limit: int = 50, offset: int = 0):
        where, params = ["1 = 1"], []
        if not session.is_super:
            where.append("StoreID = ?")
            params.append(session.active_store_id)
        if text:
            where.append("(Username LIKE ? OR Details LIKE ? OR Entity LIKE ?)")
            params += [f"%{text}%"] * 3
        if action:
            where.append("Action = ?")
            params.append(action)
        clause = " AND ".join(where)
        total = self.db.scalar(f"SELECT COUNT(*) FROM AuditLog WHERE {clause}", params)
        rows = self.db.query(
            f"SELECT AuditID, Username, Action, Entity, EntityID, Details, CreatedAt FROM AuditLog WHERE {clause} "
            "ORDER BY AuditID DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY", params + [offset, limit])
        return rows, total

    def purge_old(self, days: int) -> None:
        if days > 0:
            try:
                self.db.execute("DELETE FROM AuditLog WHERE CreatedAt < DATEADD(DAY, ?, SYSUTCDATETIME())", (-days,))
            except Exception:
                pass
