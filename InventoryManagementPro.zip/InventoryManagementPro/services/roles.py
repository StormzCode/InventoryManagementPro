"""Permission catalog sync, built-in roles and custom role management."""
from __future__ import annotations

from core.errors import user_error
from core.permissions import ALL_CODES, PERMISSIONS, SYSTEM_ROLES


class RoleService:
    def __init__(self, db) -> None:
        self.db = db

    def sync_catalog(self) -> None:
        """Make the Permissions table and the built-in roles match the code. Custom roles are untouched."""
        with self.db.transaction() as tx:
            known = {r["PermissionCode"] for r in tx.query("SELECT PermissionCode FROM Permissions")}
            for code, group, description in PERMISSIONS:
                if code in known:
                    tx.execute("UPDATE Permissions SET GroupName = ?, Description = ? WHERE PermissionCode = ?",
                               (group, description, code))
                else:
                    tx.execute("INSERT INTO Permissions (PermissionCode, GroupName, Description) VALUES (?, ?, ?)",
                               (code, group, description))
            for role in SYSTEM_ROLES:
                row = tx.query_one("SELECT RoleID FROM Roles WHERE RoleName = ?", (role.name,))
                if row is None:
                    role_id = tx.scalar("INSERT INTO Roles (RoleName, Description, RankLevel, IsSystem) "
                                        "OUTPUT INSERTED.RoleID VALUES (?, ?, ?, 1)",
                                        (role.name, role.description, role.rank))
                else:
                    role_id = row["RoleID"]
                    tx.execute("UPDATE Roles SET Description = ?, RankLevel = ?, IsSystem = 1 WHERE RoleID = ?",
                               (role.description, role.rank, role_id))
                have = {r["PermissionCode"] for r in
                        tx.query("SELECT PermissionCode FROM RolePermissions WHERE RoleID = ?", (role_id,))}
                for code in role.permissions - have:
                    tx.execute("INSERT INTO RolePermissions (RoleID, PermissionCode) VALUES (?, ?)", (role_id, code))
                for code in have - role.permissions:
                    tx.execute("DELETE FROM RolePermissions WHERE RoleID = ? AND PermissionCode = ?", (role_id, code))

    def list_roles(self) -> list[dict]:
        return self.db.query(
            "SELECT r.RoleID, r.RoleName, r.Description, r.RankLevel, r.IsSystem, "
            "(SELECT COUNT(*) FROM RolePermissions p WHERE p.RoleID = r.RoleID) AS PermCount, "
            "(SELECT COUNT(*) FROM UserStoreRoles u WHERE u.RoleID = r.RoleID) AS UserCount "
            "FROM Roles r ORDER BY r.RankLevel, r.RoleName")

    def permissions_of(self, role_id: int) -> set[str]:
        return {r["PermissionCode"] for r in
                self.db.query("SELECT PermissionCode FROM RolePermissions WHERE RoleID = ?", (role_id,))}

    def save_role(self, role_id: int | None, name: str, description: str, rank: int, permissions: set[str]) -> int:
        name = name.strip()
        if not name:
            raise user_error("Role name is empty.", "Every role needs a name.",
                             ["Type a name such as 'Night Shift Clerk' in the Role name box."])
        if not permissions:
            raise user_error("No permissions selected.", "A role with no permissions could not open any page.",
                             ["Tick at least one permission (start with 'Open settings' and 'See products')."])
        if not permissions <= ALL_CODES:
            raise user_error("Unknown permission.", "The role contains a permission this version does not know.",
                             ["Close the dialog, reopen it and tick the permissions again."])
        with self.db.transaction() as tx:
            clash = tx.query_one("SELECT RoleID FROM Roles WHERE RoleName = ? AND (? IS NULL OR RoleID <> ?)",
                                 (name, role_id, role_id))
            if clash:
                raise user_error(f"A role named '{name}' already exists.", "Role names must be unique.",
                                 ["Choose a different role name, e.g. add the store or shift to it."])
            if role_id is None:
                role_id = tx.scalar("INSERT INTO Roles (RoleName, Description, RankLevel, IsSystem) "
                                    "OUTPUT INSERTED.RoleID VALUES (?, ?, ?, 0)", (name, description, rank))
            else:
                if tx.scalar("SELECT IsSystem FROM Roles WHERE RoleID = ?", (role_id,)):
                    raise user_error("Built-in roles cannot be edited.",
                                     "Administrator, Manager, Stock Clerk, Auditor and Viewer are fixed.",
                                     ["Click 'New role', tick the permissions you want, and give it your own name."])
                tx.execute("UPDATE Roles SET RoleName = ?, Description = ?, RankLevel = ? WHERE RoleID = ?",
                           (name, description, rank, role_id))
                tx.execute("DELETE FROM RolePermissions WHERE RoleID = ?", (role_id,))
            for code in sorted(permissions):
                tx.execute("INSERT INTO RolePermissions (RoleID, PermissionCode) VALUES (?, ?)", (role_id, code))
        return role_id

    def delete_role(self, role_id: int) -> None:
        with self.db.transaction() as tx:
            role = tx.query_one("SELECT RoleName, IsSystem FROM Roles WHERE RoleID = ?", (role_id,))
            if role is None:
                return
            if role["IsSystem"]:
                raise user_error("Built-in roles cannot be deleted.", "They are required by the application.",
                                 ["Leave it as is. Only roles you created can be deleted."])
            in_use = tx.scalar("SELECT COUNT(*) FROM UserStoreRoles WHERE RoleID = ?", (role_id,))
            if in_use:
                raise user_error(f"'{role['RoleName']}' is still assigned to {in_use} user(s).",
                                 "Deleting it would leave those users without access.",
                                 ["Open Users, edit each user that has this role and pick a different role.",
                                  "Then delete the role again."])
            tx.execute("DELETE FROM Roles WHERE RoleID = ?", (role_id,))
