"""User and store administration with per-store permission scoping."""
from __future__ import annotations

from core.errors import user_error
from core.security import hash_password


class UserService:
    def __init__(self, db, auth) -> None:
        self.db, self.auth = db, auth

    # ---------------------------------------------------------------- listing
    def list_users(self, session) -> list[dict]:
        users = self.db.query("SELECT UserID, Username, FullName, Email, IsSuperAdmin, IsActive, LastLoginAt, CreatedAt "
                              "FROM Users ORDER BY FullName")
        assignments = self.db.query(
            "SELECT usr.UserID, usr.StoreID, s.StoreName, usr.RoleID, r.RoleName FROM UserStoreRoles usr "
            "JOIN Stores s ON s.StoreID = usr.StoreID JOIN Roles r ON r.RoleID = usr.RoleID ORDER BY s.StoreName")
        by_user: dict[int, list[dict]] = {}
        for a in assignments:
            by_user.setdefault(a["UserID"], []).append(a)
        visible_stores = {a.store_id for a in session.stores_where("users.view")}
        result = []
        for u in users:
            mine = by_user.get(u["UserID"], [])
            if not session.is_super and u["UserID"] != session.user_id and not any(a["StoreID"] in visible_stores for a in mine):
                continue
            u["Assignments"] = mine if session.is_super else [a for a in mine if a["StoreID"] in visible_stores]
            result.append(u)
        return result

    def assignments_of(self, user_id: int) -> dict[int, int]:
        return {r["StoreID"]: r["RoleID"] for r in
                self.db.query("SELECT StoreID, RoleID FROM UserStoreRoles WHERE UserID = ?", (user_id,))}

    def assignable_roles(self, session, store_id: int) -> list[dict]:
        """Roles the signed-in person may give in a store: same rank or weaker than their own."""
        roles = self.db.query("SELECT RoleID, RoleName, RankLevel FROM Roles ORDER BY RankLevel, RoleName")
        limit = session.best_rank(store_id)
        return [r for r in roles if r["RankLevel"] >= limit]

    # ---------------------------------------------------------------- create / edit
    def create_user(self, session, data: dict, assignments: dict[int, int | None]) -> int:
        self.auth.validate_profile(data["full_name"], data["username"], data["email"])
        self.auth.check_new_password(data["password"], data["confirm"])
        self._check_assignable(session, assignments)
        if data.get("is_super") and not session.is_super:
            raise user_error("Only a super administrator can create another one.", "Super administrators see every store.",
                             ["Untick 'Super administrator' or ask the existing super administrator to do this."])
        if not data.get("is_super") and not any(assignments.values()):
            raise user_error("No store access was chosen.", "A user without any role could not sign in.",
                             ["In 'Store access' pick a role for at least one store."])
        digest, salt, iterations = hash_password(data["password"])
        with self.db.transaction() as tx:
            if tx.query_one("SELECT 1 AS x FROM Users WHERE Username = ?", (data["username"].strip(),)):
                raise user_error(f"The username '{data['username'].strip()}' is taken.", "Usernames must be unique.",
                                 ["Pick another username, e.g. add a number or the person's initials."])
            user_id = tx.scalar(
                "INSERT INTO Users (Username, FullName, Email, PasswordHash, PasswordSalt, PasswordIterations, "
                "MustChangePassword, IsSuperAdmin, IsActive) OUTPUT INSERTED.UserID VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (data["username"].strip(), data["full_name"].strip(), data["email"].strip() or None, digest, salt,
                 iterations, 1 if data.get("must_change") else 0, 1 if data.get("is_super") else 0,
                 1 if data.get("is_active", True) else 0))
            for store_id, role_id in assignments.items():
                if role_id:
                    tx.execute("INSERT INTO UserStoreRoles (UserID, StoreID, RoleID) VALUES (?, ?, ?)",
                               (user_id, store_id, role_id))
        return user_id

    def update_user(self, session, user_id: int, data: dict, assignments: dict[int, int | None]) -> None:
        self.auth.validate_profile(data["full_name"], data.get("username", "valid.user"), data["email"])
        self._guard_target(session, user_id, "users.edit")
        self._check_assignable(session, assignments)
        if not session.is_super and data.get("is_super"):
            raise user_error("Only a super administrator can grant that.", "Super administrators see every store.",
                             ["Untick 'Super administrator'."])
        with self.db.transaction() as tx:
            current = tx.query_one("SELECT IsSuperAdmin, IsActive FROM Users WHERE UserID = ?", (user_id,))
            if current is None:
                raise user_error("That user no longer exists.", "Someone else removed it.", ["Close the dialog and refresh the list."])
            is_super = bool(data.get("is_super")) if session.is_super else bool(current["IsSuperAdmin"])
            if current["IsSuperAdmin"] and not is_super:
                others = tx.scalar("SELECT COUNT(*) FROM Users WHERE IsSuperAdmin = 1 AND IsActive = 1 AND UserID <> ?", (user_id,))
                if not others:
                    raise user_error("This is the last super administrator.", "Without one nobody could manage all stores.",
                                     ["Make another user a super administrator first, then remove it here."])
            tx.execute("UPDATE Users SET FullName = ?, Email = ?, IsSuperAdmin = ? WHERE UserID = ?",
                       (data["full_name"].strip(), data["email"].strip() or None, 1 if is_super else 0, user_id))
            for store_id, role_id in assignments.items():  # only stores the actor may manage are passed in
                tx.execute("DELETE FROM UserStoreRoles WHERE UserID = ? AND StoreID = ?", (user_id, store_id))
                if role_id:
                    tx.execute("INSERT INTO UserStoreRoles (UserID, StoreID, RoleID) VALUES (?, ?, ?)", (user_id, store_id, role_id))
            if not is_super and not tx.scalar("SELECT COUNT(*) FROM UserStoreRoles WHERE UserID = ?", (user_id,)):
                raise user_error("That would leave the user with no store access.", "They could no longer sign in.",
                                 ["Keep a role in at least one store, or use Disable if you want to block the account."])

    def _guard_target(self, session, user_id: int, permission: str) -> None:
        """A non-super admin may only touch ordinary users who share a store where they hold `permission`."""
        if session.is_super or user_id == session.user_id and permission == "users.edit":
            return
        row = self.db.query_one("SELECT IsSuperAdmin FROM Users WHERE UserID = ?", (user_id,))
        if row is None:
            raise user_error("That user no longer exists.", "Someone else removed it.", ["Close the dialog and refresh the list."])
        if row["IsSuperAdmin"]:
            raise user_error("Only a super administrator can change this account.", "It controls every store.",
                             ["Ask a super administrator to make this change."])
        mine = {a.store_id for a in session.stores_where(permission)}
        if not mine & set(self.assignments_of(user_id)):
            raise user_error("You cannot manage this user.", f"They have no role in a store where you hold '{permission}'.",
                             ["Switch to a store you share with them (sidebar store switcher), or ask their store's administrator."])

    def _check_assignable(self, session, assignments: dict[int, int | None]) -> None:
        for store_id, role_id in assignments.items():
            if not role_id:
                continue
            if not session.can("users.assign_roles", store_id):
                raise user_error("You cannot give roles in that store.", "Your role there lacks 'Give users roles'.",
                                 ["Ask an administrator of that store to do this, or leave that store as 'No access'."])
            allowed = {r["RoleID"] for r in self.assignable_roles(session, store_id)}
            if role_id not in allowed:
                raise user_error("You cannot give a role stronger than your own.", "That prevents privilege escalation.",
                                 ["Pick a role with the same or fewer permissions than yours."])

    # ---------------------------------------------------------------- status & passwords
    def set_active(self, session, user_id: int, active: bool) -> None:
        if user_id == session.user_id and not active:
            raise user_error("You cannot disable your own account.", "You would lock yourself out.",
                             ["Ask another administrator to do it, or just sign out."])
        self._guard_target(session, user_id, "users.deactivate")
        with self.db.transaction() as tx:
            row = tx.query_one("SELECT IsSuperAdmin FROM Users WHERE UserID = ?", (user_id,))
            if row and row["IsSuperAdmin"] and not active:
                others = tx.scalar("SELECT COUNT(*) FROM Users WHERE IsSuperAdmin = 1 AND IsActive = 1 AND UserID <> ?", (user_id,))
                if not others:
                    raise user_error("This is the last active super administrator.", "Disabling it would lock everyone out of administration.",
                                     ["Create or enable another super administrator first."])
            tx.execute("UPDATE Users SET IsActive = ?, FailedAttempts = 0, LockedUntil = NULL WHERE UserID = ?",
                       (1 if active else 0, user_id))

    def reset_password(self, session, user_id: int, new: str, confirm: str, must_change: bool) -> None:
        self._guard_target(session, user_id, "users.reset_password")
        self.auth.check_new_password(new, confirm)
        self.auth.set_password(user_id, new, must_change)


class StoreService:
    def __init__(self, db, settings) -> None:
        self.db, self.settings = db, settings

    def list_stores(self, session) -> list[dict]:
        rows = self.db.query(
            "SELECT s.StoreID, s.StoreName, s.City, s.Country, s.Phone, s.Address, s.IsActive, "
            "(SELECT COUNT(*) FROM UserStoreRoles u WHERE u.StoreID = s.StoreID) AS UserCount "
            "FROM Stores s ORDER BY s.StoreName")
        if session.is_super:
            return rows
        visible = {a.store_id for a in session.stores_where("stores.view")}
        return [r for r in rows if r["StoreID"] in visible]

    def save_store(self, session, store_id: int | None, data: dict) -> int:
        name = data["name"].strip()
        if not name:
            raise user_error("Store name is empty.", "Every store needs a name.", ["Type a name such as 'Jeddah branch'."])
        with self.db.transaction() as tx:
            clash = tx.query_one("SELECT StoreID FROM Stores WHERE StoreName = ? AND (? IS NULL OR StoreID <> ?)", (name, store_id, store_id))
            if clash:
                raise user_error(f"A store named '{name}' already exists.", "Store names must be unique.", ["Choose a different name."])
            values = (name, data["city"].strip() or None, data["country"].strip() or None,
                      data["phone"].strip() or None, data["address"].strip() or None)
            if store_id is None:
                store_id = tx.scalar("INSERT INTO Stores (StoreName, City, Country, Phone, Address) OUTPUT INSERTED.StoreID "
                                     "VALUES (?, ?, ?, ?, ?)", values)
                admin_role = tx.scalar("SELECT RoleID FROM Roles WHERE RoleName = 'Administrator'")
                if not session.is_super and admin_role:  # creator becomes administrator of the new store
                    tx.execute("INSERT INTO UserStoreRoles (UserID, StoreID, RoleID) VALUES (?, ?, ?)",
                               (session.user_id, store_id, admin_role))
                tx.execute("INSERT INTO Settings (Scope, ScopeID, SettingKey, SettingValue) VALUES ('store', ?, 'regional.currency_symbol', ?)",
                           (store_id, self.settings.get("regional.currency_symbol")))
            else:
                tx.execute("UPDATE Stores SET StoreName = ?, City = ?, Country = ?, Phone = ?, Address = ? WHERE StoreID = ?",
                           values + (store_id,))
        return store_id

    def set_active(self, store_id: int, active: bool) -> None:
        with self.db.transaction() as tx:
            if not active:
                others = tx.scalar("SELECT COUNT(*) FROM Stores WHERE IsActive = 1 AND StoreID <> ?", (store_id,))
                if not others:
                    raise user_error("This is the only active store.", "The app needs at least one active store.",
                                     ["Create or activate another store first, then deactivate this one."])
            tx.execute("UPDATE Stores SET IsActive = ? WHERE StoreID = ?", (1 if active else 0, store_id))
