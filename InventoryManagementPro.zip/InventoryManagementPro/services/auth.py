"""Sign-in, lockout, password policy, first-run setup and session building."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

from core.errors import user_error
from core.permissions import ALL_CODES, SUPER_ROLE_NAME, Session, StoreAccess
from core.security import (hash_password, is_valid_email, is_valid_username, password_problems,
                           verify_password)

_DUMMY = None  # lazily computed hash so unknown usernames take as long as wrong passwords


@dataclass
class LoginResult:
    ok: bool
    user: dict | None = None
    message: str = ""
    fix: str = ""
    must_change_password: bool = False


class AuthService:
    def __init__(self, db, settings, audit, roles) -> None:
        self.db, self.settings, self.audit, self.roles = db, settings, audit, roles

    # ---------------------------------------------------------------- policy
    def policy_errors(self, password: str) -> list[str]:
        g = self.settings.get
        return password_problems(password, g("security.min_password_length"), g("security.require_upper"),
                                 g("security.require_digit"), g("security.require_symbol"))

    def check_new_password(self, password: str, confirm: str) -> None:
        problems = self.policy_errors(password)
        if problems:
            raise user_error("That password is too weak.", "It does not meet the password rules.",
                             [p[0].upper() + p[1:] + "." for p in problems], "PASSWORD_POLICY")
        if password != confirm:
            raise user_error("The two passwords are different.", "Password and Confirm password must match.",
                             ["Retype the same password in both boxes."], "PASSWORD_MISMATCH")

    # ---------------------------------------------------------------- queries
    def has_users(self) -> bool:
        return (self.db.scalar("SELECT COUNT(*) FROM Users") or 0) > 0

    def validate_profile(self, full_name: str, username: str, email: str) -> None:
        if not full_name.strip():
            raise user_error("Full name is empty.", "Every user needs a display name.",
                             ["Type the person's full name, e.g. Omar Alharbi."])
        if not is_valid_username(username.strip()):
            raise user_error("The username is not valid.", "Usernames are 3-40 characters: letters, digits, dot, dash, underscore.",
                             ["Type something like omar.a (no spaces or special characters)."])
        if email.strip() and not is_valid_email(email.strip()):
            raise user_error("The email address looks wrong.", "It must look like name@company.com.",
                             ["Fix the email, or clear the box to leave it empty."])

    def create_first_admin(self, store_name: str, city: str, symbol: str, full_name: str, username: str,
                           email: str, password: str, confirm: str) -> None:
        if not store_name.strip():
            raise user_error("Store name is empty.", "The first store needs a name.",
                             ["Type your store or company name, e.g. Riyadh workspace."])
        self.validate_profile(full_name, username, email)
        self.check_new_password(password, confirm)
        digest, salt, iterations = hash_password(password)
        with self.db.transaction() as tx:
            if tx.scalar("SELECT COUNT(*) FROM Users") > 0:
                raise user_error("Setup was already completed.", "An administrator account exists.",
                                 ["Close this window and sign in with that account."])
            store_id = tx.scalar("INSERT INTO Stores (StoreName, City, Country) OUTPUT INSERTED.StoreID VALUES (?, ?, ?)",
                                 (store_name.strip(), city.strip() or None, None))
            tx.execute("INSERT INTO Users (Username, FullName, Email, PasswordHash, PasswordSalt, PasswordIterations, "
                       "IsSuperAdmin) VALUES (?, ?, ?, ?, ?, ?, 1)",
                       (username.strip(), full_name.strip(), email.strip() or None, digest, salt, iterations))
            tx.execute("INSERT INTO Settings (Scope, ScopeID, SettingKey, SettingValue) VALUES ('store', ?, ?, ?)",
                       (store_id, "regional.currency_symbol", symbol.strip() or "SAR"))
        self.audit.log("setup_completed", username=username.strip(), details=f"First store '{store_name.strip()}'",
                       force=True)

    # ---------------------------------------------------------------- sign in
    def login(self, username: str, password: str) -> LoginResult:
        global _DUMMY
        username = username.strip()
        if not username or not password:
            return LoginResult(False, message="Type your username and password.",
                               fix="Fill in both boxes, then press Sign in.")
        now = self.db.scalar("SELECT SYSUTCDATETIME()")
        row = self.db.query_one("SELECT * FROM Users WHERE Username = ?", (username,))
        if row is None:
            if _DUMMY is None:
                _DUMMY = hash_password("not-a-real-password")
            verify_password(password, _DUMMY[0], _DUMMY[1], _DUMMY[2])
            self._log_failure(username, "unknown username")
            return LoginResult(False, message="Username or password is wrong.",
                               fix="Check Caps Lock and spelling. Forgot it? Ask an administrator to reset your password "
                                   "(Users & Access > Users > Reset password).")
        if not row["IsActive"]:
            return LoginResult(False, message="This account is disabled.",
                               fix="Ask an administrator to enable it: Users & Access > Users > Enable.")
        locked = row["LockedUntil"]
        if locked and locked > now:
            minutes = max(1, int((locked - now).total_seconds() // 60) + 1)
            return LoginResult(False, message=f"This account is locked for about {minutes} more minute(s).",
                               fix=f"Wait {minutes} minute(s) and try again, or ask an administrator to reset your password.")
        if not verify_password(password, row["PasswordHash"], row["PasswordSalt"], row["PasswordIterations"]):
            attempts = row["FailedAttempts"] + 1
            limit = self.settings.get("security.max_failed_attempts")
            if attempts >= limit:
                minutes = self.settings.get("security.lockout_minutes")
                self.db.execute("UPDATE Users SET FailedAttempts = 0, LockedUntil = DATEADD(MINUTE, ?, SYSUTCDATETIME()) "
                                "WHERE UserID = ?", (minutes, row["UserID"]))
                self._log_failure(username, f"locked for {minutes} min")
                return LoginResult(False, message=f"Too many wrong passwords. The account is locked for {minutes} minutes.",
                                   fix=f"Wait {minutes} minutes, or ask an administrator to reset your password.")
            self.db.execute("UPDATE Users SET FailedAttempts = ? WHERE UserID = ?", (attempts, row["UserID"]))
            self._log_failure(username, f"wrong password ({attempts}/{limit})")
            return LoginResult(False, message="Username or password is wrong.",
                               fix=f"Retype the password carefully. {limit - attempts} attempt(s) left before the account locks.")
        self.db.execute("UPDATE Users SET FailedAttempts = 0, LockedUntil = NULL, LastLoginAt = SYSUTCDATETIME() "
                        "WHERE UserID = ?", (row["UserID"],))
        expiry = self.settings.get("security.password_expiry_days")
        expired = bool(expiry and row["PasswordChangedAt"] + timedelta(days=expiry) < now)
        return LoginResult(True, user=row, must_change_password=bool(row["MustChangePassword"]) or expired)

    def _log_failure(self, username: str, why: str) -> None:
        if self.settings.get("security.log_sign_ins"):
            self.audit.log("login_failed", username=username, details=why)

    def build_session(self, user_id: int, preferred_store: int | None = None) -> Session:
        user = self.db.query_one("SELECT * FROM Users WHERE UserID = ?", (user_id,))
        if user is None or not user["IsActive"]:
            raise user_error("This account is no longer active.", "It was disabled or removed while you were signed in.",
                             ["Ask an administrator to enable your account, then sign in again."])
        accesses: dict[int, StoreAccess] = {}
        if user["IsSuperAdmin"]:
            for s in self.db.query("SELECT StoreID, StoreName FROM Stores WHERE IsActive = 1 ORDER BY StoreName"):
                accesses[s["StoreID"]] = StoreAccess(s["StoreID"], s["StoreName"], None, SUPER_ROLE_NAME, 0, ALL_CODES)
        else:
            perms: dict[int, set[str]] = {}
            for p in self.db.query("SELECT RoleID, PermissionCode FROM RolePermissions"):
                perms.setdefault(p["RoleID"], set()).add(p["PermissionCode"])
            for r in self.db.query(
                    "SELECT usr.StoreID, s.StoreName, usr.RoleID, r.RoleName, r.RankLevel FROM UserStoreRoles usr "
                    "JOIN Stores s ON s.StoreID = usr.StoreID JOIN Roles r ON r.RoleID = usr.RoleID "
                    "WHERE usr.UserID = ? AND s.IsActive = 1 ORDER BY s.StoreName", (user_id,)):
                accesses[r["StoreID"]] = StoreAccess(r["StoreID"], r["StoreName"], r["RoleID"], r["RoleName"],
                                                     r["RankLevel"], frozenset(perms.get(r["RoleID"], set())))
        if not accesses:
            raise user_error("You have no store access.", "Your account is active but has no role in any active store.",
                             ["Ask an administrator to open Users & Access > Users > Edit and pick a role for you in a store.",
                              "If you are the administrator, sign in with the super administrator account created at setup."])
        store_id = preferred_store if preferred_store in accesses else next(iter(accesses))
        return Session(user=user, accesses=accesses, active_store_id=store_id)

    def check_password(self, user_id: int, password: str) -> bool:
        row = self.db.query_one("SELECT PasswordHash, PasswordSalt, PasswordIterations FROM Users WHERE UserID = ?", (user_id,))
        return bool(row and verify_password(password, row["PasswordHash"], row["PasswordSalt"], row["PasswordIterations"]))

    # ---------------------------------------------------------------- passwords
    def change_own_password(self, user_id: int, current: str, new: str, confirm: str) -> None:
        row = self.db.query_one("SELECT PasswordHash, PasswordSalt, PasswordIterations FROM Users WHERE UserID = ?", (user_id,))
        if row is None or not verify_password(current, row["PasswordHash"], row["PasswordSalt"], row["PasswordIterations"]):
            raise user_error("Current password is wrong.", "The password you typed does not match your account.",
                             ["Retype your current password. If you forgot it, sign out and ask an administrator to reset it."])
        self.check_new_password(new, confirm)
        if new == current:
            raise user_error("The new password is the same as the old one.", "Choosing a different password is required.",
                             ["Type a password you have not used for this account."])
        self.set_password(user_id, new, must_change=False)

    def set_password(self, user_id: int, new: str, must_change: bool) -> None:
        digest, salt, iterations = hash_password(new)
        self.db.execute("UPDATE Users SET PasswordHash = ?, PasswordSalt = ?, PasswordIterations = ?, "
                        "PasswordChangedAt = SYSUTCDATETIME(), MustChangePassword = ?, FailedAttempts = 0, LockedUntil = NULL "
                        "WHERE UserID = ?", (digest, salt, iterations, 1 if must_change else 0, user_id))
