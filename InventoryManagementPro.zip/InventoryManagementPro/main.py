"""Inventory Management Pro - entry point. Run:  python main.py"""
import sys
import tkinter as tk
from tkinter import messagebox


def _missing(package: str) -> None:
    text = (f"The Python package '{package}' is not installed.\n\nHow to fix it:\n"
            "  1. Open the VS Code terminal (Ctrl+`) in this project folder.\n"
            "  2. Run:  pip install -r requirements.txt\n"
            "  3. Run:  python main.py again.\n\n"
            "If 'pip' is not recognised, use:  python -m pip install -r requirements.txt")
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Missing package", text)
    except tk.TclError:
        print(text)
    sys.exit(1)


def main() -> None:
    for module, package in (("customtkinter", "customtkinter"), ("pyodbc", "pyodbc")):
        try:
            __import__(module)
        except ImportError:
            _missing(package)
    from application import InventoryApp
    InventoryApp().mainloop()


if __name__ == "__main__":
    main()
