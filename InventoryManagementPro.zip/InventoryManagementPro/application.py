"""InventoryApp: owns the window, services, session, theming, background work and screen switching."""
from __future__ import annotations

import queue
import threading
import time
import tkinter as tk

import customtkinter as ctk

from core.config import APP_NAME, ConfigError, DbConfig, LocalState, load_db_config
from core.errors import config_guidance, guidance_of
from core.formatting import Formatter
from core.settings_registry import REGISTRY
from database import Database
from services.audit import AuditService
from services.catalog import CategoryService, ProductService, SupplierService
from services.auth import AuthService
from services.roles import RoleService
from services.settings import SettingsService
from services.users import StoreService, UserService
from ui.login import ChangePasswordDialog, LoginScreen, SetupScreen, StartupErrorScreen
from ui.pages import NAV_ORDER, build_registry
from ui.shell import MainShell
from ui.theme import UIContext
from ui.widgets import ToastManager, ask_confirm, show_guidance

APPEARANCE_PREFIXES = ("appearance.",)
APPEARANCE_KEYS = {"window.always_on_top", "window.opacity"}


class InventoryApp(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.minsize(1000, 650)
        self.local = LocalState()
        self.geometry(self.local.get("geometry") or "1250x800")
        self.ui = UIContext()
        self.session = None
        self.shell: MainShell | None = None
        self.collapsed_override: bool | None = None
        self._queue: queue.Queue = queue.Queue()
        self._last_activity = time.monotonic()
        self._startup_guidance = None
        try:
            config = load_db_config()
        except ConfigError as exc:
            config = DbConfig()
            self._startup_guidance = config_guidance(str(exc))
        self.db = Database(config)
        self.settings = SettingsService(self.db)
        self.audit = AuditService(self.db, self.settings)
        self.roles = RoleService(self.db)
        self.auth = AuthService(self.db, self.settings, self.audit, self.roles)
        self.users = UserService(self.db, self.auth)
        self.stores = StoreService(self.db, self.settings)
        self.categories = CategoryService(self.db, self.settings)
        self.suppliers = SupplierService(self.db, self.settings)
        self.products = ProductService(self.db, self.settings)
        self.page_memory: dict = {}
        self.fmt = Formatter(self.settings.get)
        self.pages = build_registry()
        self.apply_look()
        self.toasts = ToastManager(self)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        for sequence in ("<Key>", "<Button>", "<Motion>"):
            self.bind_all(sequence, self._touch, add="+")
        self.after(40, self._poll)
        self.after(15000, self._idle_check)
        self.start()

    # ---------------------------------------------------------------- appearance
    def _value(self, key: str):
        return self.settings.get(key) if self.session else REGISTRY[key].default

    def apply_look(self) -> None:
        theme = self.settings.get("appearance.theme") if self.session else self.local.get("theme", "Light")
        get = self._value
        pct = lambda text: int(str(text).rstrip("%")) / 100
        ctk.set_widget_scaling(pct(get("appearance.ui_scaling")))
        self.ui.configure(theme, get("appearance.accent_color"), get("appearance.font_family"),
                          pct(get("appearance.font_scale")), get("appearance.corner_radius"),
                          get("appearance.compact_mode"), get("appearance.table_row_height"),
                          get("appearance.page_padding"), get("appearance.card_borders"),
                          get("appearance.zebra_rows"), get("appearance.row_hover"),
                          get("appearance.uppercase_headers"))
        self.configure(fg_color=self.ui.pal.bg)
        if self.session:
            self.local.put(theme=theme)
        try:
            self.attributes("-topmost", bool(get("window.always_on_top")))
            self.attributes("-alpha", get("window.opacity") / 100)
        except tk.TclError:
            pass

    def on_settings_changed(self, keys: set[str]) -> None:
        if any(k.startswith(APPEARANCE_PREFIXES) or k in APPEARANCE_KEYS for k in keys):
            if "appearance.sidebar_collapsed" in keys:
                self.collapsed_override = None
            self.rebuild_ui(self.shell.current if self.shell else None)

    def rebuild_ui(self, page: str | None = None, collapsed: bool | None = None) -> None:
        if collapsed is not None:
            self.collapsed_override = collapsed
        self.apply_look()
        self._build_main(page)

    # ---------------------------------------------------------------- screens
    def _clear(self) -> None:
        self.shell = None
        for widget in self.winfo_children():
            widget.destroy()
        self.toasts.reset()

    def _splash(self, text: str) -> None:
        self._clear()
        frame = ctk.CTkFrame(self, fg_color=self.ui.pal.bg)
        frame.pack(fill="both", expand=True)
        ctk.CTkLabel(frame, text=APP_NAME, font=self.ui.font(26, True), text_color=self.ui.pal.text).place(relx=0.5, rely=0.46, anchor="center")
        ctk.CTkLabel(frame, text=text, font=self.ui.font(13), text_color=self.ui.pal.muted).place(relx=0.5, rely=0.54, anchor="center")

    def start(self) -> None:
        if self._startup_guidance:
            self.show_startup_guidance(self._startup_guidance)
            return
        self.apply_look()
        self._splash(f"Connecting to SQL Server and preparing {self.db.config.database}...")

        def work() -> bool:
            self.db.initialize()
            self.roles.sync_catalog()
            self.settings.load(0, 0)
            self.db.query_timeout = self.settings.get("system.query_timeout")
            self.audit.purge_old(self.settings.get("audit.retention_days"))
            return self.auth.has_users()

        self.run_async(work, lambda has: self.show_login() if has else self.show_setup(), self.show_startup_error)

    def show_startup_error(self, exc: BaseException) -> None:
        self.show_startup_guidance(guidance_of(exc))

    def show_startup_guidance(self, guidance) -> None:
        self._clear()
        StartupErrorScreen(self, guidance).pack(fill="both", expand=True)

    def show_login(self, message: str = "") -> None:
        self.apply_look()
        self._clear()
        LoginScreen(self, message).pack(fill="both", expand=True)

    def show_setup(self) -> None:
        self.apply_look()
        self._clear()
        SetupScreen(self).pack(fill="both", expand=True)

    def _build_main(self, page: str | None = None) -> None:
        self._clear()
        first = page or self._value("window.default_page")
        self.shell = MainShell(self, first)
        self.shell.pack(fill="both", expand=True)

    # ---------------------------------------------------------------- sign in / out
    def complete_login(self, result) -> None:
        self._splash("Loading your workspace...")

        def work():
            preferred = self.local.get("last_store")
            session = self.auth.build_session(result.user["UserID"], preferred)
            if session.active_store_id != preferred or self.settings.get("system.default_store_policy") == "First store":
                pass  # policy applied below once the user's own setting is known
            self.settings.load(session.user_id, session.active_store_id)
            if self.settings.get("system.default_store_policy") == "First store":
                first = next(iter(session.accesses))
                if first != session.active_store_id:
                    session.active_store_id = first
                    self.settings.load(session.user_id, first)
            self.db.query_timeout = self.settings.get("system.query_timeout")
            return session

        def done(session) -> None:
            self.session = session
            self.local.put(last_store=session.active_store_id)
            if self.settings.get("security.log_sign_ins"):
                self.audit.log("login", session)
            self.apply_look()
            if self.settings.get("window.start_maximized"):
                try:
                    self.state("zoomed")
                except tk.TclError:
                    pass
            self._build_main()
            if result.must_change_password:
                self.after(250, self._forced_password_change)
            self._login_stock_toast()

        def failed(exc: BaseException) -> None:
            self.show_login()
            self.show_error(exc)

        self.run_async(work, done, failed)

    def _login_stock_toast(self) -> None:
        """One summary message after sign-in when products need restocking."""
        if "products" not in self.pages or not self.session.can("products.view"):
            return
        get = self.settings.get
        if not (get("notify.low_stock_on_login") and get("notify.low_stock_alerts")):
            return
        sid = self.session.active_store_id

        def done(counts) -> None:
            low, out = counts
            parts = [f"{low} low on stock"] if low else []
            if out and get("notify.out_of_stock_alerts"):
                parts.append(f"{out} out of stock")
            if parts and self.session:
                self.toasts.show(f"{' and '.join(parts)}. Open Products and use 'Show' to see them.", "warning", "Restock needed")

        self.run_async(lambda: self.products.stock_alerts(sid), done, lambda _e: None)

    def _forced_password_change(self) -> None:
        dialog = ChangePasswordDialog(self, forced=True)
        self.wait_window(dialog)
        if not dialog.result:
            self.logout()

    def open_change_password(self) -> None:
        ChangePasswordDialog(self)

    def logout(self, reason: str = "") -> None:
        if self.session:
            self.audit.log("logout" if not reason else "auto_logout", self.session)
        self.session = None
        self.page_memory.clear()
        self._splash("Signing out...")
        self.apply_look()
        self.run_async(lambda: self.settings.load(0, 0), lambda _r: self.show_login(reason), self.show_startup_error)

    def switch_store(self, store_id: int) -> None:
        if not self.session or store_id == self.session.active_store_id:
            return
        page = self.shell.current if self.shell else None
        self.session.active_store_id = store_id
        self.local.put(last_store=store_id)

        def done(_r) -> None:
            self.audit.log("store_switched", self.session, "store", store_id)
            self.rebuild_ui(page)

        self.run_async(lambda: self.settings.load(self.session.user_id, store_id), done)

    def refresh_session(self) -> None:
        if not self.session:
            return
        user_id, store_id = self.session.user_id, self.session.active_store_id

        def done(session) -> None:
            self.session = session
            self.rebuild_ui(self.shell.current if self.shell else None)

        self.run_async(lambda: self.auth.build_session(user_id, store_id), done)

    # ---------------------------------------------------------------- errors
    def show_error(self, exc: BaseException) -> None:
        guidance = guidance_of(exc)
        self.toasts.show(f"Fix: {guidance.steps[0]}" if guidance.steps else guidance.cause, "error", guidance.title)
        show_guidance(self, guidance)

    # ---------------------------------------------------------------- background work
    def run_async(self, work, done=None, failed=None) -> None:
        def runner() -> None:
            try:
                self._queue.put((done, work(), None))
            except BaseException as exc:  # noqa: BLE001 - everything is reported to the UI thread
                self._queue.put((failed, None, exc))

        threading.Thread(target=runner, daemon=True).start()

    def _poll(self) -> None:
        try:
            while True:
                callback, result, exc = self._queue.get_nowait()
                try:
                    if exc is None:
                        if callback:
                            callback(result)
                    else:
                        (callback or self.show_error)(exc)
                except tk.TclError:
                    pass  # the widget was closed while the work was running
        except queue.Empty:
            pass
        self.after(40, self._poll)

    # ---------------------------------------------------------------- idle timeout, closing
    def _touch(self, _event=None) -> None:
        self._last_activity = time.monotonic()

    def _idle_check(self) -> None:
        interval = 15
        if self.session:
            minutes = self.settings.get("security.session_timeout_minutes")
            interval = self.settings.get("system.idle_check_seconds")
            if minutes and time.monotonic() - self._last_activity > minutes * 60:
                self.logout(f"You were signed out after {minutes} minutes without activity. Sign in again to continue.")
        self.after(int(interval * 1000), self._idle_check)

    def _on_close(self) -> None:
        if self.session and self.settings.get("window.confirm_exit"):
            if not ask_confirm(self, "Close the application?", "Any unsaved changes will be lost.", "Close"):
                return
        if self.session and self.settings.get("window.remember_size"):
            self.local.put(geometry=self.geometry().split("+")[0] if self.state() != "zoomed" else None)
        self.destroy()
