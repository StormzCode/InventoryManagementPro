/* Inventory Management Pro - schema for database InvProDB.
   Safe to run many times: every object is created only if missing.
   The app runs this automatically at startup. Batches are separated by GO. */

IF OBJECT_ID(N'dbo.SchemaVersion', N'U') IS NULL
    CREATE TABLE dbo.SchemaVersion (
        Version   INT           NOT NULL CONSTRAINT PK_SchemaVersion PRIMARY KEY,
        AppliedAt DATETIME2(0)  NOT NULL CONSTRAINT DF_SchemaVersion_At DEFAULT SYSUTCDATETIME(),
        Notes     NVARCHAR(200) NULL
    );
GO
IF OBJECT_ID(N'dbo.Stores', N'U') IS NULL
    CREATE TABLE dbo.Stores (
        StoreID   INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Stores PRIMARY KEY,
        StoreName NVARCHAR(120)     NOT NULL CONSTRAINT UQ_Stores_Name UNIQUE,
        City      NVARCHAR(80)      NULL,
        Country   NVARCHAR(80)      NULL,
        Phone     NVARCHAR(40)      NULL,
        Address   NVARCHAR(300)     NULL,
        IsActive  BIT               NOT NULL CONSTRAINT DF_Stores_Active DEFAULT 1,
        CreatedAt DATETIME2(0)      NOT NULL CONSTRAINT DF_Stores_Created DEFAULT SYSUTCDATETIME()
    );
GO
IF OBJECT_ID(N'dbo.Roles', N'U') IS NULL
    CREATE TABLE dbo.Roles (
        RoleID      INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Roles PRIMARY KEY,
        RoleName    NVARCHAR(60)      NOT NULL CONSTRAINT UQ_Roles_Name UNIQUE,
        Description NVARCHAR(250)     NULL,
        RankLevel   INT               NOT NULL CONSTRAINT DF_Roles_Rank DEFAULT 60,
        IsSystem    BIT               NOT NULL CONSTRAINT DF_Roles_System DEFAULT 0,
        CreatedAt   DATETIME2(0)      NOT NULL CONSTRAINT DF_Roles_Created DEFAULT SYSUTCDATETIME()
    );
GO
IF OBJECT_ID(N'dbo.Permissions', N'U') IS NULL
    CREATE TABLE dbo.Permissions (
        PermissionCode VARCHAR(60)   NOT NULL CONSTRAINT PK_Permissions PRIMARY KEY,
        GroupName      NVARCHAR(60)  NOT NULL,
        Description    NVARCHAR(200) NULL
    );
GO
IF OBJECT_ID(N'dbo.RolePermissions', N'U') IS NULL
    CREATE TABLE dbo.RolePermissions (
        RoleID         INT         NOT NULL CONSTRAINT FK_RolePerm_Role REFERENCES dbo.Roles(RoleID) ON DELETE CASCADE,
        PermissionCode VARCHAR(60) NOT NULL CONSTRAINT FK_RolePerm_Perm REFERENCES dbo.Permissions(PermissionCode),
        CONSTRAINT PK_RolePermissions PRIMARY KEY (RoleID, PermissionCode)
    );
GO
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
    CREATE TABLE dbo.Users (
        UserID             INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
        Username           NVARCHAR(40)      NOT NULL CONSTRAINT UQ_Users_Username UNIQUE,
        FullName           NVARCHAR(120)     NOT NULL,
        Email              NVARCHAR(200)     NULL,
        PasswordHash       VARCHAR(128)      NOT NULL,
        PasswordSalt       VARCHAR(64)       NOT NULL,
        PasswordIterations INT               NOT NULL,
        PasswordChangedAt  DATETIME2(0)      NOT NULL CONSTRAINT DF_Users_PwdAt DEFAULT SYSUTCDATETIME(),
        MustChangePassword BIT               NOT NULL CONSTRAINT DF_Users_MustChange DEFAULT 0,
        IsSuperAdmin       BIT               NOT NULL CONSTRAINT DF_Users_Super DEFAULT 0,
        IsActive           BIT               NOT NULL CONSTRAINT DF_Users_Active DEFAULT 1,
        FailedAttempts     INT               NOT NULL CONSTRAINT DF_Users_Failed DEFAULT 0,
        LockedUntil        DATETIME2(0)      NULL,
        LastLoginAt        DATETIME2(0)      NULL,
        CreatedAt          DATETIME2(0)      NOT NULL CONSTRAINT DF_Users_Created DEFAULT SYSUTCDATETIME()
    );
GO
IF OBJECT_ID(N'dbo.UserStoreRoles', N'U') IS NULL
    CREATE TABLE dbo.UserStoreRoles (
        UserID  INT NOT NULL CONSTRAINT FK_USR_User  REFERENCES dbo.Users(UserID),
        StoreID INT NOT NULL CONSTRAINT FK_USR_Store REFERENCES dbo.Stores(StoreID),
        RoleID  INT NOT NULL CONSTRAINT FK_USR_Role  REFERENCES dbo.Roles(RoleID),
        CONSTRAINT PK_UserStoreRoles PRIMARY KEY (UserID, StoreID)
    );
GO
IF OBJECT_ID(N'dbo.Categories', N'U') IS NULL
    CREATE TABLE dbo.Categories (
        CategoryID   INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Categories PRIMARY KEY,
        StoreID      INT           NOT NULL CONSTRAINT FK_Categories_Store REFERENCES dbo.Stores(StoreID),
        CategoryName NVARCHAR(100) NOT NULL,
        Description  NVARCHAR(250) NULL,
        IconName     NVARCHAR(40)  NULL,
        CreatedAt    DATETIME2(0)  NOT NULL CONSTRAINT DF_Categories_Created DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_Categories_Store_Name UNIQUE (StoreID, CategoryName)
    );
GO
IF OBJECT_ID(N'dbo.Suppliers', N'U') IS NULL
    CREATE TABLE dbo.Suppliers (
        SupplierID    INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Suppliers PRIMARY KEY,
        StoreID       INT           NOT NULL CONSTRAINT FK_Suppliers_Store REFERENCES dbo.Stores(StoreID),
        SupplierName  NVARCHAR(150) NOT NULL,
        ContactPerson NVARCHAR(120) NULL,
        Phone         NVARCHAR(40)  NULL,
        Email         NVARCHAR(200) NULL,
        City          NVARCHAR(80)  NULL,
        Country       NVARCHAR(80)  NULL,
        Address       NVARCHAR(300) NULL,
        IsActive      BIT           NOT NULL CONSTRAINT DF_Suppliers_Active DEFAULT 1,
        CreatedAt     DATETIME2(0)  NOT NULL CONSTRAINT DF_Suppliers_Created DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_Suppliers_Store_Name UNIQUE (StoreID, SupplierName)
    );
GO
IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
    CREATE TABLE dbo.Products (
        ProductID     INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Products PRIMARY KEY,
        StoreID       INT            NOT NULL CONSTRAINT FK_Products_Store REFERENCES dbo.Stores(StoreID),
        ProductName   NVARCHAR(200)  NOT NULL,
        SKU           NVARCHAR(60)   NOT NULL,
        CategoryID    INT            NULL CONSTRAINT FK_Products_Category REFERENCES dbo.Categories(CategoryID),
        SupplierID    INT            NULL CONSTRAINT FK_Products_Supplier REFERENCES dbo.Suppliers(SupplierID),
        PurchasePrice DECIMAL(18,2)  NOT NULL CONSTRAINT DF_Products_Cost DEFAULT 0,
        SellingPrice  DECIMAL(18,2)  NOT NULL CONSTRAINT DF_Products_Price DEFAULT 0,
        Quantity      INT            NOT NULL CONSTRAINT DF_Products_Qty DEFAULT 0,
        ReorderLevel  INT            NOT NULL CONSTRAINT DF_Products_Reorder DEFAULT 0,
        Unit          NVARCHAR(30)   NOT NULL CONSTRAINT DF_Products_Unit DEFAULT N'Piece',
        Description   NVARCHAR(1000) NULL,
        IsDeleted     BIT            NOT NULL CONSTRAINT DF_Products_Deleted DEFAULT 0,
        DeletedAt     DATETIME2(0)   NULL,
        CreatedAt     DATETIME2(0)   NOT NULL CONSTRAINT DF_Products_Created DEFAULT SYSUTCDATETIME(),
        UpdatedAt     DATETIME2(0)   NOT NULL CONSTRAINT DF_Products_Updated DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_Products_Cost    CHECK (PurchasePrice >= 0),
        CONSTRAINT CK_Products_Price   CHECK (SellingPrice  >= 0),
        CONSTRAINT CK_Products_Qty     CHECK (Quantity      >= 0),
        CONSTRAINT CK_Products_Reorder CHECK (ReorderLevel  >= 0)
    );
GO
IF OBJECT_ID(N'dbo.StockTransactions', N'U') IS NULL
    CREATE TABLE dbo.StockTransactions (
        TransactionID   INT IDENTITY(1001,1) NOT NULL CONSTRAINT PK_StockTransactions PRIMARY KEY,
        StoreID         INT            NOT NULL CONSTRAINT FK_Tx_Store   REFERENCES dbo.Stores(StoreID),
        ProductID       INT            NOT NULL CONSTRAINT FK_Tx_Product REFERENCES dbo.Products(ProductID),
        TransactionType VARCHAR(12)    NOT NULL,
        QuantityChanged INT            NOT NULL,
        PreviousQuantity INT           NOT NULL,
        NewQuantity     INT            NOT NULL,
        UnitCost        DECIMAL(18,2)  NOT NULL CONSTRAINT DF_Tx_Cost DEFAULT 0,
        Reference       NVARCHAR(60)   NULL,
        Notes           NVARCHAR(500)  NULL,
        UserID          INT            NULL CONSTRAINT FK_Tx_User REFERENCES dbo.Users(UserID),
        TransactionDate DATETIME2(0)   NOT NULL CONSTRAINT DF_Tx_Date DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_Tx_Type     CHECK (TransactionType IN ('Stock In', 'Stock Out', 'Adjustment')),
        CONSTRAINT CK_Tx_NewQty   CHECK (NewQuantity >= 0),
        CONSTRAINT CK_Tx_PrevQty  CHECK (PreviousQuantity >= 0)
    );
GO
IF OBJECT_ID(N'dbo.Settings', N'U') IS NULL
    CREATE TABLE dbo.Settings (
        SettingID    INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Settings PRIMARY KEY,
        Scope        VARCHAR(10)   NOT NULL CONSTRAINT CK_Settings_Scope CHECK (Scope IN ('global', 'store', 'user')),
        ScopeID      INT           NOT NULL CONSTRAINT DF_Settings_ScopeID DEFAULT 0,
        SettingKey   VARCHAR(100)  NOT NULL,
        SettingValue NVARCHAR(500) NULL,
        UpdatedAt    DATETIME2(0)  NOT NULL CONSTRAINT DF_Settings_Updated DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_Settings UNIQUE (Scope, ScopeID, SettingKey)
    );
GO
IF OBJECT_ID(N'dbo.AuditLog', N'U') IS NULL
    CREATE TABLE dbo.AuditLog (
        AuditID   BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditLog PRIMARY KEY,
        UserID    INT           NULL,
        Username  NVARCHAR(40)  NULL,
        StoreID   INT           NULL,
        Action    VARCHAR(60)   NOT NULL,
        Entity    VARCHAR(60)   NULL,
        EntityID  NVARCHAR(60)  NULL,
        Details   NVARCHAR(1000) NULL,
        CreatedAt DATETIME2(0)  NOT NULL CONSTRAINT DF_Audit_Created DEFAULT SYSUTCDATETIME()
    );
GO
SET QUOTED_IDENTIFIER ON;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Products_Store_SKU' AND object_id = OBJECT_ID(N'dbo.Products'))
    CREATE UNIQUE INDEX UX_Products_Store_SKU ON dbo.Products (StoreID, SKU) WHERE IsDeleted = 0;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Products_Store_Name' AND object_id = OBJECT_ID(N'dbo.Products'))
    CREATE INDEX IX_Products_Store_Name ON dbo.Products (StoreID, ProductName);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Products_Category' AND object_id = OBJECT_ID(N'dbo.Products'))
    CREATE INDEX IX_Products_Category ON dbo.Products (CategoryID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Products_Supplier' AND object_id = OBJECT_ID(N'dbo.Products'))
    CREATE INDEX IX_Products_Supplier ON dbo.Products (SupplierID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Tx_Store_Date' AND object_id = OBJECT_ID(N'dbo.StockTransactions'))
    CREATE INDEX IX_Tx_Store_Date ON dbo.StockTransactions (StoreID, TransactionDate DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Tx_Product' AND object_id = OBJECT_ID(N'dbo.StockTransactions'))
    CREATE INDEX IX_Tx_Product ON dbo.StockTransactions (ProductID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Audit_Created' AND object_id = OBJECT_ID(N'dbo.AuditLog'))
    CREATE INDEX IX_Audit_Created ON dbo.AuditLog (CreatedAt DESC);
GO
IF NOT EXISTS (SELECT 1 FROM dbo.SchemaVersion WHERE Version = 1)
    INSERT INTO dbo.SchemaVersion (Version, Notes) VALUES (1, N'Initial schema: stores, users, roles, inventory, settings, audit');
GO
