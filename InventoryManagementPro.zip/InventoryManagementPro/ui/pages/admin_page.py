"""Users & Access: users, stores, roles and the audit log. Everything respects per-store permissions."""
from __future__ import annotations

import customtkinter as ctk

from core.errors import AppError
from core.permissions import DESCRIPTIONS, GROUP_ORDER, PERMISSIONS
from ui.pages import BasePage
from ui.table import Action, Column, DataTable, Pager
from ui.widgets import Dialog, Form, ask_confirm, badge, button, focus_search, label, show_guidance

NO_ACCESS = "No access"


def _run_guarded(app, work, done, failed_btn=None, busy_text=None):
    """Run work in the background; on error show the guided error dialog and re-enable the button."""
    def failed(exc: BaseException) -> None:
        if failed_btn is not None:
            try:
                failed_btn.configure(state="normal", text=busy_text or failed_btn.cget("text"))
            except Exception:
                pass
        app.show_error(exc)
    app.run_async(work, done, failed)


class AdminPage(BasePage):
    TABS = [("Users", "users.view"), ("Stores", "stores.view"), ("Roles", "roles.view"), ("Audit log", "audit.view")]

    def __init__(self, parent, app, spec) -> None:
        super().__init__(parent, app, spec)
        self.header()
        self.tabs = [name for name, perm in self.TABS if app.session.can(perm)]
        self.tab_bar = ctk.CTkSegmentedButton(self, values=self.tabs, command=self._show_tab, height=36,
                                              selected_color=app.ui.pal.accent_soft, selected_hover_color=app.ui.pal.accent_soft,
                                              unselected_color=app.ui.pal.card, unselected_hover_color=app.ui.pal.hover,
                                              text_color=app.ui.pal.text, fg_color=app.ui.pal.card,
                                              font=app.ui.font(13, True))
        self.tab_bar.pack(anchor="w", pady=(0, 14))
        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.pack(fill="both", expand=True)
        self.tab_bar.set(self.tabs[0])
        self._show_tab(self.tabs[0])

    def _show_tab(self, name: str) -> None:
        for child in self.body.winfo_children():
            child.destroy()
        {"Users": UsersTab, "Stores": StoresTab, "Roles": RolesTab, "Audit log": AuditTab}[name](self.body, self.app).pack(fill="both", expand=True)


class _Tab(ctk.CTkFrame):
    def __init__(self, parent, app) -> None:
        super().__init__(parent, fg_color="transparent")
        self.app = app

    def toolbar(self, placeholder: str, on_search, add_text: str | None = None, on_add=None):
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", pady=(0, 12))
        pal = self.app.ui.pal
        entry = ctk.CTkEntry(bar, placeholder_text=placeholder, width=320, height=38, fg_color=pal.input_bg,
                             border_color=pal.border, text_color=pal.text, font=self.app.ui.font(13), placeholder_text_color=pal.muted,
                             corner_radius=max(0, self.app.ui.radius - 3))
        entry.pack(side="left")
        entry.bind("<KeyRelease>", lambda _e: on_search(entry.get().strip().lower()))
        focus_search(self.app, entry)
        if add_text and on_add:
            button(bar, self.app, add_text, on_add, width=140).pack(side="right")
        return bar

    def alive(self) -> bool:
        try:
            return bool(self.winfo_exists())
        except Exception:
            return False


# ====================================================================== USERS
class UsersTab(_Tab):
    def __init__(self, parent, app) -> None:
        super().__init__(parent, app)
        s = app.session
        self.rows: list[dict] = []
        self.needle = ""
        self.toolbar("Search name, username or email...", self._search, "+ Add user" if s.can("users.create") else None, self._add)
        manage = lambda r: not r["IsSuperAdmin"] or s.is_super
        self.table = DataTable(self, app, [
            Column("FullName", "Name"),
            Column("Username", "Username"),
            Column("Email", "Email", value=lambda r: r["Email"] or "-", wrap=180),
            Column("Access", "Store access", weight=1, value=self._access_text, wrap=200),
            Column("Status", "Status", value=lambda r: ("Active", "success") if r["IsActive"] else ("Disabled", "error")),
            Column("LastLoginAt", "Last sign-in", value=lambda r: app.fmt.datetime(r["LastLoginAt"]) if r["LastLoginAt"] else "Never"),
            Column("Actions", "Actions", actions=[
                Action("Edit", self._edit, visible=lambda r: s.can("users.edit") and manage(r)),
                Action("Reset password", self._reset, visible=lambda r: s.can("users.reset_password") and manage(r)),
                Action("Disable", lambda r: self._toggle(r, False), "error",
                       visible=lambda r: s.can("users.deactivate") and manage(r) and r["IsActive"] and r["UserID"] != s.user_id),
                Action("Enable", lambda r: self._toggle(r, True), "accent",
                       visible=lambda r: s.can("users.deactivate") and manage(r) and not r["IsActive"]),
            ]),
        ], empty_text="Loading users...")
        self.table.pack(fill="x")
        self.refresh()

    @staticmethod
    def _access_text(r: dict) -> str:
        if r["IsSuperAdmin"]:
            return "Super administrator \u00b7 all stores"
        items = [f"{a['StoreName']}: {a['RoleName']}" for a in r.get("Assignments", [])]
        if not items:
            return "No store access"
        return "; ".join(items[:2]) + (f"  (+{len(items) - 2} more)" if len(items) > 2 else "")

    def refresh(self) -> None:
        app = self.app
        app.run_async(lambda: app.users.list_users(app.session), self._loaded, lambda e: (self._loaded([]), app.show_error(e)))

    def _loaded(self, rows: list[dict]) -> None:
        if self.alive():
            self.rows = rows
            self.table.empty.configure(text="No users match.")
            self._search(self.needle)

    def _search(self, text: str) -> None:
        self.needle = text
        rows = [r for r in self.rows if not text or text in r["FullName"].lower() or text in r["Username"].lower()
                or text in (r["Email"] or "").lower()]
        self.table.set_rows(rows)

    def _add(self) -> None:
        UserDialog(self.app, None, self.refresh)

    def _edit(self, row: dict) -> None:
        UserDialog(self.app, row, self.refresh)

    def _reset(self, row: dict) -> None:
        ResetPasswordDialog(self.app, row, self.refresh)

    def _toggle(self, row: dict, active: bool) -> None:
        app = self.app
        verb = "Enable" if active else "Disable"
        message = (f"{verb} {row['FullName']}'s account?" if active else
                   f"Disable {row['FullName']}'s account? They will be signed out and cannot sign in until you enable it again.")
        if not ask_confirm(app, f"{verb} user", message, verb, danger=not active):
            return

        def done(_r) -> None:
            if app.settings.get("audit.log_user_changes"):
                app.audit.log("user_enabled" if active else "user_disabled", app.session, "user", row["UserID"], row["Username"])
            app.toasts.show(f"{row['FullName']} is now {'active' if active else 'disabled'}.", "success")
            if self.alive():
                self.refresh()

        _run_guarded(app, lambda: app.users.set_active(app.session, row["UserID"], active), done)


class UserDialog(Dialog):
    def __init__(self, app, row: dict | None, on_saved) -> None:
        editing = row is not None
        super().__init__(app, "Edit user" if editing else "Add user",
                         "Update details and store access." if editing else "Create a person who can sign in.",
                         width=580, height=720, scrollable=True)
        self.row, self.on_saved = row, on_saved
        s = app.session
        holder = ctk.CTkFrame(self.body, fg_color="transparent")
        holder.pack(fill="x")
        form_host = ctk.CTkFrame(holder, fg_color="transparent")
        form_host.pack(fill="x")
        f = self.form = Form(form_host, app)
        f.entry("full_name", "Full name", row["FullName"] if editing else "", True)
        f.entry("username", "Username", row["Username"] if editing else "", True, half=True, readonly=editing,
                placeholder="e.g. sara.m")
        f.entry("email", "Email (optional)", (row["Email"] or "") if editing else "", half=True)
        if not editing:
            f.entry("password", "Password", "", True, show="\u2022", half=True)
            f.entry("confirm", "Confirm password", "", True, show="\u2022", half=True)
            f.check("must_change", "Must choose a new password at first sign-in", True)
            f.check("is_active", "Account is active", True)
        if s.is_super:
            f.check("is_super", "Super administrator (every permission in every store)", bool(row and row["IsSuperAdmin"]))
        label(holder, app, "Store access", 14, True).pack(anchor="w", pady=(12, 0))
        label(holder, app, "Pick a role per store. You can only give roles equal to or weaker than your own.", 11, muted=True,
              wraplength=500).pack(anchor="w", pady=(0, 6))
        self.role_vars: dict[int, ctk.StringVar] = {}
        self.role_ids: dict[int, dict[str, int]] = {}
        self.access_frame = ctk.CTkFrame(holder, fg_color="transparent")
        self.access_frame.pack(fill="x")
        label(self.access_frame, app, "Loading roles...", 12, muted=True).pack(anchor="w")
        self.save_btn = self.add_buttons("Save changes" if editing else "Create user", self._save)
        app.run_async(self._load_roles, self._roles_loaded, lambda e: (self.close(), app.show_error(e)))

    def _load_roles(self):
        app = self.app
        roles = app.roles.list_roles()
        current = app.users.assignments_of(self.row["UserID"]) if self.row else {}
        return roles, current

    def _roles_loaded(self, payload) -> None:
        if not self.winfo_exists():
            return
        app, s, pal = self.app, self.app.session, self.app.ui.pal
        roles, current = payload
        names = {r["RoleID"]: r["RoleName"] for r in roles}
        for child in self.access_frame.winfo_children():
            child.destroy()
        for access in s.accesses.values():
            store_id = access.store_id
            mine = s.can("users.assign_roles", store_id)
            allowed = [r for r in roles if r["RankLevel"] >= s.best_rank(store_id)]
            line = ctk.CTkFrame(self.access_frame, fg_color=pal.card_alt, corner_radius=8)
            line.pack(fill="x", pady=3)
            label(line, app, access.store_name, 13, True).pack(side="left", padx=12, pady=10)
            have = current.get(store_id)
            if not mine:
                if have:
                    label(line, app, f"{names.get(have, '?')}  (you cannot change this store)", 12, muted=True).pack(side="right", padx=12)
                else:
                    label(line, app, "You cannot give roles in this store", 12, muted=True).pack(side="right", padx=12)
                continue
            if have and have not in {r["RoleID"] for r in allowed}:
                label(line, app, f"{names.get(have, '?')}  (stronger than your role - cannot change)", 12, muted=True).pack(side="right", padx=12)
                continue
            mapping = {r["RoleName"]: r["RoleID"] for r in allowed}
            self.role_ids[store_id] = mapping
            var = ctk.StringVar(value=names.get(have, NO_ACCESS) if have else NO_ACCESS)
            self.role_vars[store_id] = var
            ctk.CTkOptionMenu(line, values=[NO_ACCESS] + list(mapping), variable=var, width=210, height=32,
                              fg_color=pal.input_bg, button_color=pal.border, button_hover_color=pal.hover,
                              text_color=pal.text, dropdown_fg_color=pal.card, dropdown_text_color=pal.text,
                              dropdown_hover_color=pal.hover, font=app.ui.font(13), dropdown_font=app.ui.font(13),
                              anchor="w").pack(side="right", padx=10, pady=8)

    def _assignments(self) -> dict[int, int | None]:
        return {sid: self.role_ids[sid].get(var.get()) for sid, var in self.role_vars.items()}

    def _save(self) -> None:
        app, f, s = self.app, self.form, self.app.session
        f.clear_errors()
        ok = f.require("full_name", "Type the person's full name, e.g. Sara Mohammed.")
        if not self.row:
            ok = f.require("username", "Type a username such as sara.m (3-40 letters, digits, dot, dash).") and ok
            ok = f.require("password", "Type a password for the new user.") and ok
        if not ok:
            return
        data = {"full_name": f.get("full_name"), "username": f.get("username"), "email": f.get("email"),
                "is_super": f.get("is_super") if s.is_super else (bool(self.row and self.row["IsSuperAdmin"]))}
        if not self.row:
            data.update(password=f.get("password"), confirm=f.get("confirm"), must_change=f.get("must_change"),
                        is_active=f.get("is_active"))
        assignments = self._assignments()
        self.save_btn.configure(state="disabled", text="Saving...")

        def work():
            if self.row:
                app.users.update_user(s, self.row["UserID"], data, assignments)
                return self.row["UserID"]
            return app.users.create_user(s, data, assignments)

        def done(user_id) -> None:
            if app.settings.get("audit.log_user_changes"):
                app.audit.log("user_updated" if self.row else "user_created", s, "user", user_id, data["username"])
            app.toasts.show(f"{data['full_name']} was {'updated' if self.row else 'created'}.", "success")
            self.on_saved()
            if self.winfo_exists():
                self.close()

        _run_guarded(app, work, done, self.save_btn, "Save changes" if self.row else "Create user")


class ResetPasswordDialog(Dialog):
    def __init__(self, app, row: dict, on_saved) -> None:
        super().__init__(app, "Reset password", f"Set a new password for {row['FullName']}.", width=460, height=440)
        self.row, self.on_saved = row, on_saved
        holder = ctk.CTkFrame(self.body, fg_color="transparent")
        holder.pack(fill="x")
        self.form = Form(holder, app)
        self.form.entry("new", "New password", "", True, show="\u2022")
        self.form.entry("confirm", "Confirm new password", "", True, show="\u2022")
        self.form.check("must", "They must choose their own password at next sign-in", True)
        self.btn = self.add_buttons("Reset password", self._save)

    def _save(self) -> None:
        app, f = self.app, self.form
        f.clear_errors()
        if not f.require("new", "Type a new password."):
            return
        self.btn.configure(state="disabled", text="Saving...")

        def done(_r) -> None:
            app.audit.log("password_reset", app.session, "user", self.row["UserID"], self.row["Username"])
            app.toasts.show(f"Password reset for {self.row['FullName']}.", "success")
            self.on_saved()
            if self.winfo_exists():
                self.close()

        _run_guarded(app, lambda: app.users.reset_password(app.session, self.row["UserID"], f.get("new"), f.get("confirm"), f.get("must")),
                     done, self.btn, "Reset password")


# ====================================================================== STORES
class StoresTab(_Tab):
    def __init__(self, parent, app) -> None:
        super().__init__(parent, app)
        s = app.session
        self.rows: list[dict] = []
        self.toolbar("Search stores...", self._search, "+ Add store" if s.can("stores.create") else None, lambda: StoreDialog(app, None, self.refresh))
        self.table = DataTable(self, app, [
            Column("StoreName", "Store", weight=1, wrap=300),
            Column("City", "City", value=lambda r: r["City"] or "-"),
            Column("Country", "Country", value=lambda r: r["Country"] or "-"),
            Column("UserCount", "Users"),
            Column("Status", "Status", value=lambda r: ("Active", "success") if r["IsActive"] else ("Inactive", "error")),
            Column("Actions", "Actions", actions=[
                Action("Edit", lambda r: StoreDialog(app, r, self.refresh), visible=lambda r: s.can("stores.edit", r["StoreID"])),
                Action("Deactivate", lambda r: self._toggle(r, False), "error", visible=lambda r: s.can("stores.edit", r["StoreID"]) and r["IsActive"]),
                Action("Activate", lambda r: self._toggle(r, True), visible=lambda r: s.can("stores.edit", r["StoreID"]) and not r["IsActive"]),
            ]),
        ], empty_text="Loading stores...")
        self.table.pack(fill="x")
        self.refresh()

    def refresh(self) -> None:
        app = self.app
        app.run_async(lambda: app.stores.list_stores(app.session), self._loaded, lambda e: (self._loaded([]), app.show_error(e)))

    def _loaded(self, rows) -> None:
        if self.alive():
            self.rows = rows
            self.table.empty.configure(text="No stores match.")
            self.table.set_rows(rows)

    def _search(self, text: str) -> None:
        self.table.set_rows([r for r in self.rows if not text or text in r["StoreName"].lower() or text in (r["City"] or "").lower()])

    def _toggle(self, row: dict, active: bool) -> None:
        app = self.app
        if not active and not ask_confirm(app, "Deactivate store", f"Deactivate '{row['StoreName']}'? Its users lose access to it until you activate it again. No data is deleted.", "Deactivate", danger=True):
            return

        def done(_r) -> None:
            app.audit.log("store_activated" if active else "store_deactivated", app.session, "store", row["StoreID"], row["StoreName"])
            app.toasts.show(f"{row['StoreName']} is now {'active' if active else 'inactive'}.", "success")
            app.refresh_session()
            if self.alive():
                self.refresh()

        _run_guarded(app, lambda: app.stores.set_active(row["StoreID"], active), done)


class StoreDialog(Dialog):
    def __init__(self, app, row: dict | None, on_saved) -> None:
        super().__init__(app, "Edit store" if row else "Add store", "Each store has its own products, stock, suppliers and settings.",
                         width=540, height=560)
        self.row, self.on_saved = row, on_saved
        holder = ctk.CTkFrame(self.body, fg_color="transparent")
        holder.pack(fill="x")
        f = self.form = Form(holder, app)
        r = row or {}
        f.entry("name", "Store name", r.get("StoreName", ""), True, placeholder="e.g. Jeddah branch")
        f.entry("city", "City", r.get("City") or "", half=True)
        f.entry("country", "Country", r.get("Country") or "", half=True)
        f.entry("phone", "Phone", r.get("Phone") or "")
        f.textarea("address", "Address", r.get("Address") or "", 70)
        self.btn = self.add_buttons("Save changes" if row else "Create store", self._save)

    def _save(self) -> None:
        app, f = self.app, self.form
        f.clear_errors()
        if not f.require("name", "Type a store name such as 'Jeddah branch'."):
            return
        data = {k: f.get(k) for k in ("name", "city", "country", "phone", "address")}
        self.btn.configure(state="disabled", text="Saving...")

        def done(store_id) -> None:
            app.audit.log("store_updated" if self.row else "store_created", app.session, "store", store_id, data["name"])
            app.toasts.show(f"Store '{data['name']}' saved.", "success")
            app.refresh_session()
            self.on_saved()
            if self.winfo_exists():
                self.close()

        _run_guarded(app, lambda: app.stores.save_store(app.session, self.row["StoreID"] if self.row else None, data), done, self.btn,
                     "Save changes" if self.row else "Create store")


# ====================================================================== ROLES
class RolesTab(_Tab):
    def __init__(self, parent, app) -> None:
        super().__init__(parent, app)
        s = app.session
        self.rows: list[dict] = []
        self.toolbar("Search roles...", self._search, "+ New role" if s.can("roles.manage") else None, lambda: RoleDialog(app, None, self.refresh))
        self.table = DataTable(self, app, [
            Column("RoleName", "Role"),
            Column("Description", "What it is for", weight=1, wrap=280),
            Column("RankLevel", "Rank", ),
            Column("PermCount", "Permissions"),
            Column("UserCount", "Assigned"),
            Column("Type", "Type", value=lambda r: ("Built-in", "muted") if r["IsSystem"] else ("Custom", "accent")),
            Column("Actions", "Actions", actions=[
                Action("View", lambda r: RoleDialog(app, r, self.refresh), visible=lambda r: r["IsSystem"] or not s.can("roles.manage")),
                Action("Edit", lambda r: RoleDialog(app, r, self.refresh), visible=lambda r: not r["IsSystem"] and s.can("roles.manage")),
                Action("Delete", self._delete, "error", visible=lambda r: not r["IsSystem"] and s.can("roles.manage")),
            ]),
        ], empty_text="Loading roles...")
        self.table.pack(fill="x")
        self.refresh()

    def refresh(self) -> None:
        app = self.app
        app.run_async(app.roles.list_roles, self._loaded, lambda e: (self._loaded([]), app.show_error(e)))

    def _loaded(self, rows) -> None:
        if self.alive():
            self.rows = rows
            self.table.empty.configure(text="No roles match.")
            self.table.set_rows(rows)

    def _search(self, text: str) -> None:
        self.table.set_rows([r for r in self.rows if not text or text in r["RoleName"].lower() or text in (r["Description"] or "").lower()])

    def _delete(self, row: dict) -> None:
        app = self.app
        if not ask_confirm(app, "Delete role", f"Delete the role '{row['RoleName']}'? This cannot be undone.", "Delete", danger=True):
            return

        def done(_r) -> None:
            app.audit.log("role_deleted", app.session, "role", row["RoleID"], row["RoleName"])
            app.toasts.show(f"Role '{row['RoleName']}' deleted.", "success")
            if self.alive():
                self.refresh()

        _run_guarded(app, lambda: app.roles.delete_role(row["RoleID"]), done)


class RoleDialog(Dialog):
    RANKS = ["25", "35", "45", "55", "65", "75", "85"]

    def __init__(self, app, row: dict | None, on_saved) -> None:
        self.system = bool(row and row["IsSystem"])
        self.readonly = self.system or (row is not None and not app.session.can("roles.manage"))
        title = "Role details" if self.readonly else ("Edit role" if row else "New role")
        super().__init__(app, title, "Lower rank number = more authority. Users can only hand out roles ranked equal to or below their own.",
                         width=680, height=760, scrollable=True)
        self.row, self.on_saved = row, on_saved
        s = app.session
        holder = ctk.CTkFrame(self.body, fg_color="transparent")
        holder.pack(fill="x")
        form_host = ctk.CTkFrame(holder, fg_color="transparent")
        form_host.pack(fill="x")
        f = self.form = Form(form_host, app)
        f.entry("name", "Role name", row["RoleName"] if row else "", True, readonly=self.readonly, placeholder="e.g. Night Shift Clerk")
        ranks = [r for r in self.RANKS if int(r) >= max(s.best_rank(), 1)] or ["85"]
        f.choice("rank", "Rank", ranks, str(row["RankLevel"]) if row and str(row["RankLevel"]) in ranks else ranks[0], half=True)
        f.entry("description", "Description", (row["Description"] or "") if row else "", half=True, readonly=self.readonly)
        if self.readonly:
            f.widget("rank").configure(state="disabled")
        label(holder, app, "Permissions", 14, True).pack(anchor="w", pady=(14, 4))
        self.checks: dict[str, ctk.BooleanVar] = {}
        self.pframe = ctk.CTkFrame(holder, fg_color="transparent")
        self.pframe.pack(fill="x")
        label(self.pframe, app, "Loading permissions...", 12, muted=True).pack(anchor="w")
        self.btn = None if self.readonly else self.add_buttons("Save role", self._save)
        if self.readonly:
            self.add_buttons("Close", self.close, secondary="")
        app.run_async(lambda: app.roles.permissions_of(row["RoleID"]) if row else set(), self._perms_loaded,
                      lambda e: (self.close(), app.show_error(e)))

    def _perms_loaded(self, granted: set) -> None:
        if not self.winfo_exists():
            return
        app, s, pal = self.app, self.app.session, self.app.ui.pal
        for child in self.pframe.winfo_children():
            child.destroy()
        for group in GROUP_ORDER:
            items = [(c, d) for c, g, d in PERMISSIONS if g == group]
            label(self.pframe, app, group.upper(), 10, True, muted=True).pack(anchor="w", pady=(10, 2))
            for code, desc in items:
                var = ctk.BooleanVar(value=code in granted)
                self.checks[code] = var
                allowed = (not self.readonly) and s.can(code)
                text = desc if self.readonly or allowed else f"{desc}  (you do not have this permission, so you cannot give it)"
                ctk.CTkCheckBox(self.pframe, text=text, variable=var, state="normal" if allowed else "disabled",
                                fg_color=pal.accent, hover_color=pal.accent_hover, border_color=pal.border,
                                text_color=pal.text if allowed or self.readonly else pal.muted, checkmark_color=pal.accent_text,
                                font=app.ui.font(12), corner_radius=5).pack(anchor="w", pady=2)

    def _save(self) -> None:
        app, f = self.app, self.form
        f.clear_errors()
        if not f.require("name", "Type a role name such as 'Night Shift Clerk'."):
            return
        perms = {c for c, v in self.checks.items() if v.get()}
        self.btn.configure(state="disabled", text="Saving...")
        rid = self.row["RoleID"] if self.row else None

        def done(role_id) -> None:
            app.audit.log("role_updated" if self.row else "role_created", app.session, "role", role_id, f.get("name"))
            app.toasts.show(f"Role '{f.get('name')}' saved.", "success")
            self.on_saved()
            if self.winfo_exists():
                self.close()

        _run_guarded(app, lambda: app.roles.save_role(rid, f.get("name"), f.get("description"), int(f.get("rank")), perms),
                     done, self.btn, "Save role")


# ====================================================================== AUDIT
class AuditTab(_Tab):
    def __init__(self, parent, app) -> None:
        super().__init__(parent, app)
        self.page, self.text, self.action = 1, "", ""
        self.size = app.settings.get("audit.page_size")
        bar = self.toolbar("Search user, entity or details...", self._search)
        pal = app.ui.pal
        self.action_menu = ctk.CTkOptionMenu(bar, values=["All actions"], width=190, height=38, fg_color=pal.input_bg,
                                             button_color=pal.border, button_hover_color=pal.hover, text_color=pal.text,
                                             dropdown_fg_color=pal.card, dropdown_text_color=pal.text,
                                             dropdown_hover_color=pal.hover, font=app.ui.font(13), anchor="w",
                                             command=self._pick_action)
        self.action_menu.pack(side="left", padx=10)
        self.table = DataTable(self, app, [
            Column("CreatedAt", "When", value=lambda r: app.fmt.datetime(r["CreatedAt"])),
            Column("Username", "User", value=lambda r: r["Username"] or "-"),
            Column("Action", "Action"),
            Column("Entity", "Entity", value=lambda r: f"{r['Entity'] or ''} {r['EntityID'] or ''}".strip() or "-"),
            Column("Details", "Details", weight=1, value=lambda r: r["Details"] or "", wrap=300),
        ], empty_text="Loading audit log...")
        self.table.pack(fill="x")
        self.pager = Pager(self, app, self._go)
        self.pager.pack(fill="x", pady=10)
        self._debounce = None
        app.run_async(app.audit.actions, lambda a: self.alive() and self.action_menu.configure(values=["All actions"] + a))
        self._load()

    def _search(self, text: str) -> None:
        if self._debounce:
            self.after_cancel(self._debounce)
        self.text = text
        self._debounce = self.after(300, lambda: self._go(1))

    def _pick_action(self, value: str) -> None:
        self.action = "" if value == "All actions" else value
        self._go(1)

    def _go(self, page: int) -> None:
        self.page = max(1, page)
        self._load()

    def _load(self) -> None:
        app = self.app
        offset = (self.page - 1) * self.size
        app.run_async(lambda: app.audit.search(app.session, self.text, self.action, self.size, offset), self._loaded,
                      lambda e: (self._loaded(([], 0)), app.show_error(e)))

    def _loaded(self, payload) -> None:
        if not self.alive():
            return
        rows, total = payload
        self.table.empty.configure(text="No audit entries match.")
        self.table.set_rows(rows)
        self.pager.set(total, self.page, self.size)
