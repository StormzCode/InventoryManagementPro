"""Page registry. A page appears in the sidebar only when it is registered here AND the user has permission."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import customtkinter as ctk

from ui.widgets import label


@dataclass(frozen=True)
class PageSpec:
    key: str
    title: str
    icon: str
    perms: tuple[str, ...]          # any one of these grants access
    factory: Callable
    subtitle: str = ""


NAV_ORDER = ("dashboard", "products", "categories", "suppliers", "stock", "transactions", "reports", "admin", "settings")


def build_registry() -> dict[str, PageSpec]:
    from ui.pages.admin_page import AdminPage
    from ui.pages.categories_page import CategoriesPage
    from ui.pages.products_page import ProductsPage
    from ui.pages.settings_page import SettingsPage
    from ui.pages.suppliers_page import SuppliersPage
    return {
        "products": PageSpec("products", "Products", "\u25a3", ("products.view",), ProductsPage, "Your product catalog, stock levels and cost basis in one place."),
        "categories": PageSpec("categories", "Categories", "\u2637", ("categories.view",), CategoriesPage, "A clear structure for every product in your inventory."),
        "suppliers": PageSpec("suppliers", "Suppliers", "\u260e", ("suppliers.view",), SuppliersPage, "Your supplier directory, contacts and product relationships."),
        "admin": PageSpec("admin", "Users & Access", "\u263b", ("users.view", "stores.view", "roles.view", "audit.view"),
                          AdminPage, "Manage people, stores, roles and see who did what."),
        "settings": PageSpec("settings", "Settings", "\u2699", ("settings.view",), SettingsPage,
                             "Make Inventory Management Pro work the way you do."),
    }


class BasePage(ctk.CTkFrame):
    def __init__(self, parent, app, spec: PageSpec) -> None:
        super().__init__(parent, fg_color="transparent")
        self.app, self.spec = app, spec

    def header(self, title: str | None = None, subtitle: str | None = None) -> ctk.CTkFrame:
        """Page title row. Returns the frame on the right where action buttons go."""
        app = self.app
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", pady=(0, 14))
        left = ctk.CTkFrame(row, fg_color="transparent")
        left.pack(side="left")
        label(left, app, title or self.spec.title, 24, True).pack(anchor="w")
        sub = subtitle if subtitle is not None else self.spec.subtitle
        if sub and app.settings.get("appearance.show_page_subtitle"):
            label(left, app, sub, 13, muted=True).pack(anchor="w")
        actions = ctk.CTkFrame(row, fg_color="transparent", width=1, height=1)
        actions.pack(side="right")
        return actions

    def alive(self) -> bool:
        try:
            return bool(self.winfo_exists())
        except Exception:
            return False
