"""Categories: summary cards, searchable table, value distribution, add/edit/delete (with safe product reassignment)."""
from __future__ import annotations

import customtkinter as ctk

from core.errors import user_error
from services.catalog import CategoryService
from ui.pages import BasePage
from ui.table import Action, Column, DataTable, Pager
from ui.widgets import (Dialog, Form, button, card, focus_search, label, reauthenticate, separator, stat_card,
                        submit_form)

BAR_COLORS = ["accent", "success", "warning", "error", "muted"]


class CategoriesPage(BasePage):
    def __init__(self, parent, app, spec) -> None:
        super().__init__(parent, app, spec)
        s, get = app.session, app.settings.get
        self.rows: list[dict] = []
        self.needle, self.page_no = "", 1
        self.size = int(get("categories.page_size"))
        actions = self.header()
        if s.can("categories.create"):
            button(actions, app, "+ Add category", lambda: CategoryDialog(app, None, self.refresh)).pack()
        self.stats = ctk.CTkFrame(self, fg_color="transparent")
        if get("categories.show_stats"):
            self.stats.pack(fill="x", pady=(0, 14))
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", pady=(0, 12))
        self.search = ctk.CTkEntry(bar, placeholder_text="Search categories...", width=320, height=38, fg_color=app.ui.pal.input_bg,
                                   border_color=app.ui.pal.border, text_color=app.ui.pal.text, placeholder_text_color=app.ui.pal.muted,
                                   font=app.ui.font(13), corner_radius=max(0, app.ui.radius - 3))
        self.search.pack(side="left")
        self.search.bind("<KeyRelease>", lambda _e: self._on_search())
        focus_search(app, self.search)
        self.count_lbl = label(bar, app, "", 12, muted=True)
        self.count_lbl.pack(side="right")
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="x")
        body.grid_columnconfigure(0, weight=1)
        left = ctk.CTkFrame(body, fg_color="transparent")
        left.grid(row=0, column=0, sticky="new")
        symbol = str(get("regional.currency_symbol"))
        self.table = DataTable(left, app, [
            Column("CategoryName", "Category", weight=1, value=lambda r: r["CategoryName"] + (f"\n{r['Description']}" if r["Description"] else ""), wrap=320),
            Column("ProductCount", "Products"),
            Column("Units", "Units", value=lambda r: app.fmt.number(r["Units"])),
            Column("Value", f"Value ({symbol})", value=lambda r: app.fmt.money(r["Value"], bool(get("regional.show_currency_in_tables")))),
            Column("Actions", "Actions", actions=[
                Action("Edit", lambda r: CategoryDialog(app, r, self.refresh), visible=lambda r: s.can("categories.edit")),
                Action("Delete", self._delete, "error", visible=lambda r: s.can("categories.delete")),
            ]),
        ], empty_text="Loading categories...")
        self.table.pack(fill="x")
        self.pager = Pager(left, app, self._go)
        self.pager.pack(fill="x", pady=10)
        self.panel = card(body, app, width=300)
        if get("categories.show_distribution"):
            self.panel.grid(row=0, column=1, sticky="new", padx=(16, 0))
        label(self, app, "Category changes apply to linked products. Stock quantities are not affected.", 11, muted=True).pack(anchor="w", pady=(6, 0))
        self.refresh()

    # ---------------------------------------------------------------- data
    def refresh(self) -> None:
        app = self.app
        sid = app.session.active_store_id
        app.run_async(lambda: app.categories.list(sid), self._loaded, lambda e: (self._loaded([]), app.show_error(e)))

    def _loaded(self, rows: list[dict]) -> None:
        if not self.alive():
            return
        self.rows = rows
        self.table.empty.configure(text="No categories yet. Click '+ Add category' to create the first one.")
        self._stats()
        self._distribution()
        self._show()

    def _filtered(self) -> list[dict]:
        t = self.needle
        return [r for r in self.rows if not t or t in r["CategoryName"].lower() or t in (r["Description"] or "").lower()]

    def _on_search(self) -> None:
        self.needle = self.search.get().strip().lower()
        self._go(1)

    def _go(self, page: int) -> None:
        self.page_no = max(1, page)
        self._show()

    def _show(self) -> None:
        rows = self._filtered()
        self.pager.set(len(rows), self.page_no, self.size)
        self.page_no = self.pager.page
        self.table.set_rows(rows[(self.page_no - 1) * self.size: self.page_no * self.size])
        self.count_lbl.configure(text=f"{len(rows)} categor{'y' if len(rows) == 1 else 'ies'}")

    def _stats(self) -> None:
        app = self.app
        for child in self.stats.winfo_children():
            child.destroy()
        self.stats.grid_columnconfigure((0, 1, 2), weight=1, uniform="stat")
        products = sum(r["ProductCount"] for r in self.rows)
        total = sum(float(r["Value"]) for r in self.rows)
        top = max(self.rows, key=lambda r: r["Value"], default=None)
        empty = sum(1 for r in self.rows if r["ProductCount"] == 0)
        cards = [("Total categories", str(len(self.rows)), "All categories have products" if not empty else f"{empty} without products", None),
                 ("Products in categories", str(products), "Across every category", None),
                 ("Largest category", top["CategoryName"] if top and total else "-",
                  f"{app.fmt.money(top['Value'])} \u00b7 {float(top['Value']) / total * 100:.1f}% of value" if top and total else "No stock value yet", None)]
        for i, (t, v, sub, tone) in enumerate(cards):
            stat_card(self.stats, app, t, v, sub, tone).grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0 if i == 2 else 8))

    def _distribution(self) -> None:
        app, pal = self.app, self.app.ui.pal
        for child in self.panel.winfo_children():
            child.destroy()
        label(self.panel, app, "Value distribution", 15, True).pack(anchor="w", padx=18, pady=(16, 8))
        total = sum(float(r["Value"]) for r in self.rows)
        if not total:
            label(self.panel, app, "Add stock to products to see how value is spread across categories.", 12, muted=True, wraplength=250).pack(anchor="w", padx=18, pady=(0, 16))
            return
        for i, r in enumerate(sorted(self.rows, key=lambda r: -r["Value"])[:8]):
            share = float(r["Value"]) / total
            line = ctk.CTkFrame(self.panel, fg_color="transparent")
            line.pack(fill="x", padx=18, pady=(4, 0))
            label(line, app, r["CategoryName"], 12).pack(side="left")
            label(line, app, f"{share * 100:.1f}%", 12, True).pack(side="right")
            bar = ctk.CTkProgressBar(self.panel, height=8, progress_color=getattr(pal, BAR_COLORS[i % len(BAR_COLORS)]), fg_color=pal.border)
            bar.pack(fill="x", padx=18, pady=(2, 4))
            bar.set(share)
        separator(self.panel, app).pack(fill="x", padx=18, pady=8)
        line = ctk.CTkFrame(self.panel, fg_color="transparent")
        line.pack(fill="x", padx=18, pady=(0, 16))
        label(line, app, "Total value", 12, muted=True).pack(side="left")
        label(line, app, app.fmt.money(total), 13, True).pack(side="right")

    def _delete(self, row: dict) -> None:
        DeleteCategoryDialog(self.app, row, self.rows, self.refresh)


class CategoryDialog(Dialog):
    def __init__(self, app, row: dict | None, on_saved) -> None:
        super().__init__(app, "Edit category" if row else "Add category", "Update the details below." if row else "Add a new category to this store.",
                         width=500, height=470)
        self.row, self.on_saved = row, on_saved
        holder = ctk.CTkFrame(self.body, fg_color="transparent")
        holder.pack(fill="x")
        host = ctk.CTkFrame(holder, fg_color="transparent")
        host.pack(fill="x")
        f = self.form = Form(host, app)
        f.entry("name", "Category name", row["CategoryName"] if row else "", True, placeholder="e.g. Electronics")
        f.textarea("description", "Description", (row["Description"] or "") if row else "", 80)
        f.choice("icon", "Category icon", CategoryService.ICONS, (row["IconName"] or "Box") if row else "Box")
        if row and row["ProductCount"]:
            label(holder, app, f"{row['ProductCount']} linked product(s) will use the new name. Stock levels, costs and history are not changed.", 11, muted=True, wraplength=430).pack(anchor="w")
        self.btn = self.add_buttons("Save changes" if row else "Create category", self._save)

    def _save(self) -> None:
        app, f = self.app, self.form
        f.clear_errors()
        sid, cid = app.session.active_store_id, self.row["CategoryID"] if self.row else None
        name, desc, icon = f.get("name"), f.get("description"), f.get("icon")

        def done(category_id) -> None:
            app.audit.log("category_updated" if cid else "category_created", app.session, "category", category_id, name)
            app.toasts.show(f"Category '{name}' saved.", "success")
            self.on_saved()
            if self.winfo_exists():
                self.close()

        submit_form(app, f, self.btn, lambda: app.categories.save(sid, cid, name, desc, icon), done, "Save changes" if cid else "Create category")


class DeleteCategoryDialog(Dialog):
    def __init__(self, app, row: dict, all_rows: list[dict], on_done) -> None:
        self.row, self.on_done = row, on_done
        count = row["ProductCount"]
        super().__init__(app, "Delete category?", width=520, height=440 if count else 300)
        pal = app.ui.pal
        label(self.body, app, f"You are about to delete '{row['CategoryName']}'." + (f" It has {count} linked product(s)." if count else ""), 13, wraplength=460).pack(anchor="w")
        self.targets = {r["CategoryName"]: r["CategoryID"] for r in all_rows if r["CategoryID"] != row["CategoryID"]}
        self.var = ctk.StringVar(value=next(iter(self.targets), ""))
        if count:
            warn = ctk.CTkFrame(self.body, fg_color=pal.warning_soft, corner_radius=8)
            warn.pack(fill="x", pady=12)
            label(warn, app, "Reassign the linked products before deleting", 13, True, color=pal.warning).pack(anchor="w", padx=14, pady=(10, 0))
            label(warn, app, "Their stock and transaction history are preserved.", 12, muted=True).pack(anchor="w", padx=14, pady=(0, 10))
            label(self.body, app, "Move products to category *", 12, muted=True).pack(anchor="w")
            if self.targets:
                ctk.CTkOptionMenu(self.body, values=list(self.targets), variable=self.var, height=36, fg_color=pal.input_bg, button_color=pal.border,
                                  button_hover_color=pal.hover, text_color=pal.text, dropdown_fg_color=pal.card, dropdown_text_color=pal.text,
                                  dropdown_hover_color=pal.hover, font=app.ui.font(13), anchor="w").pack(fill="x", pady=(2, 0))
            else:
                label(self.body, app, "There is no other category to move them to. Fix: close this window, click '+ Add category', create one, then delete this one.", 12, color=pal.error, wraplength=460).pack(anchor="w", pady=4)
        label(self.body, app, "This cannot be undone.", 12, muted=True).pack(anchor="w", pady=(10, 0))
        self.btn = self.add_buttons("Move & delete category" if count else "Delete category", self._go, danger=True)

    def _go(self) -> None:
        app, count = self.app, self.row["ProductCount"]
        if count and not self.targets:
            app.show_error(user_error("No category to move the products to.", "A category with products can only be deleted after its products have a new home.",
                                      ["Close this window.", "Click '+ Add category' and create another category.", "Open Delete again and pick it in the list."]))
            return
        if not reauthenticate(app):
            return
        sid, cid = app.session.active_store_id, self.row["CategoryID"]
        move = self.targets.get(self.var.get()) if count else None
        self.btn.configure(state="disabled", text="Deleting...")

        def done(_r) -> None:
            app.audit.log("category_deleted", app.session, "category", cid, self.row["CategoryName"])
            app.toasts.show(f"Category '{self.row['CategoryName']}' deleted.", "success")
            self.on_done()
            if self.winfo_exists():
                self.close()

        def failed(exc: BaseException) -> None:
            if self.winfo_exists():
                self.btn.configure(state="normal", text="Delete category")
            app.show_error(exc)

        app.run_async(lambda: app.categories.delete(sid, cid, move), done, failed)
