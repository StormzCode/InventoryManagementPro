"""Suppliers: directory with city filter, details, add/edit, delete with replacement supplier, CSV export."""
from __future__ import annotations

import customtkinter as ctk

from core.errors import user_error
from ui.export_ui import run_export
from ui.pages import BasePage
from ui.table import Action, Column, DataTable, Pager
from ui.widgets import Dialog, Form, badge, button, focus_search, label, reauthenticate, stat_card, submit_form

ALL_CITIES = "All cities"


class SuppliersPage(BasePage):
    def __init__(self, parent, app, spec) -> None:
        super().__init__(parent, app, spec)
        s, get = app.session, app.settings.get
        self.rows: list[dict] = []
        self.needle, self.city, self.page_no = "", ALL_CITIES, 1
        self.size = int(get("suppliers.page_size"))
        actions = self.header()
        if s.can("suppliers.view"):
            button(actions, app, "Export CSV", self._export, "secondary").pack(side="left", padx=(0, 8))
        if s.can("suppliers.create"):
            button(actions, app, "+ Add supplier", lambda: SupplierDialog(app, None, self.refresh)).pack(side="left")
        self.stats = ctk.CTkFrame(self, fg_color="transparent")
        if get("suppliers.show_stats"):
            self.stats.pack(fill="x", pady=(0, 14))
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", pady=(0, 12))
        pal = app.ui.pal
        self.search = ctk.CTkEntry(bar, placeholder_text="Search name, contact or email...", width=320, height=38, fg_color=pal.input_bg,
                                   border_color=pal.border, text_color=pal.text, placeholder_text_color=pal.muted, font=app.ui.font(13),
                                   corner_radius=max(0, app.ui.radius - 3))
        self.search.pack(side="left")
        self.search.bind("<KeyRelease>", lambda _e: self._filter_changed())
        focus_search(app, self.search)
        self.city_menu = ctk.CTkOptionMenu(bar, values=[ALL_CITIES], command=self._pick_city, width=160, height=38, fg_color=pal.input_bg,
                                           button_color=pal.border, button_hover_color=pal.hover, text_color=pal.text, dropdown_fg_color=pal.card,
                                           dropdown_text_color=pal.text, dropdown_hover_color=pal.hover, font=app.ui.font(13), anchor="w")
        self.city_menu.pack(side="left", padx=10)
        self.count_lbl = label(bar, app, "", 12, muted=True)
        self.count_lbl.pack(side="right")
        self.table = DataTable(self, app, [
            Column("SupplierName", "Supplier", weight=1, value=lambda r: f"{r['SupplierName']}\nSince {app.fmt.date(r['CreatedAt'])}"),
            Column("ContactPerson", "Contact person", value=lambda r: r["ContactPerson"] or "-"),
            Column("Email", "Email / Phone", value=lambda r: "\n".join(x for x in (r["Email"], r["Phone"]) if x) or "-", wrap=240),
            Column("ProductCount", "Products", value=lambda r: f"{r['ProductCount']} product{'s' if r['ProductCount'] != 1 else ''}"),
            Column("City", "Location", value=lambda r: r["City"] or "-"),
            Column("Actions", "Actions", actions=[
                Action("View", lambda r: SupplierDetails(app, r, self.refresh)),
                Action("Edit", lambda r: SupplierDialog(app, r, self.refresh), visible=lambda r: s.can("suppliers.edit")),
                Action("Delete", lambda r: SupplierDeleteDialog(app, r, self.rows, self.refresh), "error", visible=lambda r: s.can("suppliers.delete")),
            ]),
        ], empty_text="Loading suppliers...")
        self.table.pack(fill="x")
        self.pager = Pager(self, app, self._go)
        self.pager.pack(fill="x", pady=10)
        self.refresh()

    def refresh(self) -> None:
        app = self.app
        sid = app.session.active_store_id
        app.run_async(lambda: app.suppliers.list(sid), self._loaded, lambda e: (self._loaded([]), app.show_error(e)))

    def _loaded(self, rows: list[dict]) -> None:
        if not self.alive():
            return
        self.rows = rows
        cities = sorted({r["City"] for r in rows if r["City"]})
        self.city_menu.configure(values=[ALL_CITIES] + cities)
        if self.city not in cities:
            self.city = ALL_CITIES
            self.city_menu.set(ALL_CITIES)
        self.table.empty.configure(text="No suppliers yet. Click '+ Add supplier' to create the first one.")
        self._stats()
        self._show()

    def _filtered(self) -> list[dict]:
        t = self.needle
        return [r for r in self.rows if (self.city == ALL_CITIES or r["City"] == self.city) and
                (not t or t in r["SupplierName"].lower() or t in (r["ContactPerson"] or "").lower() or t in (r["Email"] or "").lower())]

    def _filter_changed(self) -> None:
        self.needle = self.search.get().strip().lower()
        self._go(1)

    def _pick_city(self, value: str) -> None:
        self.city = value
        self._go(1)

    def _go(self, page: int) -> None:
        self.page_no = max(1, page)
        self._show()

    def _show(self) -> None:
        rows = self._filtered()
        self.pager.set(len(rows), self.page_no, self.size)
        self.page_no = self.pager.page
        self.table.set_rows(rows[(self.page_no - 1) * self.size: self.page_no * self.size])
        self.count_lbl.configure(text=f"{len(rows)} supplier{'s' if len(rows) != 1 else ''}")

    def _stats(self) -> None:
        app = self.app
        for child in self.stats.winfo_children():
            child.destroy()
        self.stats.grid_columnconfigure((0, 1, 2), weight=1, uniform="stat")
        cities = len({r["City"] for r in self.rows if r["City"]})
        linked = sum(r["ProductCount"] for r in self.rows)
        value = sum(float(r["Value"]) for r in self.rows)
        cards = [("Active suppliers", str(sum(1 for r in self.rows if r["IsActive"])), f"Across {cities} cit{'y' if cities == 1 else 'ies'}"),
                 ("Linked products", str(linked), "Every product has a supplier" if all(r["ProductCount"] for r in self.rows) and self.rows else "Some suppliers have no products"),
                 ("Stock value supplied", app.fmt.money(value), "At current unit cost")]
        for i, (t, v, sub) in enumerate(cards):
            stat_card(self.stats, app, t, v, sub).grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0 if i == 2 else 8))

    def _export(self) -> None:
        app = self.app
        rows = self._filtered()
        run_export(app, "suppliers", ["Supplier", "Contact person", "Email", "Phone", "City", "Country", "Address", "Products", "Units", "Stock value"],
                   lambda: [[r["SupplierName"], r["ContactPerson"] or "", r["Email"] or "", r["Phone"] or "", r["City"] or "", r["Country"] or "",
                             r["Address"] or "", r["ProductCount"], r["Units"], float(r["Value"])] for r in rows])


class SupplierDialog(Dialog):
    def __init__(self, app, row: dict | None, on_saved) -> None:
        super().__init__(app, "Edit supplier" if row else "Add supplier", "Update the details below." if row else "Add a new supplier to this store.",
                         width=580, height=640, scrollable=True)
        self.row, self.on_saved = row, on_saved
        get = app.settings.get
        holder = ctk.CTkFrame(self.body, fg_color="transparent")
        holder.pack(fill="x")
        host = ctk.CTkFrame(holder, fg_color="transparent")
        host.pack(fill="x")
        f = self.form = Form(host, app)
        r = row or {}
        f.entry("name", "Supplier name", r.get("SupplierName", ""), True, placeholder="e.g. Najd Supplies")
        f.entry("contact", "Contact person", r.get("ContactPerson") or "", half=True)
        f.entry("phone", "Phone", r.get("Phone") or "", bool(get("suppliers.require_phone")), half=True, placeholder="+966 11 555 0194")
        f.entry("email", "Email", r.get("Email") or "", bool(get("suppliers.require_email")), placeholder="name@company.sa")
        f.entry("city", "City", r.get("City") or (get("suppliers.default_city") if not row else ""), half=True)
        f.entry("country", "Country", r.get("Country") or (get("suppliers.default_country") if not row else ""), half=True)
        f.textarea("address", "Address / notes", r.get("Address") or "", 80)
        if row:
            label(holder, app, f"{row['ProductCount']} linked product(s). Contact updates do not affect stock or costs.", 11, muted=True).pack(anchor="w")
        self.btn = self.add_buttons("Save changes" if row else "Create supplier", self._save)

    def _save(self) -> None:
        app, f = self.app, self.form
        f.clear_errors()
        sid, supplier_id = app.session.active_store_id, self.row["SupplierID"] if self.row else None
        data = {k: f.get(k) for k in ("name", "contact", "phone", "email", "city", "country", "address")}

        def done(new_id) -> None:
            app.audit.log("supplier_updated" if supplier_id else "supplier_created", app.session, "supplier", new_id, data["name"])
            app.toasts.show(f"Supplier '{data['name']}' saved.", "success")
            self.on_saved()
            if self.winfo_exists():
                self.close()

        submit_form(app, f, self.btn, lambda: app.suppliers.save(sid, supplier_id, data), done, "Save changes" if supplier_id else "Create supplier")


class SupplierDetails(Dialog):
    def __init__(self, app, row: dict, on_changed) -> None:
        super().__init__(app, "Supplier details", width=620, height=640, scrollable=True)
        self.row, self.on_changed = row, on_changed
        pal = app.ui.pal
        head = ctk.CTkFrame(self.body, fg_color="transparent")
        head.pack(fill="x")
        initials = "".join(w[0] for w in row["SupplierName"].split()[:2]).upper()
        ctk.CTkLabel(head, text=initials, width=44, height=44, corner_radius=10, fg_color=pal.accent_soft, text_color=pal.accent, font=app.ui.font(14, True)).pack(side="left")
        names = ctk.CTkFrame(head, fg_color="transparent")
        names.pack(side="left", padx=12)
        label(names, app, row["SupplierName"], 17, True).pack(anchor="w")
        label(names, app, f"Supplier since {app.fmt.date(row['CreatedAt'])}", 12, muted=True).pack(anchor="w")
        badge(head, app, "Active" if row["IsActive"] else "Inactive", "success" if row["IsActive"] else "error").pack(side="right")
        grid = ctk.CTkFrame(self.body, fg_color="transparent")
        grid.pack(fill="x", pady=12)
        grid.grid_columnconfigure((0, 1), weight=1, uniform="d")
        place = ", ".join(x for x in (row["City"], row["Country"]) if x) or "-"
        for i, (t, v) in enumerate([("Contact person", row["ContactPerson"] or "-"), ("Phone", row["Phone"] or "-"), ("Email", row["Email"] or "-"), ("Location", place)]):
            cell = ctk.CTkFrame(grid, fg_color="transparent")
            cell.grid(row=i // 2, column=i % 2, sticky="w", pady=6)
            label(cell, app, t, 11, muted=True).pack(anchor="w")
            label(cell, app, v, 13).pack(anchor="w")
        label(self.body, app, "Address / notes", 11, muted=True).pack(anchor="w")
        label(self.body, app, row["Address"] or "-", 13, wraplength=540).pack(anchor="w", pady=(0, 10))
        box = ctk.CTkFrame(self.body, fg_color=pal.card_alt, corner_radius=8)
        box.pack(fill="x", pady=6)
        label(box, app, f"{row['ProductCount']} products \u00b7 {app.fmt.number(row['Units'])} units", 13, True).pack(side="left", padx=14, pady=12)
        label(box, app, f"Inventory value {app.fmt.money(row['Value'])}", 13, True).pack(side="right", padx=14)
        self.products_frame = ctk.CTkFrame(self.body, fg_color="transparent")
        self.products_frame.pack(fill="x", pady=6)
        label(self.products_frame, app, "Loading linked products...", 12, muted=True).pack(anchor="w")
        sid = app.session.active_store_id
        app.run_async(lambda: app.suppliers.linked_products(sid, row["SupplierID"]), self._products, lambda e: app.show_error(e))
        if app.session.can("suppliers.edit"):
            button(self.footer, app, "Edit supplier", self._edit, "secondary", width=130).pack(side="left")
        self.add_buttons("Done", self.close, secondary="")

    def _products(self, rows: list[dict]) -> None:
        if not self.winfo_exists():
            return
        for child in self.products_frame.winfo_children():
            child.destroy()
        t = DataTable(self.products_frame, self.app, [Column("ProductName", "Linked product", weight=1), Column("Quantity", "Stock"),
                                                      Column("Value", "Value", value=lambda r: self.app.fmt.money(r["Value"]))], empty_text="No products are linked to this supplier.")
        t.pack(fill="x")
        t.set_rows(rows)

    def _edit(self) -> None:
        self.close()
        SupplierDialog(self.app, self.row, self.on_changed)


class SupplierDeleteDialog(Dialog):
    def __init__(self, app, row: dict, all_rows: list[dict], on_done) -> None:
        self.row, self.on_done = row, on_done
        count = row["ProductCount"]
        super().__init__(app, "Delete supplier?", width=520, height=440 if count else 300)
        pal = app.ui.pal
        label(self.body, app, f"You are about to delete '{row['SupplierName']}'." + (f" This supplier has {count} linked product(s)." if count else ""), 13, wraplength=460).pack(anchor="w")
        self.targets = {r["SupplierName"]: r["SupplierID"] for r in all_rows if r["SupplierID"] != row["SupplierID"] and r["IsActive"]}
        self.var = ctk.StringVar(value=next(iter(self.targets), ""))
        if count:
            warn = ctk.CTkFrame(self.body, fg_color=pal.warning_soft, corner_radius=8)
            warn.pack(fill="x", pady=12)
            label(warn, app, "Reassign the linked products before deleting", 13, True, color=pal.warning).pack(anchor="w", padx=14, pady=(10, 0))
            label(warn, app, "Their stock and transaction history are preserved.", 12, muted=True).pack(anchor="w", padx=14, pady=(0, 10))
            label(self.body, app, "Assign replacement supplier *", 12, muted=True).pack(anchor="w")
            if self.targets:
                ctk.CTkOptionMenu(self.body, values=list(self.targets), variable=self.var, height=36, fg_color=pal.input_bg, button_color=pal.border,
                                  button_hover_color=pal.hover, text_color=pal.text, dropdown_fg_color=pal.card, dropdown_text_color=pal.text,
                                  dropdown_hover_color=pal.hover, font=app.ui.font(13), anchor="w").pack(fill="x", pady=(2, 0))
            else:
                label(self.body, app, "There is no other supplier. Fix: close this window, click '+ Add supplier', create one, then delete this one.", 12, color=pal.error, wraplength=460).pack(anchor="w", pady=4)
        label(self.body, app, "This cannot be undone.", 12, muted=True).pack(anchor="w", pady=(10, 0))
        self.btn = self.add_buttons("Reassign & delete supplier" if count else "Delete supplier", self._go, danger=True)

    def _go(self) -> None:
        app, count = self.app, self.row["ProductCount"]
        if count and not self.targets:
            app.show_error(user_error("No replacement supplier available.", "Products must be moved to another supplier before this one is deleted.",
                                      ["Close this window.", "Click '+ Add supplier' and create another supplier.", "Open Delete again and pick it in the list."]))
            return
        if not reauthenticate(app):
            return
        sid, supplier_id = app.session.active_store_id, self.row["SupplierID"]
        move = self.targets.get(self.var.get()) if count else None
        self.btn.configure(state="disabled", text="Deleting...")

        def done(_r) -> None:
            app.audit.log("supplier_deleted", app.session, "supplier", supplier_id, self.row["SupplierName"])
            app.toasts.show(f"Supplier '{self.row['SupplierName']}' deleted.", "success")
            self.on_done()
            if self.winfo_exists():
                self.close()

        def failed(exc: BaseException) -> None:
            if self.winfo_exists():
                self.btn.configure(state="normal", text="Delete supplier")
            app.show_error(exc)

        app.run_async(lambda: app.suppliers.delete(sid, supplier_id, move), done, failed)
