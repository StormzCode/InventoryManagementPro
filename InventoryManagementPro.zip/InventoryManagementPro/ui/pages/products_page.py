"""Products: search, category/supplier/status filters, sorting, paging, add/edit/details/delete, CSV export."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation

import customtkinter as ctk

from core.errors import user_error
from ui.export_ui import run_export
from ui.pages import BasePage
from ui.table import Action, Column, DataTable, Pager
from ui.widgets import (Dialog, Form, ask_confirm, badge, button, focus_search, label, reauthenticate, submit_form)

ALL_CAT, ALL_SUP, ALL_STATUS = "All categories", "All suppliers", "All statuses"
STATUSES = [ALL_STATUS, "In stock", "Low stock", "Out of stock"]
STATUS_TONE = {"In stock": "success", "Low stock": "warning", "Out of stock": "error"}
ROW_CHOICES = ["10", "25", "50", "100"]


def _menu(parent, app, values, command, width=170):
    pal = app.ui.pal
    return ctk.CTkOptionMenu(parent, values=values, command=command, width=width, height=38, fg_color=pal.input_bg, button_color=pal.border,
                             button_hover_color=pal.hover, text_color=pal.text, dropdown_fg_color=pal.card, dropdown_text_color=pal.text,
                             dropdown_hover_color=pal.hover, font=app.ui.font(13), dropdown_font=app.ui.font(13), anchor="w",
                             corner_radius=max(0, app.ui.radius - 3))


class ProductsPage(BasePage):
    def __init__(self, parent, app, spec) -> None:
        super().__init__(parent, app, spec)
        s, get = app.session, app.settings.get
        memory = app.page_memory.get("products") if get("products.remember_filters") else None
        self.f = dict(memory["f"]) if memory else {"search": "", "category": ALL_CAT, "supplier": ALL_SUP, "status": ALL_STATUS}
        self.sort = memory["sort"] if memory else get("products.sort_by")
        self.desc = memory["desc"] if memory else bool(get("products.sort_desc"))
        self.page_no, self.size = 1, int(get("products.page_size"))
        self.cat_ids: dict[str, int] = {}
        self.sup_ids: dict[str, int] = {}
        self._debounce = None
        self._req = 0
        pal = app.ui.pal
        actions = self.header()
        if s.can("products.export"):
            button(actions, app, "Export CSV", self._export, "secondary").pack(side="left", padx=(0, 8))
        if s.can("products.create"):
            button(actions, app, "+ Add product", lambda: ProductDialog(app, None, self.refresh_all)).pack(side="left")
        self.alert = ctk.CTkFrame(self, fg_color=pal.warning_soft, corner_radius=app.ui.radius)
        bar = self.bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", pady=(0, 10))
        self.search = ctk.CTkEntry(bar, placeholder_text="Search name or SKU...  (Ctrl+K)" if get("window.ctrl_k_search") else "Search name or SKU...",
                                   width=300, height=38, fg_color=pal.input_bg, border_color=pal.border, text_color=pal.text,
                                   placeholder_text_color=pal.muted, font=app.ui.font(13), corner_radius=max(0, app.ui.radius - 3))
        self.search.pack(side="left")
        if self.f["search"]:
            self.search.insert(0, self.f["search"])
        self.search.bind("<KeyRelease>", lambda _e: self._search_typed())
        focus_search(app, self.search)
        if get("window.ctrl_k_search"):
            app.bind_all("<Control-k>", lambda _e: self.alive() and self.search.focus_set(), add="+")
        self.cat_menu = _menu(bar, app, [ALL_CAT], lambda v: self._pick("category", v))
        self.sup_menu = _menu(bar, app, [ALL_SUP], lambda v: self._pick("supplier", v))
        self.status_menu = _menu(bar, app, STATUSES, lambda v: self._pick("status", v), 150)
        for m in (self.cat_menu, self.sup_menu, self.status_menu):
            m.pack(side="left", padx=(10, 0))
        self.status_menu.set(self.f["status"])
        self.clear_btn = button(bar, app, "Clear filters", self._clear, "ghost", width=100, height=34)
        self.count_lbl = label(bar, app, "", 12, muted=True)
        self.count_lbl.pack(side="right")
        self.table = DataTable(self, app, self._columns(), on_sort=self._sort_by, empty_text="Loading products...")
        self.table.set_sort(self.sort, self.desc)
        self.table.pack(fill="x")
        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", pady=10)
        self.pager = Pager(foot, app, self._go)
        self.pager.pack(side="left", fill="x", expand=True)
        rows_menu = _menu(foot, app, ROW_CHOICES, self._rows_changed, 80)
        rows_menu.set(str(self.size))
        rows_menu.pack(side="right", padx=(10, 0))
        label(foot, app, "Rows", 12, muted=True).pack(side="right")
        self.summary_lbl = label(self, app, "", 12, muted=True)
        self.summary_lbl.pack(anchor="w", pady=(4, 0))
        self.refresh_all()

    # ---------------------------------------------------------------- columns
    def _columns(self) -> list[Column]:
        app, s, get = self.app, self.app.session, self.app.settings.get
        symbol = get("regional.show_currency_in_tables")
        hdr = f" ({get('regional.currency_symbol')})" if not symbol else ""
        cols = [Column("Name", "Product", weight=1, sortable=True, wrap=300, value=lambda r: r["ProductName"])]
        if get("products.col_sku"):
            cols.append(Column("SKU", "SKU", sortable=True))
        if get("products.col_category"):
            cols.append(Column("Category", "Category", sortable=True, value=lambda r: r["CategoryName"] or "-"))
        if get("products.col_supplier"):
            cols.append(Column("Supplier", "Supplier", sortable=True, value=lambda r: r["SupplierName"] or "-"))
        low = get("products.highlight_low")
        cols.append(Column("Stock", "Stock", sortable=True, value=lambda r: (str(r["Quantity"]), ("error" if r["Quantity"] == 0 else "warning") if low and r["Status"] != "In stock" else None)))
        if get("products.col_cost"):
            cols.append(Column("Cost", "Cost / unit" + hdr, sortable=True, value=lambda r: app.fmt.money(r["PurchasePrice"], bool(symbol))))
        if get("products.col_price"):
            cols.append(Column("Price", "Price" + hdr, sortable=True, value=lambda r: app.fmt.money(r["SellingPrice"], bool(symbol))))
        if get("products.col_status"):
            cols.append(Column("Status", "Status", value=lambda r: (r["Status"], STATUS_TONE[r["Status"]])))
        if get("products.col_updated"):
            cols.append(Column("Updated", "Updated", sortable=True, value=lambda r: app.fmt.datetime(r["UpdatedAt"])))
        cols.append(Column("Actions", "Actions", actions=[
            Action("View", lambda r: ProductDetails(app, r, self.refresh_all)),
            Action("Edit", lambda r: ProductDialog(app, r, self.refresh_all), visible=lambda r: s.can("products.edit")),
            Action("Delete", self._delete, "error", visible=lambda r: s.can("products.delete")),
        ]))
        return cols

    # ---------------------------------------------------------------- filters
    def _remember(self) -> None:
        if self.app.settings.get("products.remember_filters"):
            self.app.page_memory["products"] = {"f": dict(self.f), "sort": self.sort, "desc": self.desc}

    def _search_typed(self) -> None:
        if self._debounce:
            self.after_cancel(self._debounce)
        self._debounce = self.after(int(self.app.settings.get("products.search_delay")), self._apply_search)

    def _apply_search(self) -> None:
        if self.alive():
            self.f["search"] = self.search.get().strip()
            self._go(1)

    def _pick(self, key: str, value: str) -> None:
        self.f[key] = value
        self._go(1)

    def _clear(self) -> None:
        self.f = {"search": "", "category": ALL_CAT, "supplier": ALL_SUP, "status": ALL_STATUS}
        self.search.delete(0, "end")
        self.cat_menu.set(ALL_CAT)
        self.sup_menu.set(ALL_SUP)
        self.status_menu.set(ALL_STATUS)
        self._go(1)

    def _sort_by(self, key: str) -> None:
        self.desc = (not self.desc) if key == self.sort else False
        self.sort = key
        self.table.set_sort(key, self.desc)
        self._go(1)

    def _rows_changed(self, value: str) -> None:
        self.size = int(value)
        self._go(1)

    def _go(self, page: int) -> None:
        self.page_no = max(1, page)
        self._remember()
        self.load()

    def _filters_sql(self) -> dict:
        f = self.f
        return {"search": f["search"], "category_id": self.cat_ids.get(f["category"]), "supplier_id": self.sup_ids.get(f["supplier"]),
                "status": None if f["status"] == ALL_STATUS else f["status"]}

    def _active_filters(self) -> bool:
        f = self.f
        return bool(f["search"] or f["category"] != ALL_CAT or f["supplier"] != ALL_SUP or f["status"] != ALL_STATUS)

    # ---------------------------------------------------------------- loading
    def refresh_all(self) -> None:
        app, sid = self.app, self.app.session.active_store_id

        def work():
            return app.products.lookups(sid), app.products.summary(sid)

        def done(payload) -> None:
            if not self.alive():
                return
            look, summary = payload
            self.cat_ids = {c["CategoryName"]: c["CategoryID"] for c in look["categories"]}
            self.sup_ids = {s["SupplierName"]: s["SupplierID"] for s in look["suppliers"]}
            self.cat_menu.configure(values=[ALL_CAT] + list(self.cat_ids))
            self.sup_menu.configure(values=[ALL_SUP] + list(self.sup_ids))
            for key, ids, default, menu in (("category", self.cat_ids, ALL_CAT, self.cat_menu), ("supplier", self.sup_ids, ALL_SUP, self.sup_menu)):
                if self.f[key] not in ids:
                    self.f[key] = default
                menu.set(self.f[key])
            self._summary(summary)
            self.load()

        app.run_async(work, done, lambda e: (self._empty_error(), app.show_error(e)))

    def _empty_error(self) -> None:
        if self.alive():
            self.table.empty.configure(text="Could not load products. Read the fix steps in the message and press Retry in Settings > Users & Access, or reopen this page.")
            self.table.set_rows([])

    def _summary(self, s: dict) -> None:
        app, pal = self.app, self.app.ui.pal
        self.summary_lbl.configure(text=f"{app.fmt.number(s['Units'])} units on hand \u00b7 {s['Categories']} categories \u00b7 {s['Suppliers']} suppliers"
                                        f" \u00b7 Total inventory value {app.fmt.money(s['CostValue'])}")
        for child in self.alert.winfo_children():
            child.destroy()
        need = s["LowCount"] + s["OutCount"]
        if need and app.settings.get("notify.low_stock_alerts"):
            parts = [f"{s['LowCount']} low" if s["LowCount"] else "", f"{s['OutCount']} out of stock" if s["OutCount"] else ""]
            label(self.alert, app, f"{need} product{'s' if need != 1 else ''} need restocking ({', '.join(p for p in parts if p)})", 13, True, color=pal.warning).pack(side="left", padx=16, pady=12)
            target = "Low stock" if s["LowCount"] else "Out of stock"
            button(self.alert, app, f"Show {target.lower()}", lambda: (self.status_menu.set(target), self._pick("status", target)), "secondary", width=150, height=30).pack(side="right", padx=12)
            self.alert.pack(fill="x", pady=(0, 10), before=self.bar)
        else:
            self.alert.pack_forget()

    def load(self) -> None:
        app, sid = self.app, self.app.session.active_store_id
        self._req += 1
        req, filters, sort, desc, page, size = self._req, self._filters_sql(), self.sort, self.desc, self.page_no, self.size

        def done(payload) -> None:
            if not self.alive() or req != self._req:
                return
            rows, total = payload
            self.pager.set(total, page, size)
            if self.pager.page != page:
                self.page_no = self.pager.page
                return self.load()
            self.table.empty.configure(text="No matching products. Try a different search or press 'Clear filters'." if self._active_filters()
                                       else "No products yet. Click '+ Add product' to create the first one.")
            self.table.set_rows(rows)
            self.count_lbl.configure(text=f"{total} result{'s' if total != 1 else ''}" if self._active_filters() else f"{total} product{'s' if total != 1 else ''}")
            if self._active_filters():
                self.clear_btn.pack(side="left", padx=10)
            else:
                self.clear_btn.pack_forget()

        app.run_async(lambda: app.products.list_page(sid, filters, sort, desc, page, size), done,
                      lambda e: (self._empty_error(), app.show_error(e)))

    # ---------------------------------------------------------------- actions
    def _delete(self, row: dict) -> None:
        app = self.app
        value = float(row["Quantity"]) * float(row["PurchasePrice"])
        if app.settings.get("products.confirm_delete") and not ask_confirm(
                app, "Delete product?", f"You are about to delete '{row['ProductName']}' ({row['SKU']}).", "Delete product", danger=True,
                detail=f"{row['Quantity']} units, {app.fmt.money(value)} will be removed from active inventory. Historical transactions are kept for your audit trail. This cannot be undone."):
            return
        if not reauthenticate(app):
            return

        def done(_r) -> None:
            app.audit.log("product_deleted", app.session, "product", row["ProductID"], f"{row['SKU']} {row['ProductName']}")
            app.toasts.show(f"'{row['ProductName']}' deleted.", "success")
            if self.alive():
                self.refresh_all()

        app.run_async(lambda: app.products.delete(app.session, row["ProductID"]), done)

    def _export(self) -> None:
        app, sid = self.app, self.app.session.active_store_id
        filters, sort, desc = self._filters_sql(), self.sort, self.desc
        money = bool(app.settings.get("reports.csv_currency"))

        def fetch():
            rows, _ = app.products.list_page(sid, filters, sort, desc, 1, 100000)
            fm = (lambda v: app.fmt.money(v)) if money else (lambda v: float(v))
            return [[r["ProductName"], r["SKU"], r["CategoryName"] or "", r["SupplierName"] or "", r["Unit"], r["Quantity"], r["ReorderLevel"],
                     fm(r["PurchasePrice"]), fm(r["SellingPrice"]), r["Status"], fm(float(r["Quantity"]) * float(r["PurchasePrice"])),
                     app.fmt.datetime(r["UpdatedAt"])] for r in rows]

        run_export(app, "products", ["Product", "SKU", "Category", "Supplier", "Unit", "Quantity", "Reorder level", "Unit cost", "Selling price",
                                     "Status", "Stock value (cost)", "Last updated"], fetch)


# ====================================================================== add / edit
class ProductDialog(Dialog):
    def __init__(self, app, row: dict | None, on_saved) -> None:
        super().__init__(app, "Edit product" if row else "Add product", "Update the details below." if row else "Add a new product to this store.",
                         width=640, height=760, scrollable=True)
        self.row, self.on_saved = row, on_saved
        self.holder = ctk.CTkFrame(self.body, fg_color="transparent")
        self.holder.pack(fill="x")
        label(self.holder, app, "Loading categories and suppliers...", 12, muted=True).pack(anchor="w")
        self.btn = self.add_buttons("Save changes" if row else "Create product", self._save)
        self.btn.configure(state="disabled")
        self.form: Form | None = None
        sid, get = app.session.active_store_id, app.settings.get

        def work():
            look = app.products.lookups(sid)
            sku = app.products.suggest_sku(sid, get("inventory.sku_prefix")) if (not row and get("inventory.auto_sku")) else ""
            return look, sku

        app.run_async(work, self._build, lambda e: (self.close(), app.show_error(e)))

    def _build(self, payload) -> None:
        if not self.winfo_exists():
            return
        look, sku = payload
        app, get, row = self.app, self.app.settings.get, self.row
        for child in self.holder.winfo_children():
            child.destroy()
        need_cat, need_sup = get("inventory.require_category"), get("inventory.require_supplier")
        if (need_cat and not look["categories"]) or (need_sup and not look["suppliers"]):
            missing = "category" if need_cat and not look["categories"] else "supplier"
            self.close()
            app.show_error(user_error(f"Create a {missing} first.", f"Products need a {missing}, and this store has none yet.",
                                      [f"Close this window and open {'Categories' if missing == 'category' else 'Suppliers'} in the sidebar.",
                                       f"Click '+ Add {missing}' and save it.", "Come back and press '+ Add product' again.",
                                       f"Or turn off 'Require {missing}' in Settings > Inventory Rules."], "NEED_LOOKUP"))
            return
        self.cats = {c["CategoryName"]: c["CategoryID"] for c in look["categories"]}
        self.sups = {s["SupplierName"]: s["SupplierID"] for s in look["suppliers"]}
        none_c, none_s = "Select a category", "Select a supplier"
        units = [u.strip() for u in str(get("inventory.units_list")).split(",") if u.strip()] or ["Piece"]
        unit = (row or {}).get("Unit") or get("inventory.default_unit")
        if unit not in units:
            units.append(unit)
        host = ctk.CTkFrame(self.holder, fg_color="transparent")
        host.pack(fill="x")
        f = self.form = Form(host, app)
        r = row or {}
        f.entry("name", "Product name", r.get("ProductName", ""), True, placeholder="e.g. USB-C hub 7-in-1")
        f.entry("sku", "SKU", r.get("SKU", sku), True, half=True, placeholder="e.g. ELC-004")
        f.choice("unit", "Unit", units, unit, half=True)
        f.choice("category", "Category", [none_c] + list(self.cats), r.get("CategoryName") or none_c, half=True, required=bool(need_cat))
        f.choice("supplier", "Supplier", [none_s] + list(self.sups), r.get("SupplierName") or none_s, half=True, required=bool(need_sup))
        cost_entry = f.entry("cost", f"Unit cost ({get('regional.currency_symbol')})", f"{r['PurchasePrice']:.2f}" if row else "", True, half=True, placeholder="0.00")
        f.entry("price", f"Selling price ({get('regional.currency_symbol')})", f"{r['SellingPrice']:.2f}" if row else "", bool(get("inventory.require_selling_price")), half=True, placeholder="0.00")
        f.entry("reorder", "Reorder level", str(r["ReorderLevel"]) if row else str(get("inventory.default_reorder_level")), True, half=True)
        if row:
            cell = f.custom(True)
            info = ctk.CTkFrame(cell, fg_color=app.ui.pal.accent_soft, corner_radius=8)
            info.pack(fill="x", pady=(18, 0))
            label(info, app, f"Current stock: {row['Quantity']} {row['Unit']}", 13, True, color=app.ui.pal.accent).pack(anchor="w", padx=14, pady=(8, 0))
            label(info, app, "Use Stock Management to change quantities and keep the audit trail.", 11, muted=True, wraplength=250).pack(anchor="w", padx=14, pady=(0, 8))
        else:
            f.entry("quantity", "Opening stock", "0", True, half=True)
        f.textarea("description", "Description", r.get("Description") or "", 80)
        self._suggested = ""
        if not row and get("inventory.default_markup") is not None:
            cost_entry.bind("<KeyRelease>", lambda _e: self._suggest_price())
        label(self.holder, app, "* Required fields \u00b7 SKU must be unique \u00b7 Costs are stored in " + str(get("regional.currency_symbol")), 11, muted=True).pack(anchor="w", pady=(6, 0))
        self.btn.configure(state="normal")

    def _suggest_price(self) -> None:
        f = self.form
        try:
            cost = Decimal(f.get("cost").replace(",", "."))
            price = (cost * (Decimal(1) + Decimal(str(self.app.settings.get("inventory.default_markup"))) / 100)).quantize(Decimal("0.01"))
        except (InvalidOperation, ValueError):
            return
        if cost >= 0 and f.get("price") in ("", self._suggested):
            self._suggested = f"{price:.2f}"
            f.set_value("price", self._suggested)

    def _collect(self) -> dict:
        f = self.form
        data = {"name": f.get("name"), "sku": f.get("sku"), "unit": f.get("unit"), "cost": f.get("cost"), "price": f.get("price"),
                "reorder": f.get("reorder"), "description": f.get("description"),
                "category_id": self.cats.get(f.get("category")), "supplier_id": self.sups.get(f.get("supplier"))}
        if not self.row:
            data["quantity"] = f.get("quantity")
        return data

    def _save(self) -> None:
        app, f, row = self.app, self.form, self.row
        if f is None:
            return
        f.clear_errors()
        data = self._collect()
        if app.settings.get("inventory.warn_below_cost"):
            try:
                if Decimal(data["price"].replace(",", ".") or "0") > 0 and Decimal(data["price"].replace(",", ".")) < Decimal(data["cost"].replace(",", ".")):
                    if not ask_confirm(app, "Selling price is below cost", "You would lose money on every sale of this product.", "Save anyway",
                                       detail="Fix: raise the selling price, or press 'Save anyway' if this is intentional (clearance, loss leader)."):
                        return
            except InvalidOperation:
                pass  # the service reports the exact bad field
        text = "Save changes" if row else "Create product"

        def work():
            return app.products.update(app.session, row["ProductID"], data) or row["ProductID"] if row else app.products.create(app.session, data)

        def done(product_id) -> None:
            app.audit.log("product_updated" if row else "product_created", app.session, "product", product_id, f"{data['sku'].upper()} {data['name']}")
            app.toasts.show(f"'{data['name']}' saved.", "success")
            self.on_saved()
            if self.winfo_exists():
                self.close()

        submit_form(app, f, self.btn, work, done, text)


# ====================================================================== details
class ProductDetails(Dialog):
    def __init__(self, app, row: dict, on_changed) -> None:
        super().__init__(app, "Product details", width=640, height=700, scrollable=True)
        self.row, self.on_changed = row, on_changed
        self.holder = ctk.CTkFrame(self.body, fg_color="transparent")
        self.holder.pack(fill="x")
        label(self.holder, app, "Loading...", 12, muted=True).pack(anchor="w")
        if app.session.can("products.edit"):
            button(self.footer, app, "Edit product", self._edit, "secondary", width=130).pack(side="left")
        self.add_buttons("Done", self.close, secondary="")
        sid = app.session.active_store_id
        app.run_async(lambda: app.products.detail(sid, row["ProductID"]), self._build, lambda e: (self.close(), app.show_error(e)))

    def _build(self, d: dict) -> None:
        if not self.winfo_exists():
            return
        app, pal = self.app, self.app.ui.pal
        self.detail = d
        for child in self.holder.winfo_children():
            child.destroy()
        head = ctk.CTkFrame(self.holder, fg_color="transparent")
        head.pack(fill="x")
        names = ctk.CTkFrame(head, fg_color="transparent")
        names.pack(side="left")
        label(names, app, d["ProductName"], 17, True).pack(anchor="w")
        label(names, app, d["SKU"], 12, muted=True).pack(anchor="w")
        badge(head, app, d["Status"], STATUS_TONE[d["Status"]]).pack(side="right")
        box = ctk.CTkFrame(self.holder, fg_color=pal.card_alt, corner_radius=8)
        box.pack(fill="x", pady=12)
        box.grid_columnconfigure((0, 1, 2), weight=1, uniform="k")
        value = float(d["Quantity"]) * float(d["PurchasePrice"])
        for i, (t, v) in enumerate([("On hand", f"{d['Quantity']} {d['Unit']}"), ("Unit cost", app.fmt.money(d["PurchasePrice"])), ("Inventory value", app.fmt.money(value))]):
            cell = ctk.CTkFrame(box, fg_color="transparent")
            cell.grid(row=0, column=i, sticky="w", padx=14, pady=12)
            label(cell, app, t, 11, muted=True).pack(anchor="w")
            label(cell, app, v, 14, True).pack(anchor="w")
        grid = ctk.CTkFrame(self.holder, fg_color="transparent")
        grid.pack(fill="x")
        grid.grid_columnconfigure((0, 1), weight=1, uniform="g")
        items = [("Category", d["CategoryName"] or "-"), ("Supplier", d["SupplierName"] or "-"), ("Selling price", app.fmt.money(d["SellingPrice"])),
                 ("Reorder level", f"{d['ReorderLevel']} {d['Unit']}")]
        for i, (t, v) in enumerate(items):
            cell = ctk.CTkFrame(grid, fg_color="transparent")
            cell.grid(row=i // 2, column=i % 2, sticky="w", pady=6)
            label(cell, app, t, 11, muted=True).pack(anchor="w")
            label(cell, app, v, 13).pack(anchor="w")
        label(self.holder, app, "Description", 11, muted=True).pack(anchor="w", pady=(8, 0))
        label(self.holder, app, d["Description"] or "-", 13, wraplength=560).pack(anchor="w")
        label(self.holder, app, "Latest transactions", 14, True).pack(anchor="w", pady=(14, 6))
        prefix = app.settings.get("transactions.id_prefix")
        t = DataTable(self.holder, app, [
            Column("TransactionID", "Transaction", value=lambda r: f"{prefix}{r['TransactionID']} \u00b7 {app.fmt.date(r['TransactionDate'])}"),
            Column("TransactionType", "Type"),
            Column("QuantityChanged", "Change", value=lambda r: (f"{r['QuantityChanged']:+d}", "success" if r["QuantityChanged"] > 0 else "warning")),
            Column("Stock", "Stock", value=lambda r: f"{r['PreviousQuantity']} \u2192 {r['NewQuantity']}")], empty_text="No stock movements recorded yet.")
        t.pack(fill="x")
        t.set_rows(d["Transactions"])
        label(self.holder, app, f"Created {app.fmt.date(d['CreatedAt'])} \u00b7 Last updated {app.fmt.datetime(d['UpdatedAt'])}", 11, muted=True).pack(anchor="w", pady=(12, 0))

    def _edit(self) -> None:
        self.close()
        ProductDialog(self.app, self.row, self.on_changed)
