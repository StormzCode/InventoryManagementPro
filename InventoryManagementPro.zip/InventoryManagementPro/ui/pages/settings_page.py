"""Settings page. Rows are generated from core.settings_registry, so adding a setting there adds it here."""
from __future__ import annotations

from tkinter import colorchooser
from typing import Any

import customtkinter as ctk

from core.errors import user_error
from core.settings_registry import (CATEGORY_ORDER, REGISTRY, SCOPE_LABEL, SETTINGS, THEMES, SettingDef)
from ui.pages import BasePage
from ui.theme import THEME_DATA, theme_key
from ui.widgets import ask_confirm, badge, button, card, focus_search, label, separator

APPEARANCE_KEYS = {"appearance.", "window.always_on_top", "window.opacity"}
MAX_SEARCH_ROWS = 60


class SettingsPage(BasePage):
    def __init__(self, parent, app, spec) -> None:
        super().__init__(parent, app, spec)
        self.pending: dict[str, Any] = {}
        self.visible = [d for d in SETTINGS if d.page is None or d.page in app.pages]
        self.categories = [c for c in CATEGORY_ORDER if any(d.category == c for d in self.visible)]
        self.category = self.categories[0]
        actions = self.header()
        self.discard_btn = button(actions, app, "Discard", self._discard, "secondary", width=90)
        self.discard_btn.pack(side="left", padx=(0, 8))
        self.save_btn = button(actions, app, "Save changes", self._save, width=150)
        self.save_btn.pack(side="left")
        info = f"{len(SETTINGS)} settings available \u00b7 {len(self.visible)} active in this version"
        label(self, app, info, 12, muted=True).pack(anchor="w", pady=(0, 10))
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", pady=(0, 12))
        entry = ctk.CTkEntry(bar, placeholder_text="Search all settings...", width=340, height=38,
                             fg_color=app.ui.pal.input_bg, border_color=app.ui.pal.border, text_color=app.ui.pal.text, placeholder_text_color=app.ui.pal.muted,
                             font=app.ui.font(13), corner_radius=max(0, app.ui.radius - 3))
        entry.pack(side="left")
        self._debounce = None
        self.search_entry = entry
        focus_search(app, entry)
        entry.bind("<KeyRelease>", lambda _e: self._schedule_render())
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(1, weight=1)
        self.cat_card = card(body, app)
        self.cat_card.grid(row=0, column=0, sticky="nw", padx=(0, 16))
        self.panel = card(body, app)
        self.panel.grid(row=0, column=1, sticky="new")
        self._build_categories()
        self._render()
        self._refresh_buttons()

    # ---------------------------------------------------------------- helpers
    def _can_edit(self, d: SettingDef) -> bool:
        s = self.app.session
        if d.scope == "user":
            return s.can("settings.personal")
        if d.scope == "store":
            return s.can("settings.store")
        return s.is_super

    def _who(self, d: SettingDef) -> str:
        return {"user": "Needs the 'change personal settings' permission.",
                "store": "Ask a manager or administrator of this store to change it.",
                "global": "Only a super administrator can change settings for all stores."}[d.scope]

    def _current(self, d: SettingDef) -> Any:
        return self.pending[d.key] if d.key in self.pending else self.app.settings.get(d.key)

    def _stage(self, d: SettingDef, value: Any) -> None:
        saved = d.dump(self.app.settings.get(d.key))
        if d.dump(value) == saved:
            self.pending.pop(d.key, None)
        else:
            self.pending[d.key] = value
        self._refresh_buttons()

    def _refresh_buttons(self) -> None:
        n = len(self.pending)
        self.save_btn.configure(text=f"Save changes ({n})" if n else "Save changes", state="normal" if n else "disabled")
        self.discard_btn.configure(state="normal" if n else "disabled")

    def _discard(self) -> None:
        self.pending.clear()
        self._render()
        self._refresh_buttons()

    # ---------------------------------------------------------------- left column
    def _build_categories(self) -> None:
        app, pal = self.app, self.app.ui.pal
        self.cat_buttons: dict[str, ctk.CTkButton] = {}
        wrap = ctk.CTkFrame(self.cat_card, fg_color="transparent")
        wrap.pack(padx=8, pady=8)
        for cat in self.categories:
            count = sum(1 for d in self.visible if d.category == cat)
            btn = ctk.CTkButton(wrap, text=f"{cat}   {count}", width=210, height=34, anchor="w", fg_color="transparent",
                                hover_color=pal.hover, text_color=pal.muted, font=app.ui.font(13, True),
                                corner_radius=max(0, app.ui.radius - 3), command=lambda c=cat: self._pick(c))
            btn.pack(pady=1)
            self.cat_buttons[cat] = btn

    def _pick(self, cat: str) -> None:
        self.category = cat
        self.search_entry.delete(0, "end")
        self._render()

    def _paint_categories(self, searching: bool) -> None:
        pal = self.app.ui.pal
        for cat, btn in self.cat_buttons.items():
            on = cat == self.category and not searching
            btn.configure(fg_color=pal.accent_soft if on else "transparent", text_color=pal.accent if on else pal.muted)

    # ---------------------------------------------------------------- right column
    def _schedule_render(self) -> None:
        if self._debounce:
            self.after_cancel(self._debounce)
        self._debounce = self.after(250, self._render)

    def _render(self) -> None:
        if not self.alive():
            return
        app, pal = self.app, self.app.ui.pal
        for child in self.panel.winfo_children():
            child.destroy()
        text = self.search_entry.get().strip().lower()
        searching = bool(text)
        self._paint_categories(searching)
        if searching:
            defs = [d for d in self.visible if text in d.label.lower() or text in d.description.lower()
                    or text in d.category.lower() or text in d.key.lower()]
            title = f"{len(defs)} result(s) for '{self.search_entry.get().strip()}'"
            truncated = len(defs) > MAX_SEARCH_ROWS
            defs = defs[:MAX_SEARCH_ROWS]
        else:
            defs = [d for d in self.visible if d.category == self.category]
            title, truncated = self.category, False
        head = ctk.CTkFrame(self.panel, fg_color="transparent")
        head.pack(fill="x", padx=20, pady=(16, 6))
        label(head, app, title, 17, True).pack(side="left")
        if not searching:
            button(head, app, "Reset this section", self._reset_category, "ghost", width=130, height=30).pack(side="right")
        if not searching and self.category == "Appearance":
            self._theme_gallery()
        if not defs:
            label(self.panel, app, "No settings match. Try a shorter word such as 'sidebar', 'currency' or 'password'.", 13,
                  muted=True).pack(anchor="w", padx=20, pady=20)
        for d in defs:
            separator(self.panel, app).pack(fill="x", padx=20)
            self._row(d, show_category=searching)
        if truncated:
            label(self.panel, app, f"Showing the first {MAX_SEARCH_ROWS}. Type more letters to narrow the search.", 12,
                  muted=True).pack(anchor="w", padx=20, pady=10)
        ctk.CTkFrame(self.panel, height=8, fg_color="transparent").pack()

    def _theme_gallery(self) -> None:
        app, pal = self.app, self.app.ui.pal
        d = REGISTRY["appearance.theme"]
        current = self._current(d)
        editable = self._can_edit(d)
        grid = ctk.CTkFrame(self.panel, fg_color="transparent")
        grid.pack(fill="x", padx=20, pady=(4, 10))
        for index, name in enumerate(THEMES):
            data = THEME_DATA["light" if name == "System" else theme_key(name)]
            selected = name == current
            cell = ctk.CTkFrame(grid, fg_color="transparent")
            cell.grid(row=index // 5, column=index % 5, padx=5, pady=5)
            swatch = ctk.CTkFrame(cell, width=116, height=70, fg_color=data["bg"], corner_radius=8,
                                  border_width=3 if selected else 1, border_color=pal.accent if selected else pal.border)
            swatch.pack()
            swatch.pack_propagate(False)
            parts = [ctk.CTkFrame(swatch, width=24, fg_color=data["sidebar"], corner_radius=0),
                     ctk.CTkFrame(swatch, width=64, height=22, fg_color=data["card"], corner_radius=4),
                     ctk.CTkFrame(swatch, width=40, height=8, fg_color=data["accent"], corner_radius=4)]
            parts[0].place(x=3, y=3, relheight=0.9)
            parts[1].place(x=34, y=10)
            parts[2].place(x=34, y=44)
            if name == "System":
                dark = THEME_DATA["dark"]
                half = ctk.CTkFrame(swatch, width=58, fg_color=dark["bg"], corner_radius=0)
                half.place(relx=1.0, x=-3, y=3, anchor="ne", relheight=0.9)
                parts.append(half)
            label(cell, app, name, 12, selected, muted=not selected).pack(pady=(3, 0))
            if editable:
                for widget in [swatch, *parts]:
                    widget.bind("<Button-1>", lambda _e, n=name: self._pick_theme(n))
                    try:
                        widget.configure(cursor="hand2")
                    except Exception:
                        pass

    def _pick_theme(self, name: str) -> None:
        self._stage(REGISTRY["appearance.theme"], name)
        self._render()

    def _row(self, d: SettingDef, show_category: bool) -> None:
        app, pal = self.app, self.app.ui.pal
        editable = self._can_edit(d)
        row = ctk.CTkFrame(self.panel, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=10)
        left = ctk.CTkFrame(row, fg_color="transparent")
        left.pack(side="left", fill="x", expand=True)
        title = ctk.CTkFrame(left, fg_color="transparent")
        title.pack(anchor="w")
        label(title, app, d.label, 13, True).pack(side="left")
        badge(title, app, SCOPE_LABEL[d.scope], "accent" if d.scope == "user" else "neutral").pack(side="left", padx=8)
        if show_category:
            badge(title, app, d.category, "info").pack(side="left")
        if not editable:
            badge(title, app, "Locked", "warning").pack(side="left", padx=6)
        desc = d.description or ""
        if not editable:
            desc = (desc + " " if desc else "") + self._who(d)
        if desc:
            label(left, app, desc, 11, muted=True, wraplength=470).pack(anchor="w", pady=(2, 0))
        right = ctk.CTkFrame(row, fg_color="transparent")
        right.pack(side="right", padx=(12, 0))
        value = self._current(d)
        state = "normal" if editable else "disabled"
        if d.kind == "bool":
            var = ctk.BooleanVar(value=bool(value))
            ctk.CTkSwitch(right, text="", variable=var, width=46, progress_color=pal.accent, button_color="#FFFFFF",
                          fg_color=pal.border, state=state,
                          command=lambda dd=d, v=var: self._stage(dd, bool(v.get()))).pack()
        elif d.kind == "choice":
            var = ctk.StringVar(value=str(value))
            ctk.CTkOptionMenu(right, values=list(d.choices), variable=var, width=200, height=34, fg_color=pal.input_bg,
                              button_color=pal.border, button_hover_color=pal.hover, text_color=pal.text,
                              dropdown_fg_color=pal.card, dropdown_text_color=pal.text, dropdown_hover_color=pal.hover,
                              font=app.ui.font(13), dropdown_font=app.ui.font(13), state=state, anchor="w",
                              corner_radius=max(0, app.ui.radius - 3),
                              command=lambda v, dd=d: (self._stage(dd, v), self._after_choice(dd))).pack()
        else:
            var = ctk.StringVar(value="" if value is None else str(value))
            entry = ctk.CTkEntry(right, textvariable=var, width=200, height=34, state=state, fg_color=pal.input_bg,
                                 border_color=pal.border, text_color=pal.text, font=app.ui.font(13),
                                 corner_radius=max(0, app.ui.radius - 3))
            if d.kind == "color":
                swatch = ctk.CTkFrame(right, width=26, height=26, corner_radius=6, border_width=1, border_color=pal.border,
                                      fg_color=str(value) if str(value).startswith("#") and len(str(value)) == 7 else pal.card)
                swatch.pack(side="left", padx=(0, 6))
                if editable:
                    button(right, app, "Pick", lambda dd=d, v=var, sw=swatch: self._choose_color(dd, v, sw), "secondary",
                           width=50, height=34).pack(side="right", padx=(6, 0))
                var.trace_add("write", lambda *_a, v=var, sw=swatch: self._tint(sw, v.get()))
            entry.pack(side="left")
            var.trace_add("write", lambda *_a, dd=d, v=var: self._stage(dd, v.get()))
        if editable and d.dump(value) != d.dump(d.default):
            button(row, app, "Reset", lambda dd=d: self._reset_one(dd), "ghost", width=52, height=28).pack(side="right")

    def _tint(self, swatch, text: str) -> None:
        if len(text.strip()) == 7 and text.startswith("#"):
            try:
                swatch.configure(fg_color=text.strip())
            except Exception:
                pass

    def _choose_color(self, d: SettingDef, var, swatch) -> None:
        picked = colorchooser.askcolor(color=var.get() or self.app.ui.pal.accent, parent=self.app, title="Pick a colour")
        if picked and picked[1]:
            var.set(picked[1].upper())

    def _after_choice(self, d: SettingDef) -> None:
        if d.key == "appearance.theme":
            self.after(20, self._render)  # rebuild after the dropdown has closed

    def _reset_one(self, d: SettingDef) -> None:
        self._stage(d, d.default)
        self._render()

    # ---------------------------------------------------------------- actions
    def _reset_category(self) -> None:
        keys = [d.key for d in self.visible if d.category == self.category and self._can_edit(d)]
        if not keys:
            self.app.show_error(user_error("Nothing here can be reset by you.", "Every setting in this section is locked for your role.",
                                           ["Ask a manager or administrator to reset it, or pick another section."]))
            return
        if not ask_confirm(self.app, "Reset this section?", f"Every setting in '{self.category}' you may edit returns to its default.",
                           "Reset", detail="Unsaved changes in this section are discarded too."):
            return
        for key in keys:
            self.pending.pop(key, None)

        def done(_r) -> None:
            if self.alive():
                self.app.on_settings_changed(set(keys))
            if self.alive():
                self._render()
                self._refresh_buttons()

        self.app.run_async(lambda: self.app.settings.reset(keys), done, lambda e: self.app.show_error(e))

    def _save(self) -> None:
        app = self.app
        changes: dict[str, Any] = {}
        for key, raw in self.pending.items():
            d = REGISTRY[key]
            value, err = d.validate(raw)
            if err:
                app.show_error(user_error(f"'{d.label}' is not valid.", f"The value '{raw}' cannot be used.",
                                          [f"Open {d.category} > {d.label} and {err}.", "Then press Save changes again."], "SETTING_INVALID"))
                return
            changes[key] = value
        self.save_btn.configure(state="disabled", text="Saving...")

        def done(_r) -> None:
            if not self.alive():
                return
            if app.settings.get("audit.log_settings"):
                app.audit.log("settings_changed", app.session, "settings", None, ", ".join(sorted(changes))[:900])
            self.pending.clear()
            app.toasts.show(f"{len(changes)} setting(s) saved.", "success")
            app.on_settings_changed(set(changes))
            if self.alive():
                self._render()
                self._refresh_buttons()

        def failed(exc: BaseException) -> None:
            if self.alive():
                self._refresh_buttons()
            app.show_error(exc)

        app.run_async(lambda: app.settings.save(changes), done, failed)
