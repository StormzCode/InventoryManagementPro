"""DataTable (one aligned grid, fast plain-tk labels) and Pager."""
from __future__ import annotations

import tkinter as tk
from dataclasses import dataclass, field
from typing import Any, Callable

import customtkinter as ctk

from ui.widgets import button, label


@dataclass
class Action:
    text: str
    command: Callable[[dict], None]
    tone: str = "accent"                      # accent | error | muted
    visible: Callable[[dict], bool] | None = None


@dataclass
class Column:
    key: str
    title: str
    value: Callable[[dict], Any] | None = None   # returns str or (str, tone) ; tone: success|warning|error|muted|accent
    weight: int = 0
    wrap: int = 220
    sortable: bool = False
    actions: list[Action] = field(default_factory=list)


class DataTable(ctk.CTkFrame):
    def __init__(self, parent, app, columns: list[Column], on_sort: Callable[[str], None] | None = None,
                 empty_text: str = "Nothing to show yet.") -> None:
        ui, pal = app.ui, app.ui.pal
        super().__init__(parent, fg_color=pal.card, corner_radius=ui.radius,
                         border_width=1 if ui.card_border else 0, border_color=pal.border)
        self.app, self.columns, self.on_sort, self.empty_text = app, columns, on_sort, empty_text
        self.sort_key, self.sort_desc = "", False
        self.grid_frame = tk.Frame(self, bg=pal.card)
        self.grid_frame.pack(fill="x", padx=2, pady=2)
        for i, col in enumerate(columns):
            self.grid_frame.grid_columnconfigure(i, weight=col.weight)
        self._rows: list[list[tk.Widget]] = []
        self._build_header()
        self.empty = ctk.CTkLabel(self, text=empty_text, font=ui.font(13), text_color=pal.muted, height=90)

    def _tone_color(self, tone: str | None) -> str:
        pal = self.app.ui.pal
        return {"success": pal.success, "warning": pal.warning, "error": pal.error, "muted": pal.muted,
                "accent": pal.accent}.get(tone or "", pal.text)

    def _build_header(self) -> None:
        pal, ui = self.app.ui.pal, self.app.ui
        for i, col in enumerate(self.columns):
            title = col.title.upper() if ui.upper_headers else col.title
            if col.key == self.sort_key:
                title += "  " + ("\u2191" if self.sort_desc else "\u2193")
            lbl = tk.Label(self.grid_frame, text=title, bg=pal.card_alt, fg=pal.muted, anchor="w",
                           font=ui.tk_font(self, 11, True), padx=14, pady=10,
                           cursor="hand2" if col.sortable and self.on_sort else "")
            lbl.grid(row=0, column=i, sticky="nsew")
            if col.sortable and self.on_sort:
                lbl.bind("<Button-1>", lambda _e, k=col.key: self.on_sort(k))

    def set_sort(self, key: str, desc: bool) -> None:
        self.sort_key, self.sort_desc = key, desc
        for child in self.grid_frame.grid_slaves(row=0):
            child.destroy()
        self._build_header()

    def set_rows(self, rows: list[dict]) -> None:
        pal, ui = self.app.ui.pal, self.app.ui
        for group in self._rows:
            for widget in group:
                widget.destroy()
        self._rows.clear()
        for child in self.grid_frame.grid_slaves():
            if int(child.grid_info()["row"]) > 0:
                child.destroy()
        if not rows:
            self.empty.pack(fill="x")
            return
        self.empty.pack_forget()
        pad_y = max(4, (ui.row_height - 18) // 2)
        for r, row in enumerate(rows):
            bg = pal.card_alt if (ui.zebra and r % 2 == 1) else pal.card
            group: list[tk.Widget] = []
            for c, col in enumerate(self.columns):
                if col.actions:
                    cell = tk.Frame(self.grid_frame, bg=bg)
                    visible = [a for a in col.actions if a.visible is None or a.visible(row)]
                    for index, action in enumerate(visible):
                        color = {"error": pal.error, "muted": pal.muted}.get(action.tone, pal.accent)
                        link = tk.Label(cell, text=action.text, bg=bg, fg=color, cursor="hand2",
                                        font=ui.tk_font(self, 12, True), pady=pad_y)
                        link.pack(side="left")
                        link.bind("<Button-1>", lambda _e, a=action, rw=row: a.command(rw))
                        if index < len(visible) - 1:
                            tk.Label(cell, text=" \u00b7 ", bg=bg, fg=pal.muted, font=ui.tk_font(self, 12)).pack(side="left")
                    cell.grid(row=r * 2 + 1, column=c, sticky="nsew", padx=(10, 4))
                    group.append(cell)
                    continue
                raw = col.value(row) if col.value else row.get(col.key, "")
                text, tone = raw if isinstance(raw, tuple) else (raw, None)
                lbl = tk.Label(self.grid_frame, text="" if text is None else str(text), bg=bg, anchor="w",
                               justify="left", fg=self._tone_color(tone), font=ui.tk_font(self, 12),
                               wraplength=col.wrap, padx=14, pady=pad_y)
                lbl.grid(row=r * 2 + 1, column=c, sticky="nsew")
                group.append(lbl)
            if ui.hover_rows:
                hover = pal.hover
                for widget in group:
                    widget.bind("<Enter>", lambda _e, g=group, h=hover: self._paint(g, h))
                    widget.bind("<Leave>", lambda _e, g=group, b=bg: self._paint(g, b))
            sep = tk.Frame(self.grid_frame, height=1, bg=pal.border)
            sep.grid(row=r * 2 + 2, column=0, columnspan=len(self.columns), sticky="ew")
            group.append(sep)
            self._rows.append(group)

    @staticmethod
    def _paint(group: list[tk.Widget], color: str) -> None:
        for widget in group[:-1]:
            try:
                widget.configure(bg=color)
                for child in widget.winfo_children():
                    child.configure(bg=color)
            except tk.TclError:
                pass


class Pager(ctk.CTkFrame):
    def __init__(self, parent, app, on_page: Callable[[int], None]) -> None:
        super().__init__(parent, fg_color="transparent")
        self.app, self.on_page = app, on_page
        self.page, self.pages = 1, 1
        self.info = label(self, app, "", 12, muted=True)
        self.info.pack(side="left")
        self.next_btn = button(self, app, "Next", lambda: self._go(1), "secondary", width=70, height=30)
        self.next_btn.pack(side="right")
        self.page_lbl = label(self, app, "1 / 1", 12, muted=True)
        self.page_lbl.pack(side="right", padx=10)
        self.prev_btn = button(self, app, "Previous", lambda: self._go(-1), "secondary", width=80, height=30)
        self.prev_btn.pack(side="right")

    def set(self, total: int, page: int, size: int) -> None:
        self.pages = max(1, -(-total // size))
        self.page = min(max(1, page), self.pages)
        first = 0 if total == 0 else (self.page - 1) * size + 1
        last = min(total, self.page * size)
        self.info.configure(text=f"Showing {first}-{last} of {total}")
        self.page_lbl.configure(text=f"{self.page} / {self.pages}")
        self.prev_btn.configure(state="normal" if self.page > 1 else "disabled")
        self.next_btn.configure(state="normal" if self.page < self.pages else "disabled")

    def _go(self, step: int) -> None:
        self.on_page(self.page + step)
