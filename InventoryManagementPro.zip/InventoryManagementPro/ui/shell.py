"""Main window layout: sidebar (permission-filtered), header with user menu, scrolling page area."""
from __future__ import annotations

import tkinter as tk

import customtkinter as ctk

from core.config import APP_VERSION
from ui.pages import NAV_ORDER
from ui.widgets import ask_confirm, label


class MainShell(ctk.CTkFrame):
    def __init__(self, app, first_page: str) -> None:
        pal = app.ui.pal
        super().__init__(app, fg_color=pal.bg)
        self.app = app
        self.collapsed = app.collapsed_override if app.collapsed_override is not None else bool(app.settings.get("appearance.sidebar_collapsed"))
        self.nav: dict[str, ctk.CTkButton] = {}
        self.current = ""
        self.page = None
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_sidebar()
        main = ctk.CTkFrame(self, fg_color=pal.bg, corner_radius=0)
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(1, weight=1)
        self._build_header(main)
        self.content = ctk.CTkScrollableFrame(main, fg_color=pal.bg, corner_radius=0)
        self.content.grid(row=1, column=0, sticky="nsew")
        self.show_page(first_page)
        if app.settings.get("appearance.show_connection_status"):
            self.after(300, self._ping)

    # ---------------------------------------------------------------- sidebar
    def visible_pages(self) -> list:
        app = self.app
        return [app.pages[k] for k in NAV_ORDER if k in app.pages and app.session.can_any(app.pages[k].perms)]

    def _build_sidebar(self) -> None:
        app, pal, ui = self.app, self.app.ui.pal, self.app.ui
        width = 76 if self.collapsed else app.settings.get("appearance.sidebar_width")
        side = ctk.CTkFrame(self, width=width, fg_color=pal.sidebar, corner_radius=0, border_width=0)
        side.grid(row=0, column=0, sticky="ns")
        side.grid_propagate(False)
        side.pack_propagate(False)
        self.sidebar = side
        top = ctk.CTkFrame(side, fg_color="transparent")
        top.pack(fill="x", padx=14, pady=(18, 10))
        logo = ctk.CTkLabel(top, text="I", width=38, height=38, corner_radius=10, fg_color=pal.accent,
                            text_color=pal.accent_text, font=ui.font(18, True))
        logo.pack(side="left")
        if not self.collapsed:
            names = ctk.CTkFrame(top, fg_color="transparent")
            names.pack(side="left", padx=10)
            label(names, app, "Inventory", 14, True).pack(anchor="w")
            label(names, app, "Management Pro", 11, muted=True).pack(anchor="w")
        if not self.collapsed and app.settings.get("appearance.sidebar_store_switcher"):
            names = [a.store_name for a in app.session.accesses.values()]
            current = app.session.store_name
            self.store_menu = ctk.CTkOptionMenu(side, values=names, command=self._switch_store, height=36,
                                                fg_color=pal.card_alt, button_color=pal.border,
                                                button_hover_color=pal.hover, text_color=pal.text,
                                                dropdown_fg_color=pal.card, dropdown_text_color=pal.text,
                                                dropdown_hover_color=pal.hover, font=ui.font(13, True),
                                                dropdown_font=ui.font(13), anchor="w",
                                                corner_radius=max(0, ui.radius - 2))
            self.store_menu.set(current)
            self.store_menu.pack(fill="x", padx=14, pady=(4, 6))
            if len(names) == 1:
                self.store_menu.configure(state="disabled", text_color_disabled=pal.text)
            label(side, app, "WORKSPACE", 10, True, muted=True).pack(anchor="w", padx=18, pady=(12, 4))
        icons = app.settings.get("appearance.sidebar_icons")
        for spec in self.visible_pages():
            if self.collapsed:
                text = spec.icon
            else:
                text = f"{spec.icon}   {spec.title}" if icons else spec.title
            btn = ctk.CTkButton(side, text=text, anchor="center" if self.collapsed else "w", height=40,
                                corner_radius=max(0, ui.radius - 2), fg_color="transparent", hover_color=pal.hover,
                                text_color=pal.muted, font=ui.font(13, True),
                                command=lambda k=spec.key: self.show_page(k))
            btn.pack(fill="x", padx=12, pady=2)
            self.nav[spec.key] = btn
        bottom = ctk.CTkFrame(side, fg_color="transparent")
        bottom.pack(side="bottom", fill="x", padx=14, pady=14)
        ctk.CTkButton(bottom, text="\u00bb" if self.collapsed else "\u00ab  Collapse", height=30, anchor="center" if self.collapsed else "w",
                      fg_color="transparent", hover_color=pal.hover, text_color=pal.muted, font=ui.font(12),
                      command=self._toggle_collapse).pack(fill="x")
        if app.settings.get("appearance.show_connection_status"):
            self.status = ctk.CTkLabel(bottom, text="\u25cf" if self.collapsed else "\u25cf  Checking database...",
                                       font=ui.font(11), text_color=pal.muted, anchor="w")
            self.status.pack(fill="x", pady=(6, 0))
        if not self.collapsed:
            label(bottom, app, f"v{APP_VERSION} \u00b7 Desktop application", 10, muted=True).pack(anchor="w", pady=(2, 0))

    def _toggle_collapse(self) -> None:
        self.app.rebuild_ui(self.current, collapsed=not self.collapsed)

    def _switch_store(self, name: str) -> None:
        for access in self.app.session.accesses.values():
            if access.store_name == name:
                self.app.switch_store(access.store_id)
                return

    def _ping(self) -> None:
        if not self.winfo_exists():
            return
        app = self.app

        def done(ok: bool) -> None:
            if not self.winfo_exists() or not hasattr(self, "status"):
                return
            pal = app.ui.pal
            text = "\u25cf" if self.collapsed else ("\u25cf  Database connected" if ok else "\u25cf  Database not reachable")
            self.status.configure(text=text, text_color=pal.success if ok else pal.error)

        app.run_async(app.db.ping, done, lambda _e: done(False))
        self.after(int(app.settings.get("system.status_ping_seconds")) * 1000, self._ping)

    # ---------------------------------------------------------------- header
    def _build_header(self, main) -> None:
        app, pal, ui = self.app, self.app.ui.pal, self.app.ui
        bar = ctk.CTkFrame(main, height=62, fg_color=pal.bg, corner_radius=0)
        bar.grid(row=0, column=0, sticky="ew")
        bar.grid_propagate(False)
        ctk.CTkFrame(main, height=1, fg_color=pal.border, corner_radius=0).grid(row=0, column=0, sticky="sew")
        self.crumb = label(bar, app, "", 12, muted=True)
        if app.settings.get("appearance.show_breadcrumb"):
            self.crumb.pack(side="left", padx=app.ui.padding)
        user = app.session.user
        initials = "".join(p[0] for p in user["FullName"].split()[:2]).upper() or "?"
        chip = ctk.CTkButton(bar, text=f"{initials}   {user['FullName']}  \u25be", height=38, fg_color="transparent",
                             hover_color=pal.hover, text_color=pal.text, border_width=1, border_color=pal.border,
                             corner_radius=max(0, ui.radius), font=ui.font(13, True))
        chip.configure(command=lambda b=chip: self._user_menu(b))
        chip.pack(side="right", padx=app.ui.padding)
        ctk.CTkLabel(bar, text=app.session.active.role_name, font=ui.font(11, True), text_color=pal.accent,
                     fg_color=pal.accent_soft, corner_radius=6, height=22).pack(side="right")

    def _user_menu(self, anchor) -> None:
        app, pal = self.app, self.app.ui.pal
        menu = tk.Menu(app, tearoff=0, bg=pal.card, fg=pal.text, activebackground=pal.accent,
                       activeforeground=pal.accent_text, bd=0, relief="flat")
        menu.add_command(label=f"Signed in as {app.session.user['Username']}", state="disabled")
        menu.add_separator()
        menu.add_command(label="Change my password", command=app.open_change_password)
        menu.add_command(label="Sign out", command=lambda: app.logout())
        menu.tk_popup(anchor.winfo_rootx(), anchor.winfo_rooty() + anchor.winfo_height() + 4)

    # ---------------------------------------------------------------- navigation
    def show_page(self, key: str) -> None:
        app, pal = self.app, self.app.ui.pal
        allowed = {s.key for s in self.visible_pages()}
        if key not in allowed:
            key = next(iter(allowed), "")
        if not key:
            return
        if self.page is not None:
            self.page.destroy()
        self.current = key
        for k, btn in self.nav.items():
            active = k == key
            btn.configure(fg_color=pal.accent_soft if active else "transparent",
                          text_color=pal.accent if active else pal.muted)
        spec = app.pages[key]
        if app.settings.get("appearance.show_breadcrumb"):
            self.crumb.configure(text=f"{app.session.store_name}  \u203a  {spec.title}")
        self.page = spec.factory(self.content, app, spec)
        pad = app.ui.padding
        self.page.pack(fill="both", expand=True, padx=pad, pady=pad)
        try:
            self.content._parent_canvas.yview_moveto(0)
        except Exception:
            pass
