"""Colour themes and the UIContext (palette, fonts, sizes) shared by every widget."""
from __future__ import annotations

import re
from types import SimpleNamespace

import customtkinter as ctk

_LIGHT = dict(mode="light", bg="#F4F6FB", sidebar="#FFFFFF", card="#FFFFFF", card_alt="#F8FAFC", border="#E2E8F0",
              text="#0F172A", muted="#64748B", accent="#6366F1", accent_hover="#4F46E5", accent_text="#FFFFFF",
              accent_soft="#EEF2FF", success="#16A34A", success_soft="#DCFCE7", warning="#D97706",
              warning_soft="#FEF3C7", error="#DC2626", error_soft="#FEE2E2", info_soft="#E0E7FF",
              input_bg="#FFFFFF", hover="#F1F5F9")
_DARK = dict(mode="dark", bg="#0B1120", sidebar="#111827", card="#172033", card_alt="#131B2E", border="#263149",
             text="#F8FAFC", muted="#94A3B8", accent="#6366F1", accent_hover="#818CF8", accent_text="#FFFFFF",
             accent_soft="#252B57", success="#22C55E", success_soft="#12341F", warning="#F59E0B",
             warning_soft="#3A2A0E", error="#EF4444", error_soft="#3B1818", info_soft="#252B57",
             input_bg="#0F172A", hover="#1E293B")

THEME_DATA = {
    "light": _LIGHT,
    "dark": _DARK,
    "ocean": {**_LIGHT, "bg": "#F0F9FF", "card_alt": "#F5FBFF", "border": "#BAE6FD", "text": "#0C4A6E",
              "muted": "#5B7C99", "accent": "#0284C7", "accent_hover": "#0369A1", "accent_soft": "#E0F2FE",
              "info_soft": "#E0F2FE", "hover": "#E8F6FE"},
    "forest": {**_LIGHT, "bg": "#F3F8F4", "card_alt": "#F7FBF8", "border": "#CFE3D4", "text": "#14301F",
               "muted": "#5C7A66", "accent": "#15803D", "accent_hover": "#166534", "accent_soft": "#DCFCE7",
               "info_soft": "#DCFCE7", "hover": "#EAF4EC"},
    "sunset": {**_LIGHT, "bg": "#FFF7ED", "card_alt": "#FFFAF4", "border": "#FED7AA", "text": "#431407",
               "muted": "#9A6B4F", "accent": "#EA580C", "accent_hover": "#C2410C", "accent_soft": "#FFEDD5",
               "info_soft": "#FFEDD5", "hover": "#FFF0E0"},
    "rose": {**_LIGHT, "bg": "#FFF1F5", "card_alt": "#FFF7F9", "border": "#FBCFE8", "text": "#500724",
             "muted": "#9D6B80", "accent": "#DB2777", "accent_hover": "#BE185D", "accent_soft": "#FCE7F3",
             "info_soft": "#FCE7F3", "hover": "#FDE8F0"},
    "midnight": {**_DARK, "bg": "#080B1A", "sidebar": "#0E1330", "card": "#141A3D", "card_alt": "#10163A",
                 "border": "#252D63", "text": "#EEF2FF", "muted": "#9AA4D6", "accent": "#8B5CF6",
                 "accent_hover": "#A78BFA", "accent_soft": "#2A2257", "info_soft": "#2A2257", "input_bg": "#0B1030",
                 "hover": "#1B2250"},
    "graphite": {**_DARK, "bg": "#121212", "sidebar": "#1A1A1A", "card": "#212121", "card_alt": "#1B1B1B",
                 "border": "#333333", "text": "#F5F5F5", "muted": "#A3A3A3", "accent": "#10B981",
                 "accent_hover": "#34D399", "accent_soft": "#123D31", "info_soft": "#123D31", "input_bg": "#171717",
                 "hover": "#2A2A2A"},
    "high_contrast": {**_DARK, "bg": "#000000", "sidebar": "#000000", "card": "#0A0A0A", "card_alt": "#000000",
                      "border": "#FFFFFF", "text": "#FFFFFF", "muted": "#E5E5E5", "accent": "#FFD400",
                      "accent_hover": "#FFE55C", "accent_text": "#000000", "accent_soft": "#2A2400",
                      "info_soft": "#2A2400", "success": "#00FF7F", "warning": "#FFD400", "error": "#FF6B6B",
                      "input_bg": "#000000", "hover": "#1A1A1A"},
}


def theme_key(name: str) -> str:
    return name.strip().lower().replace(" ", "_")


def _hex_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)


def blend(a: str, b: str, t: float) -> str:
    """Mix colour a into b by fraction t (0..1)."""
    ra, ga, ba = _hex_rgb(a)
    rb, gb, bb = _hex_rgb(b)
    return "#%02X%02X%02X" % (round(rb + (ra - rb) * t), round(gb + (ga - gb) * t), round(bb + (ba - bb) * t))


def resolve_theme(name: str) -> str:
    key = theme_key(name)
    if key == "system":
        try:
            import darkdetect
            return "dark" if darkdetect.isDark() else "light"
        except Exception:
            return "light"
    return key if key in THEME_DATA else "light"


class UIContext:
    def __init__(self) -> None:
        self.pal = SimpleNamespace(**THEME_DATA["light"])
        self.theme = "light"
        self.font_family = "Segoe UI"
        self.font_scale = 1.0
        self.radius = 10
        self.compact = False
        self.row_height = 44
        self.padding = 28
        self.card_border = True
        self.zebra = True
        self.hover_rows = True
        self.upper_headers = False
        self._fonts: dict = {}

    def configure(self, theme_name: str, accent: str = "", family: str = "Segoe UI", font_scale: float = 1.0,
                  radius: int = 10, compact: bool = False, row_height: int = 44, padding: int = 28,
                  card_border: bool = True, zebra: bool = True, hover_rows: bool = True,
                  upper_headers: bool = False) -> None:
        self.theme = resolve_theme(theme_name)
        data = dict(THEME_DATA[self.theme])
        if accent and re.fullmatch(r"#[0-9A-Fa-f]{6}", accent):
            data["accent"] = accent.upper()
            data["accent_hover"] = blend("#000000", accent, 0.18)
            data["accent_soft"] = blend(accent, data["card"], 0.16)
            data["info_soft"] = data["accent_soft"]
            r, g, b = _hex_rgb(accent)
            data["accent_text"] = "#000000" if (r * 299 + g * 587 + b * 114) / 1000 > 160 else "#FFFFFF"
        self.pal = SimpleNamespace(**data)
        self.font_family, self.font_scale, self.radius = family, font_scale, radius
        self.compact = compact
        self.row_height = max(24, row_height - (8 if compact else 0))
        self.padding = max(6, padding - (8 if compact else 0))
        self.card_border, self.zebra, self.hover_rows = card_border, zebra, hover_rows
        self.upper_headers = upper_headers
        self._fonts.clear()
        ctk.set_appearance_mode("dark" if data["mode"] == "dark" else "light")

    def font(self, size: int = 13, bold: bool = False) -> ctk.CTkFont:
        key = (size, bold)
        if key not in self._fonts:
            self._fonts[key] = ctk.CTkFont(family=self.font_family, size=max(8, round(size * self.font_scale)),
                                           weight="bold" if bold else "normal")
        return self._fonts[key]

    def tk_font(self, widget, size: int = 12, bold: bool = False) -> tuple:
        """A plain-tkinter font tuple (pixels) that follows the interface zoom."""
        try:
            from customtkinter.windows.widgets.scaling import ScalingTracker
            zoom = ScalingTracker.get_widget_scaling(widget)
        except Exception:
            zoom = 1.0
        px = max(9, round(size * self.font_scale * zoom * 1.0))
        return (self.font_family, -px, "bold") if bold else (self.font_family, -px)
