"""Reusable UI building blocks. Every widget reads colours/fonts from app.ui so themes apply everywhere."""
from __future__ import annotations

import tkinter as tk
from typing import Any, Callable

import customtkinter as ctk

from core.errors import FieldError, Guidance

TONES = {  # tone -> (foreground key, background key)
    "neutral": ("muted", "hover"), "success": ("success", "success_soft"), "warning": ("warning", "warning_soft"),
    "error": ("error", "error_soft"), "info": ("accent", "accent_soft"), "accent": ("accent", "accent_soft"),
}


def label(parent, app, text: str = "", size: int = 13, bold: bool = False, muted: bool = False,
          color: str | None = None, **kw) -> ctk.CTkLabel:
    pal = app.ui.pal
    kw.setdefault("anchor", "w")
    kw.setdefault("justify", "left")
    return ctk.CTkLabel(parent, text=text, font=app.ui.font(size, bold),
                        text_color=color or (pal.muted if muted else pal.text), **kw)


def button(parent, app, text: str, command: Callable | None = None, kind: str = "primary", width: int = 0,
           height: int = 36, **kw) -> ctk.CTkButton:
    pal, ui = app.ui.pal, app.ui
    styles = {
        "primary": dict(fg_color=pal.accent, hover_color=pal.accent_hover, text_color=pal.accent_text, border_width=0),
        "danger": dict(fg_color=pal.error, hover_color=pal.error, text_color="#FFFFFF", border_width=0),
        "secondary": dict(fg_color=pal.card, hover_color=pal.hover, text_color=pal.text, border_width=1, border_color=pal.border),
        "ghost": dict(fg_color="transparent", hover_color=pal.hover, text_color=pal.text, border_width=0),
    }
    style = styles[kind]
    if width:
        kw["width"] = width
    return ctk.CTkButton(parent, text=text, command=command, height=height, corner_radius=max(0, ui.radius - 2),
                         font=ui.font(13, kind == "primary"), **style, **kw)


def card(parent, app, **kw) -> ctk.CTkFrame:
    pal, ui = app.ui.pal, app.ui
    return ctk.CTkFrame(parent, fg_color=pal.card, corner_radius=ui.radius, border_width=1 if ui.card_border else 0,
                        border_color=pal.border, **kw)


def badge(parent, app, text: str, tone: str = "neutral") -> ctk.CTkLabel:
    fg, bg = TONES[tone]
    pal = app.ui.pal
    return ctk.CTkLabel(parent, text=f" {text} ", font=app.ui.font(11, True), text_color=getattr(pal, fg),
                        fg_color=getattr(pal, bg), corner_radius=6, height=22)


def separator(parent, app) -> ctk.CTkFrame:
    return ctk.CTkFrame(parent, height=1, fg_color=app.ui.pal.border, corner_radius=0)


class Form:
    """Vertical form on a 2-column grid. Each field has an inline error line that shows the exact fix."""

    def __init__(self, parent, app) -> None:
        self.parent, self.app = parent, app
        parent.grid_columnconfigure((0, 1), weight=1, uniform="form")
        self._row, self._col = 0, 0
        self._getters: dict[str, Callable[[], Any]] = {}
        self._errors: dict[str, ctk.CTkLabel] = {}
        self._widgets: dict[str, Any] = {}
        self._vars: dict[str, Any] = {}

    def _cell(self, half: bool) -> ctk.CTkFrame:
        if half:
            col, row = self._col, self._row
            if col == 1:
                self._row += 1
            self._col = 1 - col
            span = 1
        else:
            if self._col == 1:
                self._row += 1
                self._col = 0
            col, row, span = 0, self._row, 2
            self._row += 1
        cell = ctk.CTkFrame(self.parent, fg_color="transparent")
        cell.grid(row=row, column=col, columnspan=span, sticky="ew", padx=(0, 10) if (half and col == 0) else 0, pady=(0, 4))
        return cell

    def _header(self, cell, key: str, text: str, required: bool) -> None:
        label(cell, self.app, text + (" *" if required else ""), 12, muted=True).pack(anchor="w", pady=(0, 3))

    def _footer(self, cell, key: str) -> None:
        err = label(cell, self.app, "", 11, color=self.app.ui.pal.error, wraplength=440)
        err.pack(anchor="w")
        self._errors[key] = err

    def _entry_style(self) -> dict:
        pal = self.app.ui.pal
        return dict(fg_color=pal.input_bg, border_color=pal.border, text_color=pal.text, placeholder_text_color=pal.muted, height=36,
                    corner_radius=max(0, self.app.ui.radius - 3), font=self.app.ui.font(13))

    def entry(self, key: str, text: str, value: str = "", required: bool = False, show: str | None = None,
              placeholder: str = "", half: bool = False, readonly: bool = False) -> ctk.CTkEntry:
        cell = self._cell(half)
        self._header(cell, key, text, required)
        entry = ctk.CTkEntry(cell, placeholder_text=placeholder, show=show or "", **self._entry_style())
        entry.pack(fill="x")
        if value:
            entry.insert(0, value)
        if readonly:
            entry.configure(state="disabled", text_color=self.app.ui.pal.muted)
        self._footer(cell, key)
        # passwords are never trimmed; everything else is
        self._getters[key] = (lambda e=entry: e.get()) if show else (lambda e=entry: e.get().strip())
        self._widgets[key] = entry
        return entry

    def choice(self, key: str, text: str, values: list[str], value: str = "", half: bool = False,
               required: bool = False) -> ctk.CTkOptionMenu:
        cell = self._cell(half)
        self._header(cell, key, text, required)
        pal = self.app.ui.pal
        var = ctk.StringVar(value=value if value in values else (values[0] if values else ""))
        menu = ctk.CTkOptionMenu(cell, values=values or [""], variable=var, height=36, fg_color=pal.input_bg,
                                 button_color=pal.border, button_hover_color=pal.hover, text_color=pal.text,
                                 dropdown_fg_color=pal.card, dropdown_text_color=pal.text,
                                 dropdown_hover_color=pal.hover, font=self.app.ui.font(13),
                                 dropdown_font=self.app.ui.font(13), corner_radius=max(0, self.app.ui.radius - 3),
                                 anchor="w")
        menu.pack(fill="x")
        self._footer(cell, key)
        self._getters[key] = lambda v=var: v.get()
        self._widgets[key], self._vars[key] = menu, var
        return menu

    def check(self, key: str, text: str, value: bool = False, half: bool = False) -> ctk.CTkCheckBox:
        cell = self._cell(half)
        pal = self.app.ui.pal
        var = ctk.BooleanVar(value=value)
        box = ctk.CTkCheckBox(cell, text=text, variable=var, fg_color=pal.accent, hover_color=pal.accent_hover,
                              border_color=pal.border, text_color=pal.text, checkmark_color=pal.accent_text,
                              font=self.app.ui.font(13), corner_radius=5)
        box.pack(anchor="w", pady=4)
        self._getters[key] = lambda v=var: bool(v.get())
        self._widgets[key], self._vars[key] = box, var
        return box

    def textarea(self, key: str, text: str, value: str = "", height: int = 80) -> ctk.CTkTextbox:
        cell = self._cell(False)
        self._header(cell, key, text, False)
        pal = self.app.ui.pal
        box = ctk.CTkTextbox(cell, height=height, fg_color=pal.input_bg, border_width=1, border_color=pal.border,
                             text_color=pal.text, font=self.app.ui.font(13), corner_radius=max(0, self.app.ui.radius - 3))
        box.pack(fill="x")
        box.insert("1.0", value)
        self._footer(cell, key)
        self._getters[key] = lambda b=box: b.get("1.0", "end").strip()
        self._widgets[key] = box
        return box

    def custom(self, half: bool = True) -> ctk.CTkFrame:
        """An empty grid cell for caller-built content (e.g. an info box) that keeps the 2-column layout aligned."""
        return self._cell(half)

    def get(self, key: str):
        return self._getters[key]()

    def widget(self, key: str):
        return self._widgets[key]

    def set_value(self, key: str, value) -> None:
        widget = self._widgets[key]
        if isinstance(widget, ctk.CTkEntry):
            widget.delete(0, "end")
            widget.insert(0, value)
        else:
            self._vars[key].set(value)

    def error(self, key: str, message: str) -> None:
        self._errors[key].configure(text=message)
        widget = self._widgets.get(key)
        if isinstance(widget, ctk.CTkEntry):
            widget.configure(border_color=self.app.ui.pal.error)
            widget.focus_set()

    def clear_errors(self) -> None:
        for key, err in self._errors.items():
            err.configure(text="")
            widget = self._widgets.get(key)
            if isinstance(widget, ctk.CTkEntry):
                widget.configure(border_color=self.app.ui.pal.border)

    def require(self, key: str, message: str) -> bool:
        if not self.get(key):
            self.error(key, message)
            return False
        return True


class Dialog(ctk.CTkToplevel):
    """Modal dialog with title, scrollable or plain body and a right-aligned button footer."""

    def __init__(self, app, title: str, subtitle: str = "", width: int = 520, height: int = 460,
                 scrollable: bool = False) -> None:
        pal = app.ui.pal
        super().__init__(app, fg_color=pal.card)
        self.app = app
        self.withdraw()
        self.title(title)
        self.resizable(False, False)
        self.transient(app)
        self.result: Any = None
        head = ctk.CTkFrame(self, fg_color="transparent")
        head.pack(fill="x", padx=24, pady=(20, 10))
        label(head, app, title, 18, True).pack(anchor="w")
        if subtitle:
            label(head, app, subtitle, 12, muted=True, wraplength=width - 60).pack(anchor="w", pady=(2, 0))
        separator(self, app).pack(fill="x")
        self.footer = ctk.CTkFrame(self, fg_color="transparent")
        self.footer.pack(side="bottom", fill="x", padx=24, pady=14)
        separator(self, app).pack(side="bottom", fill="x")
        if scrollable:
            self.body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        else:
            self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=(24, 12) if scrollable else 24, pady=12)
        max_h = max(360, int(self.winfo_screenheight() / max(app_scale(self), 1.0)) - 90)
        self.geometry(f"{width}x{min(height, max_h)}")
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.bind("<Escape>", lambda _e: self.close())
        self.after(30, self._present)

    def _present(self) -> None:
        try:
            self.update_idletasks()
            host = self.app
            x = host.winfo_rootx() + max(0, (host.winfo_width() - self.winfo_width()) // 2)
            y = host.winfo_rooty() + max(0, (host.winfo_height() - self.winfo_height()) // 3)
            self.wm_geometry(f"+{x}+{y}")
            self.deiconify()
            self.after(60, self._grab)
        except tk.TclError:
            pass

    def _grab(self) -> None:
        try:
            self.grab_set()
            self.focus_force()
        except tk.TclError:
            pass

    def add_buttons(self, primary: str, on_primary: Callable, secondary: str = "Cancel", danger: bool = False) -> ctk.CTkButton:
        main = button(self.footer, self.app, primary, on_primary, "danger" if danger else "primary", width=120)
        main.pack(side="right")
        if secondary:
            button(self.footer, self.app, secondary, self.close, "secondary", width=90).pack(side="right", padx=(0, 10))
        return main

    def close(self, result: Any = None) -> None:
        self.result = result
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


def app_scale(widget) -> float:
    try:
        from customtkinter.windows.widgets.scaling import ScalingTracker
        return ScalingTracker.get_widget_scaling(widget)
    except Exception:
        return 1.0


def ask_confirm(app, title: str, message: str, confirm: str = "Confirm", danger: bool = False,
                detail: str = "") -> bool:
    dlg = Dialog(app, title, width=480, height=260 if not detail else 330)
    label(dlg.body, app, message, 13, wraplength=420).pack(anchor="w")
    if detail:
        label(dlg.body, app, detail, 12, muted=True, wraplength=420).pack(anchor="w", pady=(10, 0))
    dlg.add_buttons(confirm, lambda: dlg.close(True), danger=danger)
    app.wait_window(dlg)
    return bool(dlg.result)


def show_guidance(app, guidance: Guidance) -> None:
    """Dialog that tells the person what happened and the exact steps to fix it."""
    pal = app.ui.pal
    dlg = Dialog(app, guidance.title, width=620, height=560, scrollable=True)
    label(dlg.body, app, "Why this happened", 12, True, color=pal.muted).pack(anchor="w")
    label(dlg.body, app, guidance.cause, 13, wraplength=540).pack(anchor="w", pady=(2, 14))
    label(dlg.body, app, "How to fix it", 12, True, color=pal.muted).pack(anchor="w")
    for number, step in enumerate(guidance.steps, 1):
        row = ctk.CTkFrame(dlg.body, fg_color=pal.accent_soft, corner_radius=8)
        row.pack(fill="x", pady=3)
        ctk.CTkLabel(row, text=str(number), width=26, font=app.ui.font(13, True), text_color=pal.accent).pack(side="left", padx=(8, 2), pady=8)
        label(row, app, step, 13, wraplength=500).pack(side="left", fill="x", expand=True, padx=(2, 10), pady=8)
    if guidance.detail:
        label(dlg.body, app, "Technical detail (for support)", 11, True, color=pal.muted).pack(anchor="w", pady=(14, 2))
        box = ctk.CTkTextbox(dlg.body, height=70, fg_color=pal.input_bg, text_color=pal.muted, border_width=1,
                             border_color=pal.border, font=app.ui.font(11))
        box.pack(fill="x")
        box.insert("1.0", guidance.detail)
        box.configure(state="disabled")

    def copy() -> None:
        app.clipboard_clear()
        app.clipboard_append(guidance.full_text())
        app.toasts.show("Fix steps copied to the clipboard.", "success")

    dlg.add_buttons("Close", dlg.close, secondary="")
    button(dlg.footer, app, "Copy fix steps", copy, "secondary", width=130).pack(side="right", padx=(0, 10))


class ToastManager:
    WIDTH, HEIGHT, GAP = 360, 74, 10

    def __init__(self, app) -> None:
        self.app = app
        self.items: list[ctk.CTkFrame] = []

    def reset(self) -> None:
        self.items.clear()

    def show(self, message: str, tone: str = "success", title: str = "") -> None:
        app = self.app
        enabled = True
        try:
            if app.session:
                get = app.settings.get
                enabled = get("notify.toasts") and get({"success": "notify.success", "warning": "notify.warning",
                                                         "error": "notify.error"}.get(tone, "notify.success"))
                if tone == "error" and get("notify.beep_on_error"):
                    app.bell()
        except Exception:
            pass
        if not enabled:
            return
        pal = app.ui.pal
        color = {"success": pal.success, "warning": pal.warning, "error": pal.error}.get(tone, pal.accent)
        frame = ctk.CTkFrame(app, width=self.WIDTH, height=self.HEIGHT, fg_color=pal.card, border_width=2,
                             border_color=color, corner_radius=app.ui.radius)
        frame.pack_propagate(False)
        head = title or {"success": "Done", "warning": "Heads up", "error": "Could not finish"}.get(tone, "")
        ctk.CTkLabel(frame, text=head, font=app.ui.font(13, True), text_color=color, anchor="w").pack(fill="x", padx=14, pady=(8, 0))
        ctk.CTkLabel(frame, text=message, font=app.ui.font(12), text_color=pal.text, anchor="nw", justify="left",
                     wraplength=self.WIDTH - 60).pack(fill="both", expand=True, padx=14, pady=(0, 6))
        close = ctk.CTkButton(frame, text="x", width=22, height=22, fg_color="transparent", hover_color=pal.hover,
                              text_color=pal.muted, command=lambda f=frame: self._dismiss(f))
        close.place(relx=1.0, x=-6, y=4, anchor="ne")
        self.items.append(frame)
        self._layout()
        seconds = 5
        try:
            seconds = app.settings.get("notify.duration") if app.session else 5
        except Exception:
            pass
        frame.after(int(seconds * (3 if tone == "error" else 1) * 1000), lambda f=frame: self._dismiss(f))

    def _dismiss(self, frame) -> None:
        if frame in self.items:
            self.items.remove(frame)
        try:
            frame.destroy()
        except tk.TclError:
            pass
        self._layout()

    def _layout(self) -> None:
        position = "Bottom right"
        try:
            if self.app.session:
                position = self.app.settings.get("notify.position")
        except Exception:
            pass
        right, bottom = "right" in position.lower(), position.startswith("Bottom")
        for index, frame in enumerate(self.items):
            offset = 20 + index * (self.HEIGHT + self.GAP)
            frame.place(relx=1.0 if right else 0.0, rely=1.0 if bottom else 0.0,
                        x=-20 if right else 20, y=-offset if bottom else offset,
                        anchor=("s" if bottom else "n") + ("e" if right else "w"))
            try:
                frame.tkraise()
            except tk.TclError:
                pass


def stat_card(parent, app, title: str, value: str, sub: str = "", tone: str | None = None) -> ctk.CTkFrame:
    pal = app.ui.pal
    box = card(parent, app)
    label(box, app, title, 12, muted=True).pack(anchor="w", padx=16, pady=(14, 0))
    label(box, app, value, 24, True, color={"warning": pal.warning, "success": pal.success, "error": pal.error}.get(tone or "", pal.text)).pack(anchor="w", padx=16)
    label(box, app, sub, 11, muted=True).pack(anchor="w", padx=16, pady=(0, 14))
    return box


def submit_form(app, form: "Form", btn, work, done, text: str) -> None:
    """Run a save in the background. A FieldError lands under its field with the fix; other errors open the fix dialog."""
    btn.configure(state="disabled", text="Saving...")

    def failed(exc: BaseException) -> None:
        try:
            btn.configure(state="normal", text=text)
        except Exception:
            pass
        if isinstance(exc, FieldError):
            form.clear_errors()
            form.error(exc.field, exc.inline_text())
        else:
            app.show_error(exc)

    app.run_async(work, done, failed)


def reauthenticate(app) -> bool:
    """Ask for the signed-in user's password when 'Ask for password before deleting' is on."""
    if not app.settings.get("security.reauth_for_delete"):
        return True
    dlg = Dialog(app, "Confirm it is you", "Type your password to continue.", width=440, height=330)
    holder = ctk.CTkFrame(dlg.body, fg_color="transparent")
    holder.pack(fill="x")
    form = Form(holder, app)
    form.entry("password", "Your password", "", True, show="\u2022")

    def check() -> None:
        form.clear_errors()
        try:
            ok = app.auth.check_password(app.session.user_id, form.get("password"))
        except Exception as exc:
            dlg.close(False)
            app.show_error(exc)
            return
        if ok:
            dlg.close(True)
        else:
            form.error("password", "That is not your password. Retype it, checking Caps Lock.")

    dlg.add_buttons("Continue", check)
    app.wait_window(dlg)
    return bool(dlg.result)


def focus_search(app, entry) -> None:
    if app.settings.get("window.focus_search_on_open"):
        entry.after(80, lambda: entry.winfo_exists() and entry.focus_set())
