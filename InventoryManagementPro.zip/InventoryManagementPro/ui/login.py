"""Pre-login screens: sign in, first-run setup, startup failure (with exact fix steps), change password."""
from __future__ import annotations

import customtkinter as ctk

from core.config import APP_NAME, APP_VERSION
from core.errors import AppError, Guidance, guidance_of
from ui.widgets import Dialog, Form, button, label, show_guidance


def _split_layout(app, parent_frame, headline: str, tagline: str):
    """Brand panel on the left, returns the right-hand frame for the form."""
    pal = app.ui.pal
    parent_frame.grid_columnconfigure(0, weight=4, uniform="s")
    parent_frame.grid_columnconfigure(1, weight=5, uniform="s")
    parent_frame.grid_rowconfigure(0, weight=1)
    brand = ctk.CTkFrame(parent_frame, fg_color=pal.accent, corner_radius=0)
    brand.grid(row=0, column=0, sticky="nsew")
    inner = ctk.CTkFrame(brand, fg_color="transparent")
    inner.place(relx=0.5, rely=0.5, anchor="center")
    ctk.CTkLabel(inner, text="I", width=64, height=64, corner_radius=16, fg_color=pal.accent_text,
                 text_color=pal.accent, font=app.ui.font(30, True)).pack(anchor="w")
    ctk.CTkLabel(inner, text=headline, font=app.ui.font(28, True), text_color=pal.accent_text,
                 anchor="w", justify="left").pack(anchor="w", pady=(18, 6))
    ctk.CTkLabel(inner, text=tagline, font=app.ui.font(14), text_color=pal.accent_text, anchor="w",
                 justify="left", wraplength=340).pack(anchor="w")
    right = ctk.CTkFrame(parent_frame, fg_color=pal.bg, corner_radius=0)
    right.grid(row=0, column=1, sticky="nsew")
    return right


class LoginScreen(ctk.CTkFrame):
    def __init__(self, app, message: str = "") -> None:
        super().__init__(app, fg_color=app.ui.pal.bg)
        self.app = app
        pal = app.ui.pal
        right = _split_layout(app, self, "Inventory\nManagement Pro",
                              "Stock, suppliers and reports for every store, with the right access for every person.")
        box = ctk.CTkFrame(right, fg_color=pal.card, corner_radius=app.ui.radius + 4, border_width=1, border_color=pal.border)
        box.place(relx=0.5, rely=0.5, anchor="center")
        pad = ctk.CTkFrame(box, fg_color="transparent")
        pad.pack(padx=36, pady=32)
        label(pad, app, "Welcome back", 24, True).pack(anchor="w")
        label(pad, app, "Sign in to continue", 13, muted=True).pack(anchor="w", pady=(0, 18))
        form_frame = ctk.CTkFrame(pad, fg_color="transparent", width=340)
        form_frame.pack(fill="x")
        self.form = Form(form_frame, app)
        remembered = app.local.get("last_username", "") if app.settings.get("security.remember_username") else ""
        user_entry = self.form.entry("username", "Username", remembered)
        pwd_entry = self.form.entry("password", "Password", show="\u2022")
        self.msg = label(pad, app, message, 12, color=pal.warning, wraplength=340)
        self.msg.pack(anchor="w", pady=(0, 4))
        self.fix = label(pad, app, "", 12, muted=True, wraplength=340)
        self.fix.pack(anchor="w", pady=(0, 6))
        row = ctk.CTkFrame(pad, fg_color="transparent")
        row.pack(fill="x", pady=(0, 10))
        self.remember = ctk.BooleanVar(value=bool(remembered))
        if app.settings.get("security.remember_username"):
            ctk.CTkCheckBox(row, text="Remember username", variable=self.remember, fg_color=pal.accent,
                            hover_color=pal.accent_hover, border_color=pal.border, text_color=pal.text,
                            checkmark_color=pal.accent_text, font=app.ui.font(12)).pack(side="left")
        if app.settings.get("security.show_password_toggle"):
            self.show_btn = button(row, app, "Show", self._toggle_password, "ghost", width=60, height=28)
            self.show_btn.pack(side="right")
        self.signin = button(pad, app, "Sign in", self._submit, width=340, height=42)
        self.signin.pack(fill="x")
        label(pad, app, f"{APP_NAME} v{APP_VERSION}", 10, muted=True).pack(anchor="center", pady=(16, 0))
        self.user_entry, self.pwd_entry = user_entry, pwd_entry
        for entry in (user_entry, pwd_entry):
            entry.bind("<Return>", lambda _e: self._submit())
        (pwd_entry if remembered else user_entry).focus_set()

    def _toggle_password(self) -> None:
        hidden = self.pwd_entry.cget("show") != ""
        self.pwd_entry.configure(show="" if hidden else "\u2022")
        self.show_btn.configure(text="Hide" if hidden else "Show")

    def _submit(self) -> None:
        username, password = self.form.get("username"), self.pwd_entry.get()
        self.signin.configure(state="disabled", text="Signing in...")
        self.msg.configure(text="")
        self.fix.configure(text="")

        def work():
            return self.app.auth.login(username, password)

        def done(result) -> None:
            if not self.winfo_exists():
                return
            self.signin.configure(state="normal", text="Sign in")
            if result.ok:
                if self.app.settings.get("security.remember_username"):
                    self.app.local.put(last_username=username if self.remember.get() else "")
                self.app.complete_login(result)
            else:
                self.msg.configure(text=result.message)
                self.fix.configure(text="How to fix: " + result.fix if result.fix else "")
                self.pwd_entry.delete(0, "end")
                self.pwd_entry.focus_set()

        def failed(exc: BaseException) -> None:
            if not self.winfo_exists():
                return
            self.signin.configure(state="normal", text="Sign in")
            self.app.show_error(exc)

        self.app.run_async(work, done, failed)


class SetupScreen(ctk.CTkFrame):
    """Shown once, when the database has no users: creates the first store and super administrator."""

    def __init__(self, app) -> None:
        super().__init__(app, fg_color=app.ui.pal.bg)
        self.app = app
        pal = app.ui.pal
        right = _split_layout(app, self, "Let's set up\nyour workspace",
                              "Create your first store and the super administrator who will manage everything else.")
        scroll = ctk.CTkScrollableFrame(right, fg_color=pal.card, corner_radius=app.ui.radius + 4, width=470,
                                        border_width=1, border_color=pal.border)
        scroll.place(relx=0.5, rely=0.5, anchor="center", relheight=0.92)
        label(scroll, app, "First-time setup", 22, True).pack(anchor="w", padx=14, pady=(14, 0))
        label(scroll, app, "This only happens once. You can add more stores and users afterwards.", 12, muted=True,
              wraplength=420).pack(anchor="w", padx=14, pady=(0, 12))
        holder = ctk.CTkFrame(scroll, fg_color="transparent")
        holder.pack(fill="x", padx=14)
        form_host = ctk.CTkFrame(holder, fg_color="transparent")
        form_host.pack(fill="x")
        f = self.form = Form(form_host, app)
        f.entry("store", "Store name", "", True, placeholder="e.g. Riyadh workspace")
        f.entry("city", "City", "Riyadh", half=True)
        f.entry("symbol", "Currency symbol", "SAR", half=True)
        f.entry("full_name", "Your full name", "", True)
        f.entry("username", "Username", "", True, half=True, placeholder="e.g. omar.a")
        f.entry("email", "Email (optional)", "", half=True)
        f.entry("password", "Password", "", True, show="\u2022", half=True)
        f.entry("confirm", "Confirm password", "", True, show="\u2022", half=True)
        g = app.settings.get
        parts = [f"at least {g('security.min_password_length')} characters"]
        parts += (["one capital letter"] if g("security.require_upper") else []) + (["one number"] if g("security.require_digit") else [])
        parts += ["one symbol"] if g("security.require_symbol") else []
        label(holder, app, "Password rules: " + ", ".join(parts) + ".", 11, muted=True,
              wraplength=420).pack(anchor="w", pady=(0, 10))
        self.btn = button(holder, app, "Create workspace", self._submit, height=42)
        self.btn.pack(fill="x", pady=(4, 14))

    def _submit(self) -> None:
        f = self.form
        f.clear_errors()
        ok = f.require("store", "Type a store name, e.g. Riyadh workspace.")
        ok = f.require("full_name", "Type your full name.") and ok
        ok = f.require("username", "Type a username like omar.a (letters, digits, dot, dash).") and ok
        ok = f.require("password", "Type a password.") and ok
        if not ok:
            return
        self.btn.configure(state="disabled", text="Creating...")
        args = [f.get(k) for k in ("store", "city", "symbol", "full_name", "username", "email")]
        args += [f.get("password"), f.get("confirm")]

        def done(_r) -> None:
            if self.winfo_exists():
                self.app.toasts.show("Workspace created. Sign in with your new account.", "success")
                self.app.show_login()

        def failed(exc: BaseException) -> None:
            if self.winfo_exists():
                self.btn.configure(state="normal", text="Create workspace")
                self.app.show_error(exc)

        self.app.run_async(lambda: self.app.auth.create_first_admin(*args), done, failed)


class StartupErrorScreen(ctk.CTkFrame):
    """Full-window explanation when the database cannot be reached, with numbered fix steps."""

    def __init__(self, app, guidance: Guidance) -> None:
        super().__init__(app, fg_color=app.ui.pal.bg)
        pal = app.ui.pal
        box = ctk.CTkScrollableFrame(self, fg_color=pal.card, corner_radius=app.ui.radius + 4, width=700,
                                     border_width=1, border_color=pal.error)
        box.place(relx=0.5, rely=0.5, anchor="center", relheight=0.9)
        label(box, app, "\u26a0  " + guidance.title, 20, True, color=pal.error, wraplength=640).pack(anchor="w", padx=18, pady=(18, 4))
        label(box, app, guidance.cause, 13, wraplength=640).pack(anchor="w", padx=18, pady=(0, 14))
        label(box, app, "How to fix it", 12, True, muted=True).pack(anchor="w", padx=18)
        for number, step in enumerate(guidance.steps, 1):
            row = ctk.CTkFrame(box, fg_color=pal.accent_soft, corner_radius=8)
            row.pack(fill="x", padx=18, pady=3)
            ctk.CTkLabel(row, text=str(number), width=28, font=app.ui.font(13, True), text_color=pal.accent).pack(side="left", padx=(8, 2), pady=8)
            label(row, app, step, 13, wraplength=590).pack(side="left", fill="x", expand=True, padx=(2, 10), pady=8)
        if guidance.detail:
            label(box, app, "Technical detail", 11, True, muted=True).pack(anchor="w", padx=18, pady=(14, 2))
            label(box, app, guidance.detail[:600], 11, muted=True, wraplength=640).pack(anchor="w", padx=18)
        actions = ctk.CTkFrame(box, fg_color="transparent")
        actions.pack(fill="x", padx=18, pady=18)
        button(actions, app, "Retry connection", app.start, width=160).pack(side="left")

        def copy() -> None:
            app.clipboard_clear()
            app.clipboard_append(guidance.full_text())
            app.toasts.show("Fix steps copied.", "success")

        button(actions, app, "Copy fix steps", copy, "secondary", width=140).pack(side="left", padx=10)
        button(actions, app, "Quit", app.destroy, "ghost", width=70).pack(side="right")


class ChangePasswordDialog(Dialog):
    def __init__(self, app, forced: bool = False) -> None:
        super().__init__(app, "Change password",
                         "Your password has expired or was reset. Choose a new one to continue." if forced
                         else "Choose a new password for your account.", width=460, height=470)
        self.forced = forced
        holder = ctk.CTkFrame(self.body, fg_color="transparent")
        holder.pack(fill="x")
        self.form = Form(holder, app)
        self.form.entry("current", "Current password", "", True, show="\u2022")
        self.form.entry("new", "New password", "", True, show="\u2022")
        self.form.entry("confirm", "Confirm new password", "", True, show="\u2022")
        self.add_buttons("Change password", self._submit, secondary="" if forced else "Cancel")
        if forced:
            self.protocol("WM_DELETE_WINDOW", lambda: None)

    def _submit(self) -> None:
        f, app = self.form, self.app
        f.clear_errors()
        if not (f.require("current", "Type your current password.") and f.require("new", "Type the new password.")):
            return
        try:
            app.auth.change_own_password(app.session.user_id, f.get("current"), f.get("new"), f.get("confirm"))
        except AppError as err:
            show_guidance(app, err.guidance)
            return
        except Exception as exc:  # database trouble etc.
            show_guidance(app, guidance_of(exc))
            return
        app.audit.log("password_changed", app.session)
        app.toasts.show("Password changed.", "success")
        self.close(True)
