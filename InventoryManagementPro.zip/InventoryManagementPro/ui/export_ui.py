"""Shared 'Export CSV' flow: pick a file, build rows in the background, write, report, optionally open."""
from __future__ import annotations

from pathlib import Path
from tkinter import filedialog

from core.errors import user_error
from core.export import default_filename, open_file, write_csv


def run_export(app, report: str, headers: list[str], fetch) -> None:
    """fetch() runs in a background thread and returns the list of rows (each a list of cell values)."""
    get = app.settings.get
    name = default_filename(get("reports.filename_pattern"), report, app.session.store_name) + ".csv"
    folder = str(get("reports.export_folder")).strip()
    if folder:
        if not Path(folder).is_dir():
            app.show_error(user_error("The export folder does not exist.", f"'{folder}' was not found on this computer.",
                                      ["Open Settings > Reports & Export > Export folder.", "Type a folder that exists (e.g. C:\\Users\\You\\Documents) or clear the box to be asked each time.",
                                       "Press Save changes, then Export again."], "EXPORT_FOLDER"))
            return
        path = str(Path(folder) / name)
    else:
        path = filedialog.asksaveasfilename(parent=app, title=f"Export {report} to CSV", defaultextension=".csv", initialfile=name,
                                            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return

    def work() -> int:
        rows = fetch()
        write_csv(path, headers, rows, get("reports.csv_delimiter"), get("reports.csv_encoding"), bool(get("reports.include_header_row")))
        return len(rows)

    def done(count: int) -> None:
        if get("audit.log_exports"):
            app.audit.log("export_csv", app.session, "export", None, f"{report}: {count} rows -> {path}")
        app.toasts.show(f"{count} row(s) exported to {path}", "success", "Export finished")
        if get("reports.open_after_export"):
            open_file(path)

    app.run_async(work, done)
