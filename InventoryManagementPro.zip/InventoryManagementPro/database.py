"""SQL Server access layer. All SQL is parameterised; UI code never touches pyodbc.
Every failure is raised as AppError carrying exact fix steps (see core/errors.py)."""
from __future__ import annotations

import re
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Sequence

from core.config import DbConfig
from core.errors import (AppError, database_guidance, integrity_guidance, schema_failed,
                         schema_file_missing)

try:
    import pyodbc
except ImportError as exc:  # shown by main.py with install instructions
    raise ImportError("pyodbc is not installed") from exc

pyodbc.pooling = True
SCHEMA_PATH = Path(__file__).with_name("schema.sql")


def _rows(cursor) -> list[dict]:
    if cursor.description is None:
        return []
    names = [c[0] for c in cursor.description]
    return [dict(zip(names, row)) for row in cursor.fetchall()]


class Tx:
    """Statements inside one SQL transaction. Obtain via Database.transaction()."""

    def __init__(self, db: "Database", cursor) -> None:
        self._db, self._cur = db, cursor

    def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        with self._db.guard():
            self._cur.execute(sql, tuple(params))
            return self._cur.rowcount

    def query(self, sql: str, params: Sequence[Any] = ()) -> list[dict]:
        with self._db.guard():
            self._cur.execute(sql, tuple(params))
            return _rows(self._cur)

    def query_one(self, sql: str, params: Sequence[Any] = ()) -> dict | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def scalar(self, sql: str, params: Sequence[Any] = ()) -> Any:
        with self._db.guard():
            self._cur.execute(sql, tuple(params))
            row = self._cur.fetchone()
            return row[0] if row else None


class Database:
    def __init__(self, config: DbConfig) -> None:
        self.config = config
        self.query_timeout = 30  # seconds; updated from the 'system.query_timeout' setting

    # ---------------------------------------------------------------- errors
    @contextmanager
    def guard(self) -> Iterator[None]:
        try:
            yield
        except pyodbc.IntegrityError as exc:
            raise AppError(integrity_guidance(" ".join(str(a) for a in exc.args))) from exc
        except pyodbc.Error as exc:
            state = str(exc.args[0]) if exc.args else ""
            text = " ".join(str(a) for a in exc.args)
            raise AppError(database_guidance(state, text, self.config.server, self.config.database,
                                             self.config.driver)) from exc

    # ---------------------------------------------------------------- connections
    def connect(self, database: str | None = None, autocommit: bool = False):
        with self.guard():
            conn = pyodbc.connect(self.config.connection_string(database), timeout=self.config.timeout,
                                  autocommit=autocommit)
            conn.timeout = self.query_timeout
            return conn

    def initialize(self) -> None:
        """Create InvProDB (if missing) and all tables. Runs in autocommit mode, outside any transaction."""
        name = self.config.database
        try:
            probe = self.connect(autocommit=True)  # does the database already exist?
            probe.close()
        except AppError as err:
            if err.guidance.code != "DB_CANNOT_OPEN":
                raise
            master = self.connect("master", autocommit=True)
            try:
                with self.guard():
                    master.cursor().execute(f"IF DB_ID(N'{name}') IS NULL CREATE DATABASE [{name}]")
            finally:
                master.close()
        self._run_schema()

    def _run_schema(self) -> None:
        if not SCHEMA_PATH.exists():
            raise AppError(schema_file_missing(str(SCHEMA_PATH)))
        script = SCHEMA_PATH.read_text(encoding="utf-8")
        batches = [b.strip() for b in re.split(r"^\s*GO\s*$", script, flags=re.I | re.M) if b.strip()]
        conn = self.connect(autocommit=True)
        try:
            cursor = conn.cursor()
            for number, batch in enumerate(batches, 1):
                try:
                    cursor.execute(batch)
                except pyodbc.Error as exc:
                    raise AppError(schema_failed(number, " ".join(str(a) for a in exc.args))) from exc
        finally:
            conn.close()

    def ping(self) -> bool:
        try:
            return self.scalar("SELECT 1") == 1
        except AppError:
            return False

    # ---------------------------------------------------------------- queries
    @contextmanager
    def transaction(self) -> Iterator[Tx]:
        conn = self.connect()
        try:
            yield Tx(self, conn.cursor())
            with self.guard():
                conn.commit()
        except BaseException:
            try:
                conn.rollback()
            except pyodbc.Error:
                pass
            raise
        finally:
            conn.close()

    def query(self, sql: str, params: Sequence[Any] = ()) -> list[dict]:
        conn = self.connect()
        try:
            with self.guard():
                cur = conn.cursor()
                cur.execute(sql, tuple(params))
                return _rows(cur)
        finally:
            conn.close()

    def query_one(self, sql: str, params: Sequence[Any] = ()) -> dict | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def scalar(self, sql: str, params: Sequence[Any] = ()) -> Any:
        conn = self.connect()
        try:
            with self.guard():
                cur = conn.cursor()
                cur.execute(sql, tuple(params))
                row = cur.fetchone()
                return row[0] if row else None
        finally:
            conn.close()

    def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        with self.transaction() as tx:
            return tx.execute(sql, params)
